---
name: project-cross-primitive-axioms
description: "Three named cross-primitive consistency axioms (A, B, C) enforced during imscription; violation = malformed tuple"
metadata: 
  node_type: memory
  type: project
  originSessionId: f14b8f62-9438-4a2e-9af7-2253b74c38c3
---

The Imscribing Grammar has three named inter-primitive consistency axioms. Violation means the tuple is malformed — not uncertain, wrong. Verified in `p4ramill/Millennium/ParadoxBoot.lean` and `p4ramill_py/genetic_tuples.py`.

## Axiom A
**Ħ = 𐑫 (eternal/`H_inf`) → Ç = 𐑺 (order-frozen/Ç_Ù)**

If a system has eternal chirality (no finite Markov order), it must have order-frozen kinetics. The depth of chirality memory and the kinetic regime are coupled. Systems with Ħ = 𐑫 but Ç ≠ 𐑺 carry a structural tension (B-state). The Frobenius fixed point (μ∘δ=id itself) lives at Ħ_A (two-step), not Ħ_∞ — so Axiom A is vacuously satisfied by the identity and applies only to structures that accumulate chirality through time.

## Axiom B
**Ω ∈ {𐑭 (Z), 𐑴 (Z₂)} → Ħ ≥ ordinal 2 (𐑒 or above)**

Topological winding protection (integer or Z₂) requires at least two-step chirality memory. A system cannot have topological protection without the memory to sustain it. Ω = 𐑷 (trivial) has no chirality requirement.

## Axiom C
**Ð = 𐑦 (self-written) ↔ Þ = 𐑸 (self-referential closure)**

Self-referential topology requires a self-written state space, and vice versa. Both must be present or neither. A physical system embedded in external degrees of freedom (Ð ≠ 𐑦) cannot carry self-referential topology (Þ ≠ 𐑸). This is the most commonly violated axiom in practice — earlier imscriptions sometimes assigned Þ = 𐑸 to physical systems with Ð = 𐑼 (infinite-dim field).

## Unnamed structural constraints
- **D-Ω**: Ω = 𐑭 (integer winding) typically requires Ð = 𐑼 or 𐑦 (≥ infinite-dim); Ω = 𐑴 (Z₂) requires Ð ≥ 𐑨 (triangle). Ω ≠ 𐑷 with Ð = 𐑛 (point) is a warning.
- **⊙-Ç stability**: ⊙ at criticality + Ç = 𐑧 (slow/near-eq) → deep critical structure, stable. ⊙ at criticality + Ç = fast (𐑺/𐑪) → warning; criticality requires slow kinetics to stabilize.

## Source
- `~/p4rakernel/p4ramill/Millennium/ParadoxBoot.lean` §3: `paradox_fs_satisfies_axiom_A/B/C` (all proved, 0 sorrys)
- `~/p4rakernel/p4ramill_py/genetic_tuples.py`: `verify_tier_consistency()` enforces all axioms at runtime
