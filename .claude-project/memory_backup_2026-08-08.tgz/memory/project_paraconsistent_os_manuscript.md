---
name: project-paraconsistent-os-manuscript
description: `paraconsistent_os_manuscript.tex` — active manuscript in imscribing_grammar describing the paraconsistent OS layer
metadata: 
  node_type: memory
  type: project
  originSessionId: b5d10614-8349-4eaa-8c2a-15c01667ed44
---

`~/imscribing_grammar/paraconsistent_os_manuscript.tex` — manuscript covering the paraconsistent OS layer; actively being compiled as of May 25 2026.

- Compilation was being fixed in the May 25 session (was broken before)
- Connects Belnap FOUR over the 12-primitive lattice to OS-layer execution (`exOS` + priests-engine)
- Part of the broader effort to document the full IG stack in manuscript form

**Why:** Active working manuscript, not yet stable.
**How to apply:** If asked to compile or edit this file, treat it as potentially fragile; verify lualatex pipeline before assuming it compiles cleanly.

Links: [[project-para-layer]] [[project-lualatex-pipeline]] [[project-manuscripts]]
