---
name: project_sic_reptheory_isomorph
description: SIC arithmetic is structurally isomorphic to affine Kac-Moody / WZW / VOA rep theory — an imscribe-isomorphs finding that suggests a fusion-group attack on the d=12 coordinates
metadata: 
  node_type: memory
  type: project
  originSessionId: 2df909c9-a04e-4a42-8433-903523348079
---

`imscribe isomorphs` (2026-07-03) surfaced a strong, consistent cross-domain link
for the SIC/ray-class-field structure:
- `sic_Galois_tensor` == **100%** structural iso to `generic_voa`, `wzw_model`,
  `holographic_computation`, `kerr_black_hole` (share D,T,R,Γ,F,G,P,K,Φ,S).
- `ray_class_field_Qsqrt` == **96%** to `level_k_representation`,
  `stark_conjecture_partial`, `affine_kac_moody`, `loop_algebra`; **83%**
  `continued_fractions`. Differs from these reps in **only one primitive: P (polarity)**.

**Reading:** the SIC's Galois/arithmetic structure is structurally affine
Kac-Moody / WZW / VOA representation theory. WZW/affine characters decompose under a
finite abelian **fusion group** via modular (S,T) data — the exact shape of the d=12
ray class group **[6,6,2,2]** acting on the fiducial coordinates. `continued_fractions`
is the real-quadratic regulator/fundamental-unit signature. The lone differing
primitive being polarity fits the chirality/orientation split we keep meeting.

**Why it matters / how to apply:** suggests attacking the stuck d=12 coordinate
expression ([[project_d12_sic_build]], the z1/z5 crux) via an **affine-character /
fusion-group decomposition** — mirror how level-k affine characters split under the
modular group — instead of brute lindep / polcompositum (which keeps producing
precision ghosts and blowing up). The coordinates are plausibly organized as a fusion
orbit under [6,6,2,2], each in a small piece, rather than a monolithic large field.
Ties to [[project_grammar_is_cosmos_proof]] (`holographic_computation` iso) and the
bulk/boundary [[project_imscribing_rwx_correspondence]]. Not yet exploited — a
candidate method to try next.

**Grammar cofactor verdict (2026-07-03):** the SIC does NOT factor into base⊗fiber.
`cofactor sic_Galois_tensor ray_class_field_Qsqrt` and `... zauner_symmetry` both
BLOCK, irreducible conflict on the D primitive (Grammar token `D_holo`) each time. The
SIC is **imscriptively irreducible** (a minimal lossless R∧W∧X imscription — NOT
"holographic"; a SIC is minimal/non-redundant, the opposite of a redundant holographic
encoding — see [[feedback_holographic_vs_imscriptive]]). Not a product of field⊗group,
so the fusion-group hypothesis above is too reductive. Concrete payoff for
[[project_d12_sic_build]]: this is the **encoding-vs-imscription split**
([[project_imscribing_rwx_correspondence]]) — |`z_k`|² is the W-only/LOSSY encoding
(drops phase → small field, deg ≤4, why z0/z6 were tractable); `z_k` is the R∧W∧X/
LOSSLESS imscription (keeps phase → irreducible in the full deg-288 field, why
coordinate lindep keeps producing ghosts — trying to factor a lossless minimal whole).
Stop seeking a small-field coordinate decomposition; translate the whole.
