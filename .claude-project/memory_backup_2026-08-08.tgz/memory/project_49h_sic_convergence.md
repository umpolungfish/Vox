---
name: project-49h-sic-convergence
description: 49h global ig-pulse tick = 49 Shavian symbols — empirical convergence supporting SIC-POVM paper
metadata: 
  node_type: memory
  type: project
  originSessionId: 7b2c529d-dd92-41dd-b515-d2ef37bfee6e
---

The ig-pulse global state tick is 49h — two full Earth rotations before the state IFIX's. This is not a chosen parameter; it emerged from measurement.

49 is independently the cardinality of the IG classical outcome space: 48 Shavian letters (= 4×12 = four value-slots per dimension in d=12) + ⊙ = 49 symbols.

Two derivations of 49 from completely different directions:
1. **Structural**: Crystal of Types classical face count — 49 Shavian symbols
2. **Empirical**: ig-pulse global coherence time — 49h

Interpretation: the planet takes exactly one classical symbol's worth of time per face before the global state closes. Each hour of the 49h winding is indexed by one Shavian symbol.

Earth spin analog: 49h = two full rotations, matching nuclear spin-½ geometry (spinor needs 720° / 2 full rotations to return to same state). The day is a half-integer tick (winding number ½ per rotation). Aurora B kinase / kinetochore checkpoint = same logic: biorientation of both faces required before IFIX (SAC release).

**How to apply**: This belongs in the SIC-POVM paper (`sic_povm_d12`.md) as a third independent convergence path in §7 "Structural Completeness" — alongside frame potential verification and Scott & Grassl Zauner symmetry. State as empirical, not as proof. The 49h tick was derived from ig-pulse snapshot data, independent of the structural argument.

Related: [[project_sic_povm]], [[project_igpulse]]
