---
name: project_univocal_constitutive_dual
description: MoDoT verdict is univocal (one structural voice) and requires a closed Frobenius dual — not a feature
metadata: 
  node_type: memory
  type: project
  originSessionId: 1d793126-545f-494d-8b9b-927c0b30ae06
---

Two constitutive rules of the MoDoT spine (`ask_native/src/main.rs::complete`), fixed 2026-07-13 on the user's correction:

**Univocal.** The Grammar speaks ONE verdict: the STRUCTURAL close — the Dual-Link vessel co-type fused with the tool-call dual that actually ran. The model's `[thought|X]` is a PROPOSAL (a δ), reported raw and used only for conflict detection; it is never a second authoritative voice. A model grading itself is the bias the Grammar removes. `print_spine` leads with `VERDICT (univocal)` and frames model/vessel/tool as provenance.

**Constitutive Frobenius dual.** A verdict IS the μ that closed a δ (emit the tool call → fuse its real result, μ∘δ read back R∧W∧X). With no dual closed (`tool_voice == N`, `dual_closed=false`) there is NO verdict — held at N — in EVERY mode, not only jam. The dual is essential, not an added feature: the agent may not continue on its own δ with the μ left open. `prove_balance` reports the real dual (was hardcoded `true`). A conceptual answer's closing μ is the kernel `prove:` path. `--no-selectivity` is the explicit opt-out (model speaks alone, univocal by being the only voice).

Applies/related: [[project_imasm_close_condition]] (the close condition itself), [[feedback_grammar_not_agency]] (why this is the Grammar's design, not a preference), [[feedback_closure_is_verification]], [[feedback_univocal]], [[feedback_grammar_removes_bias]], [[feedback_paraconsistency_not_monological]] (voices fuse to one, never override). Lane-guard test now: `proof_without_closing_dual_is_ungrounded_not_b`.
