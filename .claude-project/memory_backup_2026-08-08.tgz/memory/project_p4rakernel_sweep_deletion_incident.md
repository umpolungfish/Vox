---
name: p4rakernel-sweep-deletion-incident
description: A 2026-07-14 notation-migration commit in p4rakernel deleted 375 files including real sorry-free proofs; only 3 have been restored and audited so far
metadata: 
  node_type: memory
  type: project
  originSessionId: 5ba516b5-dd4f-427d-b7ff-6c840abbe5ea
  modified: 2026-08-07T03:25:07.469Z
---

Commit `d971846` in p4rakernel ("Retire the gen-2 glyph-pair notation for
bare Shavian") deleted 375 files / 192,042 lines alongside its stated,
genuine token rewrites. Three of those files — `ClassicalRestriction.lean`
(295 lines, the truth-order coreflective-subcategory proof the README
describes), `ParaconsistentCore.lean`, and `ParaconsistentFrobeniusClosure.lean`
— were restored from the pre-deletion blob on 2026-08-06, rebuilt clean
against the current `build/stage1/bin/lean` with zero changes needed, and
committed at `58de350`. `make lean-oleans` had been silently broken for
three weeks because it names these exact files.

**Why:** [[feedback_sweeps_must_check_identifier_position]] — a sweep titled
as a notation migration deleting real, hand-authored, sorry-free proof
files (not just the generated-artifact cruft — tree.md, tree.txt — that was
legitimately in the same commit) is the exact failure pattern that memory
flags. This is the first confirmed live instance of it in this project,
not just the abstract warning.

**How to apply:** the other ~372 files that commit deleted (per its diff
stat: `ParaconsistentMillennium.lean` at repo root — note `p4ramill/ParaconsistentMillennium.lean`
is a separate, surviving file, not this one — `ParaconsistentKernelTest.lean`,
`ParaconsistentPapers.lean`, `TemporalEngine.lean`, `README_CLASSIC.md`, and
many more) have NOT been audited. Do not assume they were safely superseded
by something in `p4ramill/`; that was checked and found true for some
(e.g. `ParaconsistentMillennium.lean`) and false for `ClassicalRestriction.lean`
specifically — it has no successor anywhere in the tree. Treat commit
`d971846` as unverified, not as a clean retirement, until someone goes
through the rest of its deletions the same way: check whether the content
survives under a new name before accepting the loss. `git show d971846^:<path>`
recovers any of them.

New work built on the restored foundation: `DeMorganBooleanCentre.lean`
computes the actual Boolean centre of Belnap FOUR (`{v | v∨¬v=1}` under the
truth-order lattice, freshly defined as `tmeet`/`tjoin` since `band`/`bor`
turned out to be priority-dominance operators that fail De Morgan duality,
not the lattice meet/join) and finds it is `{T,F}`, sharper than
`ClassicalRestriction`'s `{v≠B}` — N is not a dialetheia but does fail
excluded middle, so it's classical by the old cut and not by this one.
