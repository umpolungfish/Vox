---
name: project_rionrebis
description: "rionrebis / rionrebis_II — personal REBIS TRANSITION gene-design output, separate from red-hot_rebis"
metadata: 
  node_type: memory
  type: project
  originSessionId: c3278fd2-ff13-4ee8-a17a-9ff6a9a2f02c
---

`~/imsgct/rionrebis/` and `~/imsgct/rionrebis_II/` — output directory for a specific "REBIS TRANSITION" design run (dated 2026-06-10), distinct from the general [[project_red_hot_rebis]] pipeline. Personal in nature — gene/hormone-pathway design constructs. Keep references minimal and discreet; don't surface design specifics in unrelated contexts.
