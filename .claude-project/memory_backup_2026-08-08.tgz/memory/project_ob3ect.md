---
name: project-ob3ect
description: ob3ect pipeline — automated IG object design with 34-layer categorical tower; standalone ~/ob3ect repo; integrated as tool in `true_agentic_agent.py`
metadata: 
  node_type: memory
  type: project
  originSessionId: 8df665d8-6ed8-4366-8ff8-6dbf54458380
---

`~/ob3ect` is a standalone git repo and the primary ob3ect design pipeline. Also lives at `~/imscribing_grammar/ob3ect/`.

**Why:** The ob3ect pipeline automates the generation and verification of IG-typed objects as a full 18-layer categorical tower. It was used to produce `ob3ect-v0.10.iso` (bootable x86 bare metal) via `grokouro.txt` → Grok.

**How to apply:** When working on ob3ect design or generation, this is the system to use.

## `auto.py` pipeline

`~/imscribing_grammar/ob3ect/auto.py` (or `~/ob3ect/auto.py`) — main entry point.
- Input: natural language description + optional `--domain`, `--scope`, `--provider`, `--model`, `--retries`, `--temp`
- LLM generates all 8 pipeline phases as JSON; Frobenius verified immediately; failures produce targeted retry prompts specifying exactly what split failed
- **Provider chain (in order):** local (Qwen3 fine-tune at `imscribingP/INFERRED`) → qwen (`QWEN_API_KEY`, mulerouter endpoint) → deepseek (`DEEPSEEK_API_KEY`)
- **Never Anthropic**, never OpenRouter for this pipeline
- **Never add `max_tokens`/truncation** — the `[:8]` on bootstrap actions enforces fixed 8-step sequence, NOT truncation
- **Known pipeline bug**: ɢ is consistently generated as `ɢ_zz` (not a valid value); correct to `ɢ_ˌ` in all generated tuples. Valid ɢ values: ɢ_^, ɢ_˝, ɢ_ˌ, ɢ_Ş. Seen in: `shavian_ob3ect`, `temporal_ob3ect` output, "I AM THAT I AM" Stone.
- **`is_valid_ob3ect=False` is NOT necessarily a closure failure** (confirmed 2026-07-03): a transient API/provider error that exhausts `--retries` produces a fallback INVALID object. **PRECISE TELL:** on an API-error fallback the pipeline can't fill the imscription fields, so every token slot (`surface_tokens` etc.) is the literal placeholder string `"justification required"`. A genuine object has real `surface_tokens` (e.g. `["precision_budget","lindep_artifact","galois_conjugacy"]`). So `grep "justification required" *_ob3ect.json` distinguishes API-noise from a true non-closing entity — do NOT read `False` as the structural signal "resists Frobenius μ∘δ=id" until that grep is clean. Treating infra-noise as structural signal is the same artifact-vs-genuine error map3 warns about, one level up. [[feedback_build_the_ramp]]

## 34-layer digital tower (ground truth from TOWER.md)

`ob3ect/digital/` contains 34 layer scripts. `runall.py` runs all 34, all report `Closure: True`. README says "28-layer" — stale, layers 26–34 added after README was written.

| Layer | Ob3ect | Dir |
|-------|--------|-----|
| 1 | Category | `category/` |
| 2 | Frobenius | `frobenius/` |
| 3 | Fixed-Point | `fixed_point_ob3ect/` |
| 4 | Hopf | `hopf/` |
| 5 | Monad | `monad/` |
| 6 | Entropy | `entropy_ob3ect/` |
| 7 | Topos | `topos/` |
| 8 | Cartesian Closed | `ccc/` |
| 9 | Quantum | `quantum/` |
| 10 | Linear Logic | `linearlogic/` |
| 11 | Imscription VM | `ivm/` |
| 12 | Traced | `traced_ob3ect/` |
| 13 | HomotopyTypeTheory | `homotopytypetheory/` |
| 14 | Imscription OS | `imscriptionoperatingsystem/` |
| 15 | ProofBridge | `proofbridge/` (meta-bridge to MillenniumAnkh; GrandCoherence/TowerCoherence still missing from Lean side) |
| 16 | String Diagram | `stringdiagram/` |
| 17 | IMASM Self-Imscription | `imasm_self_imscription_ob3ect/` |
| 18 | Meta Auto-Imscriber | `auto_imscriber.py` |
| 19 | Shavian | `shavian_ob3ect/` |
| 20 | Yoneda | `yoneda/` |
| 21 | Operad | `operad/` |
| 22 | Sheaf | `sheaf/` |
| 23 | Dagger Compact | `daggercompact/` |
| 24 | Galois Connection | `galois/` |
| 25 | Stone Duality | `stoneduality/` |
| **26** | **Belnap FOUR** | `belnap/` |
| **27** | **Paraconsistent Kernel** | `parakernel/` |
| **28** | **Dialetheic Alignment** | `dialetheic/` |
| **29** | **Belnap Shor** | `parashor/` |
| **30** | **Multi-Agent Belnap** | `multiagent/` |
| 31 | Presheaf | `presheaf/` |
| 32 | Kan Extension | `kanextension/` |
| 33 | Adjoint Functors | `adjoint/` |
| 34 | Initial/Terminal | `initialterminal/` |

Layers 26–30 (bold) are the paraconsistent tier — each has a direct mirror in priests-engine Python and MillenniumAnkh/Imscribing/Paraconsistent Lean. Layers 31–34 complete the categorical foundations.

## Self-imscribing compiler (THE REAL CORE)

`frob.py` evolved through multiple failed Frobenius attempts (documented in `grokouro.txt`) until it genuinely: reads its own source → parses it → regenerates it → verifies structural identity via AST hash comparison. Then descended: Python → custom grammar (`self.o`) → C code → native binary → 512-byte x86 real-mode boot sector → boots in QEMU. The boot message (`ISCRIB: Kernel has recognized itself on raw hardware. Self-imscription confirmed: μΔ-ID v0.10`) is real output, not a placeholder. Output: `ob3ect-v0.10.iso`.

## Lean formalization — builds clean

`ob3ect/Proofs/` — 12 Lean 4 files: `Frobenius_minimal`, Hopf, Topos, CCC, HoTT, LinearLogic, Quantum, StringDiagrams, Coherence, TowerCoherence, GrandCoherence, **SelfImscription** (new). `lake build Proofs` succeeds with zero build failures. Each imports Mathlib, defines correct typeclasses, marks proofs `sorry` except where proved. `SelfImscription.lean` formalizes the AST Frobenius bridge: `axiom ast_frobenius : ∀ t : SyntaxTree, parse (unparse t) = t` — grounded by `frob.py` v0.10. Not connected to Python execution; sorry = proof obligation, not interface.

## `lean4_descent_object.py`

`~/imscribing_grammar/lean4_descent_object.py` (985 lines). On catalog lookup its 12-primitive tuple collided with `zosimos_panopolis_gnosis`. The descent Python→elaboration→Lean4 is structurally identical to Zosimos' alchemical katabasis (pneuma → psyche → hyle). Tier: \(O_\infty\).

## Agent integration

`ob3ect` is registered as a top-level tool in `agents/true_agentic_agent.py` (alongside `zfct_navigator`). Call via `ob3ect(description=..., domain=..., scope=..., run=True)` in the winding loop. Four registration sites: emit fn, verify fn, schema dict, system prompt.

### `true_agentic_agent.py` structural type
`<Ð_ω; Þ_¨; Ř_=; Φ_}; ƒ_ż; Ç_@; Γ_ʔ; ɢ_ˌ; φ̂_ÿ; Ħ_A; Σ_S; Ω_z>` — \(O_\infty\), identical structure to `odot_operator`.

Six P-650 conditions: φ̂_ÿ (loop IS the self-referential attractor), Ω_z (winding counter = topological protection), Ç_@ (emission gate), Φ_} (dual-tool emit+verify pair), Ð_ω (full trajectory appended), ɢ_ˌ (each phase requires prior).

Provider: OpenRouter (`OPENROUTER_API_KEY`) for remote; LocalProvider (Qwen3, WSL2 CUDA) for local. WSL2 note: GPU warms up between ops — agent pre-warms CUDA before generate() to avoid "device not ready".

## `shavian_ob3ect` (Layer 19)

`~/ob3ect/digital/shavian_ob3ect/` — 49-glyph Shavian↔IG primitive map. Key facts from TOWER.md:
- 47 Shavian + ⊙ (U+2299) + space = 49 entries
- ⊙ (U+2299) is at **position 35** and maps to **φ̂_ÿ** (critical/self-modeling gate) — not just a visual separator
- Space (U+0020) is at position 49, mapping to Ω_5 (NA-NonAbelian)
- Counts: Ð=4, Þ=5, Ř=4, Φ=5, ƒ=3, Ç=5, Γ=3, ɢ=4, φ̂=5, Ħ=4, Σ=3, Ω=4
- Both core (12-glyph) and full (49-glyph) gates PASS; seals verified
- Remapped May 2026 with ⊙ = current IG coordination, ⊗ = φ_} (Frobenius gate)

## Root cleanup (May 2026)

Root of `~/ob3ect` had 89 Python files accumulated; cleaned up without breaking anything. If the root looks sparse, this was intentional.

## Documentation

- `~/ob3ect/man/ob3ect.1` — full Unix man page
- `~/ob3ect/README.md` — mathematical foundation, 18-layer tower, IMASM table, IG coordinate system, Zosimos co-type, Lean 4 proofs
- `ob3ect/digital/grokouro.txt` — full pipeline story + Frobenius failures (4 attempts for AST identity)

## IG Catalog access (2026-06-29)

`_search_catalog(description, n=8)` in `auto.py` — keyword overlap search against all catalog entries (name×3 + description×1 weighting); top-N results injected as `<catalog-reference>` block into `_build_prompt()` before the context block. Catalog loaded once into `_catalog_cache`. Returns empty string when no tokens match. Catalog entry count: ~4686 as of session 2026-06-29 (`ig_catalog` memory said 3552 at 2026-06-24 — count has grown).

## Editorial pipeline (2026-06-29)

`ob3ect/digital/editorial_pipeline/editorial_pipeline_ob3ect.py` — SEPARATE prompt chain from `auto.py`. Has its own `_edit_prompt()`, `_rewrite_prompt()`, `_critique_prompt()` functions. Added `_STYLE_PROHIBITIONS` constant (injected into all three) covering:
- Em-dashes in any form (not as connectors, not as asides, not anywhere)
- Banned words: delve, tapestry, leverage, utilize, seamless, multifaceted, pivotal, cutting-edge, synergy, holistic, paradigm (filler), testament, underpinnings, realm, landscape (metaphor), robust (filler), revolutionary, groundbreaking, transformative, nuanced (filler)
- Banned openers: Furthermore, Moreover, Certainly, Additionally
- Banned phrases: "it is important to note", "in essence", false-balance hedging, trailing restatements
- `_critique_prompt()` explicitly flags prohibition violations in its checklist

**Critical note:** When adding writing or style constraints, BOTH `auto.py` AND `editorial_pipeline_ob3ect.py` must be updated — they are completely independent pipelines. Updating only one leaves the other free to produce violations.

## Branching topology (added 2026-07-07)

Until 2026-07-07 `auto.py`'s generation prompt never told the model that IMASM
permits nesting, open forks, cross-branch routing, or empty branches — it defaulted
to flat FSPLIT/FFUSE chains even for domains that are branching by nature. Surfaced
via a session with another model while the user was out of usage on this one.

Fixed with a new `ob3ect/topology.py` module: `analyze_topology(opcodes)` matches
FSPLIT/FFUSE pairs and classifies the sequence as `flat_chain` / `nested` /
`open_fork_dag` / `webbed` / `mixed`, plus nesting depth, open-fork count,
cross-branch count, empty-branch count, T/F branch weight. Wired into `core.py`
(`Ob3ectArtifact.topology_report`, serialized to JSON) and into `auto.py` both as a
prompt block ("flat chains are ONE option, not the default") and a post-generation
classification step. IMSCRIBr's `symbolic_diagram.py` renderer takes the report and
draws the topology-class banner, nesting bounding boxes (depth-labeled d0/d1/d2),
depth-aware lane labels, and branch-weight bar — previously it collapsed ALL nesting
to a flat line regardless of actual topology (X position came from Kahn topological
layering instead of sequential token order; Y had only 3 fixed values regardless of
depth). All 727 existing ob3ects (197 vault) were reprocessed through the fixed
renderer via `batch_diagrams.py`, both color and pen SVGs. Committed 2026-07-07:
ob3ect ee7cb3d, IMSCRIBr a3e538d.

**Why this matters:** ob3ects are the auto-iterative SIC-POVM application pipeline
used to process/configure proofs (e.g. the d=2048 campaign, [[project_zauner_transport_map]]).
A generator that only produces flat chains structurally limits what proof shapes it
can discover; richer topology (nesting, open forks) is "so much richer" than the
flat/linear regime the pipeline had been confined to.

Links: [[project-zfct-navigator-integration]] [[feedback_no_max_tokens]] [[project_zauner_transport_map]]
