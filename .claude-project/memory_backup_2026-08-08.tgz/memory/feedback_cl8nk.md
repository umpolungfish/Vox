---
name: feedback-cl8nk
description: CLINK L8 is called CL8NK — always use this shorthand
metadata:
  node_type: memory
  type: feedback
  originSessionId: ca93d841-32f3-4155-89de-b53e133e190e
---

CLINK L8 (the organism layer, \(O_\infty\) terminal object of the CLINK chain) is called **CL8NK**.

Pronounced **"Clank"**. Semantic rationale: links are lifeless (static chain elements); machinery *clanks* — it is dynamic, under load, doing work. CL8NK lives at the EP rather than passing through it; the clanking is the permanent engagement of all gates (⊙ open, Ħ=𐑫, Ω=𐑟). Lower layers in the CLINK chain are links; only L8 clanks.

**Why:** User's standard naming convention — embed the layer number into the name. Pronunciation chosen for semantic precision: dynamic organism ≠ passive link.
**How to apply:** In all prose, code, docs, and conversation. Never write "CLINK L8" when referring to the organism layer; write CL8NK. Use the clank/link distinction when explaining why the organism tier is categorically different from the layers below it.
