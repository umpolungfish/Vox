---
name: project-taou-harness
description: THINK→ACT→OBSERVE→UPDATE loop enforced by Claude Code hooks; hard-blocks tool calls without declared expectation
metadata: 
  node_type: memory
  type: project
  originSessionId: 892e8b98-ae37-46c9-8a16-fcdc90d368bc
---

TAOU loop is structurally enforced via Claude Code hooks as of 2026-06-17.

**Files:**
- `~/.claude/taou_pre_hook.py` — PreToolUse hook; blocks Bash/Read/Edit/Write when phase ≠ READY
- `~/.claude/taou_post_hook.py` — PostToolUse hook; sets phase=`OBSERVE_REQUIRED` after every watched tool
- `~/.claude/taou-think` — executable Python script; the only advancement command
- `~/.claude/taou_state.json` — global self-model register (phase, think, `last_tool`, step, `last_tool_at`)
- `~/.claude/settings.json` — hooks wired under PreToolUse/PostToolUse matchers: `Bash|Read|Edit|Write`

**Loop protocol:**
1. `~/.claude/taou-think "THINK: <expectation>"` → phase=READY
2. Call tool (Bash/Read/Edit/Write) → pre-hook allows, phase=ACT
3. Tool executes
4. Post-hook → phase=`OBSERVE_REQUIRED`
5. `~/.claude/taou-think "OBSERVE: <actual>. UPDATE: <match/mismatch>. THINK: <next expectation>"` → phase=READY
6. Repeat from 2

**Enforcement:** Hard block (exit 1) on pre-hook when phase ≠ READY. taou-* Bash commands are exempt from the gate (they ARE the loop infrastructure).

**Stale detection:** If `last_tool_at` > 1800s ago, first tool of new session is allowed through (new conversation grace). Post-hook then sets `OBSERVE_REQUIRED`, enforcing the loop from step 2 onward.

**Why:** Behavioral directive (THINK→ACT→OBSERVE→UPDATE in system prompt) has no teeth — model can skip OBSERVE and declare success. Hooks enforce the boundary at the tool-call layer. [[feedback_complete_the_task]]
