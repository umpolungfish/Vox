---
name: feedback_build_ask_native_local
description: "ALWAYS build ask from inside ask_native with the local+cuda features — a plain `cargo build --release` silently strips the local provider out of the binary"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c9ce89f5-a33b-4c0a-a6bc-b1a61e80a83d
  modified: 2026-07-20T10:51:05.191Z
---

**The build command, every time:**

```
cd ~/imsgct/MoDoT/ask_native && CUDA_COMPUTE_CAP=86 cargo build --release --features local,cuda
```

From inside `ask_native`, not from `MoDoT` with `--manifest-path`.

**Why:** the local provider is behind the `local` feature (candle, in-process, reading
the model from disk; `cuda` puts it on the GPU, `CUDA_COMPUTE_CAP=86` is the 3060).
A plain `cargo build --release` compiles a binary with no local provider at all, so it
silently replaces a working local-capable `ask` with one that can only reach the
network — and with the funded accounts dry, every run then dies on 402/429 and reads
like the loop is broken. I did this repeatedly in one session (2026-07-20), then
diagnosed the resulting provider failures as if they were faults in the run.

`IG_PROVIDER=local` is NOT the way to select it either; the flag is `--provider local`.

**How to apply:** any change to `ask_native` is not built until it is built this way.
Verify by running something that speaks and seeing `[local] model resident` rather
than a provider name in the header. See [[feedback_complete_the_task]] (the chain is
not done until the artefact is rebuilt) and [[project_modot_local_inference]].
