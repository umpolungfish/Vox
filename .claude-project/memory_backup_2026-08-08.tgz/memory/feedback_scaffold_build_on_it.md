---
name: feedback_scaffold_build_on_it
description: "ob3ect scaffolds are build-on-top skeletons — port them and flesh out real proof content, don't hedge about overclaiming"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: cf01ac07-ff82-4a88-983c-e5b27d18a191
---

An ob3ect pipeline scaffold (the auto-generated IGProtocol term + Frobenius
theorem from `auto.py`) is a **scaffold**: a structure you BUILD ON. When routes
come back, port the scaffold into the Lean tree and build the real mathematical
content on top of it, iterating until the target is discharged.

**Why:** A scaffold is by definition a work-in-progress skeleton, not a finished
proof. Nobody mistakes a scaffold for a completed claim, so refusing to port it
"to avoid overclaiming", or stopping to ask permission, misreads what it is.

**How to apply:** When the user says routes are ready, execute — port the
scaffold and start filling in genuine theorems (bind to real content like
[[project_para_lean]] / `sic_povm_belnap_unconditional` where it exists, and build
the missing witness where it doesn't). Don't punt with an AskUserQuestion about
"port strategy". Honesty still matters in the FINISHED content (a still-empty
scaffold stays marked WIP with sorries), but the default action is build, not ask.
Relates to [[feedback_execute_dont_punt]] and [[project_ob3ect]].
