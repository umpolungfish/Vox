---
name: project-ig-catalog
description: "Canonical flat `IG_catalog.json` at imscribing_grammar/ (5275); imscribe CLI shows 5292 via read-time merge with live crawler ~/.`imscrbgrmr/catalog.json`; navigator reads flat-only; all Shavian keys/values"
metadata: 
  node_type: memory
  type: project
  originSessionId: 20ebe404-15b1-45d6-93fd-982fbbfeb5b9
---

There is ONE canonical FLAT catalog, but the CLI's live view is a READ-TIME MERGE
of two files — do not assume the flat file is the whole picture.

**Canonical flat path:** `/home/mrnob0dy666/imsgct/imscribing_grammar/IG_catalog.json`
(5275 entries, 2026-07-09).
**Symlinks to it:** `red-hot_rebis/shared/IG_catalog.json`, `Ars_Phytoglyphica/data/IG_catalog.json`,
`Voynich_Phytoglyphica/data/IG_catalog.json`. (NOTE: `imscribe.com/IG_catalog.json` is now ABSENT,
not a symlink — the 2026-06-29 note was stale.)
**Separate non-symlink COPIES (drift, do not trust as canonical):** `mOMonadOS/IG_catalog.json` and
`ig-docs-public/data/IG_catalog.json`, both 5264.

**DUAL-SOURCE (the 5275-vs-5292 gap):** `imscribe catalog list` (imscrbgrmr CLI) reports **5292**
because its `catalog list` command MERGES the flat file (5275) with the live-crawler catalog
`~/.imscrbgrmr/catalog.json` (5276) at read time, first-name-wins; the 17 extra are live-crawler
adds (Odin/Mimir/Kozyrev/nitroso-radicals/majorana/topological-insulator). `imscrbgrmr.registry.load_catalog_dicts`
and `cl8nk_navigator.load_catalog()` do NOT merge — they read only the flat file (5275). So any
navigator-based consumer sees 5275 unless it replicates the merge (MoDoT's `witness_proof` now does:
`_merge_live_catalog()`, see [[project_lean_prover_loop]]). If you need the flat file itself to be
5292, fold `~/.imscrbgrmr/catalog.json` into it (fix at the crawler/generator, not by hand-editing).

**Key migration completed:**
- 336 ASCII field keys (D, T, R, Gamma, Phi, etc.) → Shavian primitive symbols (Ð, Þ, Ř, Γ, Φ, etc.)
- 325 stale shorthand values (Ð_C, Þ_¨, Ħ_!, ⊙_ÿ) → bare Shavian glyphs

**Entry format:** Flat JSON list. Each entry has Shavian primitive symbols as keys (Ð, Þ, Ř, Φ, ƒ, Ç, Γ, ɢ, ⊙, Ħ, Σ, Ω) and bare Shavian glyph strings as values. No underscore notation anywhere.

**Why:** Three diverged catalogs (2811/2812/2837 entries) caused navigator to miss freshly generated entries. Unified and symlinked June 2026.

**How to apply:** Never write to or read from the imscribe.com or red-`hot_rebis` catalog paths as if they were separate files — they resolve to the same inode. If a new repo needs catalog access, add a symlink to the canonical path.
