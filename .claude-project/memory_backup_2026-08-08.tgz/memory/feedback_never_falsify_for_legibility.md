---
name: feedback_never_falsify_for_legibility
description: Never substitute a false/incorrect stand-in for correctness or aesthetics; make the TRUE object read instead
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c39133fc-742f-4c63-9995-5559097327fd
  modified: 2026-07-24T00:34:50.026Z
---

Never trade correctness for legibility, aesthetics, or ease of rendering. I rendered a ring torus (R>r) for an imscribe.com card gif "for legibility" and published it live, when the framework's geometry is the horn torus (R=r=2). Substituting a different object is publishing something false about the framework.

**Why:** The geometry (and every canonical fact) is non-negotiable. "It reads better" is never a reason to show the wrong thing, and it is worst on live/published surfaces. Truth over convenience, always. Pairs with [[feedback_univocal]], [[feedback_no_exact_numbers]], [[feedback_assume_wrong_until_proven]], [[feedback_hold_ground]].

**How to apply:** If the correct object is hard to render or express, make IT read, better camera angle, wireframe, framing, a winding chosen to reveal the feature, not by swapping in an approximation. Horn torus is R=r; the pinch at the center is the point, not a defect to hide. When tempted to simplify a canonical structure for a visual, don't; solve the legibility inside the true object.
