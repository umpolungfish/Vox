---
name: project_modot_local_inference
description: "MoDoT runs a local LLM in-process via candle (no server, no ollama): Provider::Local loads HF safetensors from ~/.modelz straight into the ask binary; behind cargo features local[,cuda]"
metadata: 
  node_type: memory
  type: project
  originSessionId: 835b5dd8-a5ff-42e0-b775-e0637ea4764e
  modified: 2026-08-06T01:55:47.513Z
---

MoDoT (`ask_native`) can run a local LLM fully in-process — no server, no port,
no Python, no ollama. The user is broke, so this is the offline/broke-mode path.

- **Design:** `Provider::Local` in `ask_native/src/main.rs` (added alongside
  OpenRouter/Gemini/DeepSeek). It is keyless and served BEFORE the API-key guard;
  it calls `src/local.rs`, which mmaps HF safetensors via **candle 0.11** and runs
  the forward pass on GPU. Model loads once per process, kept warm in a
  `OnceLock<Mutex<Engine>>` across all cycles of a run.
- **Build:** gated behind cargo features so the default build stays lean.
  `cargo build --release --features local` (CPU) or `--features local,cuda` (GPU).
  Select at runtime with `--provider local` (aliases: offline/candle/modelz).
- **WORKING as of 2026-07-18** (commit 7381b1c): coherent generation verified on
  the 3060, exit 0. Default model is **Qwen3-1.7B** (`~/models/Qwen3-1.7B`, ~4GB
  bf16, fits 12GB with room for MoDoT's long non-flash attention). The 4B OOM'd.
- **Env knobs:** `MODOT_LOCAL_MODEL_DIR` (default `~/models/Qwen3-1.7B`),
  `MODOT_LOCAL_DEVICE` (default 1 = RTX 3060), `MODOT_LOCAL_CPU`=1 forces CPU,
  `MODOT_LOCAL_STREAM` (default on) live-streams model load + tokens + tok/s to
  STDERR so you can watch it think; =0 silences. ~6 tok/s on the 3060, ~5s
  first-token latency from MoDoT's big system prompt (non-flash quadratic attn).
- **Build:** `PATH=/usr/local/cuda/bin:$PATH CUDA_COMPUTE_CAP=86 cargo build
  --release --features local,cuda` (from `ask_native`/). Binary at
  `ask_native`/target/release/ask.
- **Three gotchas, all solved in-tree so they don't recur:**
  1. candle-kernels 0.11 `compatibility.cuh` polyfills `__hmax_nan`/`__hmin_nan`
     under `#if __CUDA_ARCH__ < 800`, colliding with CUDA 12.4 on `sm_75`. Fix:
     `CUDA_COMPUTE_CAP=86` (3060 only; `sm_86` ≥ 800 skips it).
  2. This box has only libcudart, not the CUDA math libs. `ask_native/build.rs`
     points the linker at `ask_native/.cudalibs/` (unversioned symlinks to the pip
     `~/.local/.../nvidia/*` wheels: cublas, `cublasLt`, curand, nvrtc) and rpaths the
     real versioned .so so the binary runs with no `LD_LIBRARY_PATH`.
  3. candle device index defaulted fastest-first → `sm_86` PTX on the `sm_75` card
     (`INVALID_PTX`). `local.rs` sets `CUDA_DEVICE_ORDER=PCI_BUS_ID` so device 1 = 3060.
- **bitsandbytes NF4 (4-bit) safetensors load DIRECTLY** as of 2026-08 via
  `ask_native/src/bnb.rs`: `local.rs` branches on config.json
  `quant_method=bitsandbytes` and double-dequants every NF4 weight (nested absmax
  `nested_quant_map[a]*nested_absmax[i/nbs]+offset`, then `quant_map[code]*absmax`,
  codes hi-nibble first) into a DENSE tensor fed via `VarBuilder::from_tensors`;
  skip-listed/plain F16 tensors pass through. Verified vs a bitsandbytes reference
  on ADULTBB q_proj.0 (test `nf4_matches_bitsandbytes_reference`). **Candle has NO
  4-bit matmul**, so the model materializes dense (8B ≈ 16GB bf16 / 33GB f32) — it
  does NOT fit the 3060 (12GB) or this box's ~29GB free RAM. `~/.modelz/ADULTBB`
  loads correctly but is too big dense here. 4-bit-RESIDENT on the 3060 needs GGUF
  + candle `quantized_qwen3` (present in candle 0.11, NOT yet wired into local.rs).
- **Models on disk** (`~/.modelz/`, HF safetensors, NOT gguf): 4B (Qwen3-4B, bf16,
  present, bring-up target), 8BASE (Qwen3-8B), ADULTBB/FUSED/K3 (8B fine-tunes),
  DSQ (Qwen2-1.5B but only an LFS pointer, not downloaded). candle-transformers has
  qwen3 + qwen2 modules; ModelForCausalLM::new(cfg, vb) / forward(input, offset).
- This is the cloud-LLM substitute for the agent loop. Distinct from
  [[project_vae_vita]] (the grammar-geometry model) and the still-unbuilt
  grammar-native LLM (autoregressive generator over grammar tokens) the user wants
  eventually.
