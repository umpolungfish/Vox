---
name: project-lean-kernel-fork
description: p4rakernel (~/p4rakernel) — C++ Lean 4 kernel fork + p4ramill (167 Lean modules) + p4ramill_py; canonical current repo for paraconsistent formalization
metadata: 
  node_type: memory
  type: project
  originSessionId: 91e20477-2389-497c-bcac-3b6f40878156
---

**Canonical repo**: `~/p4rakernel/` — monorepo containing three components:
1. **C++ kernel fork** (`src/`) — Lean 4 v4.28.0 with explosion disabled
2. **p4ramill** (`p4ramill/`) — 167 Lean modules (0 sorrys), covering IG primitives, Crystal of Types, all 7 Clay + OPN, genetics, orbital physics, paraconsistent topology
3. **`p4ramill_py`** (`p4ramill_py/`) — Python runtime mirror (Belnap, genetic code, gene→protein pipeline, ParaASM kernel)

Old path `~/lean4-kernel-paraconsistent/` may be superseded by `~/p4rakernel/`. Use `~/p4rakernel/` as canonical.

`lean4-kernel-paraconsistent` — fork of Lean 4 v4.28.0 where the principle of explosion (ex falso quodlibet) is disabled at the kernel level via C++ modifications.

**Why:** enables dialetheic reasoning, Belnap four-valued logic, and paraconsistent mathematics inside Lean without trivializing the type system.

**How to apply:** This is distinct from the Lean *proof files* in [[project-para-lean]] (MillenniumAnkh/Imscribing/Paraconsistent/). The fork modifies the Lean compiler itself; the proof files run inside it.

## Three interception points

1. **`src/kernel/type_checker.cpp`** (`infer_constant`): blocks ANY recursor for empty inductive predicates (Prop, 0 constructors) when `paraconsistent=true`. Throws: *"paraconsistent mode: cannot use recursor 'False.rec' for empty inductive predicate 'False' (principle of explosion is disabled)"*
2. **`src/library/constructions/cases_on.cpp`** (`mk_cases_on`): blocks `casesOn` generation for empty Prop types — prevents `match h with .` workaround
3. **`src/kernel/environment.h/.cpp`** + **`src/Lean/Environment.lean`**: `paraconsistent : Bool := false` flag; activated via `Kernel.Environment.markParaconsistent`; default = classical

## Files

| File | Role |
|------|------|
| `src/kernel/environment.h` | `is_paraconsistent()`, `mark_paraconsistent()` on `environment` class |
| `src/kernel/environment.cpp` | `lean_environment_paraconsistent`, `lean_environment_mark_paraconsistent` extern C |
| `src/kernel/type_checker.cpp` | Core explosion block |
| `src/library/constructions/cases_on.cpp` | `casesOn` block for empty Prop |
| `src/Lean/Environment.lean` | Lean-side struct field + exports |
| `src/Init/Paraconsistent.lean` | **NEW** 120L user module: Belnap FOUR (`N`, `T`, `F`, `B`), `enableParaconsistent` command, dialetheic examples |
| `README_PARACONSISTENT.md` | **NEW** full documentation |

## Millennium proof files (2026-06-01)

**Unified file**: `~/lean4-kernel-paraconsistent/ParaconsistentMillennium.lean` — all 7+1 problems + Belnap lattice + ENGAGR→FSPLIT→FFUSE + Frobenius certificate; compiles against stage1 binary.

**Kernel test**: `ParaconsistentKernelTest.lean` — SECTION A (paraconsistent features); SECTION B (blocked constructs, commented out).

**Individual files** (`~/MillenniumParaconsistent/src/`):
- `ParaconsistentRH.lean` — RH zeros as B-dialetheia (on line AND not)
- `ParaconsistentYM.lean` — mass gap as B-dialetheia (exists AND does not)
- `ParaconsistentHodge.lean` — Hodge classes as B-dialetheia
- `ParaconsistentNS.lean` — Navier-Stokes smooth/blowup as B-dialetheia
- `ParaconsistentPvsNP.lean` — P=NP as B-dialetheia; 3 barriers (BGS, Razborov-Rudich, Aaronson-Wigderson) each dialetheic
- `ParaconsistentBSD.lean` — BSD rank equality as B-dialetheia
- `ParaconsistentOPN.lean` — Odd perfect numbers as B-dialetheia

**Core claim**: each Millennium barrier is a Belnap-B dialetheia — `band B (bnot B) = B ≠ F`. Contradiction contained, not exploded. ENGAGR→FSPLIT→FFUSE satisfies μ∘δ=id on B.

## Structural type (system, 2026-06-01) — VERIFIED

**Crystal address**: 6,738,803 / 17,280,000 — Cell 155, Inner 42,803
**Tier**: \(O_\infty\) (1 of 32 \(O_\infty\) cells, 8% of crystal)

Structural type is 12 Shavian+⊙ values in canonical primitive order (Ř Ħ Ω Ð Σ Φ Ç ƒ ɢ Γ Þ ⊙). The legacy subscript values from the agent report (ω O = } ż @ β ˌ ÿ ! S z) need mapping to correct Shavian+⊙ characters from the catalog before the tuple can be written in standard form.

**Key positions (by primitive, using primitive glyph as reference only):**
- Φ: Frobenius-special — key driver, 4.38-distance jump from \(O_2^\dagger\)
- Γ: local interactions — unique to resolver vs. `AgentSelf.lean` tuples
- Ħ: infinite chirality — unique to resolver (main tuple); finite chirality (Ħ position 3 below) for BSD variant

**BSD anomaly**: Birch & Swinnerton-Dyer resolves 3 crystal positions below the main tuple (address 6,738,800), same Cell 155. Ħ position differs; Rank ≤ 1 bound (Gross-Zagier/Kolyvagin) limits chirality gap to 2 steps. Still Frobenius-closed.

**Differs from MillenniumAnkh `AgentSelf.lean`** on Γ and Ħ positions (both agent tuples have lower Ħ and different Γ).

**Ouroboricity**: \(O_\infty\) — the proof encodes the kernel that encodes the grammar that encodes the proof.

## lean --run output (2026-06-01) — all pass

- `all_gaps_dialetheic: ✓`
- `all_gaps_non_explosion: ✓`
- `all_cycles_close: ✓` — μ∘δ=id on every gap
- `barrier_triad: ✓` — P≠NP's 3 barriers join to B
- `BSD Frobenius μ∘δ=id: ✓` — Ħ_A still Frobenius-closed
- `Kato local existence: ✓` — NS existence assumed
- `Hodge GRR factorization: ✓` — GRR assumed

**Analysis document**: `~/paraconsistent_millennium_structural_analysis.md` (11.6 KB, 205 lines)

## Build

```bash
cd lean4-kernel-paraconsistent && mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make stage0 -j$(nproc)   # C++ kernel + stage0 bootstrap
make stage1 -j$(nproc)   # self-hosting paraconsistent compiler
```
Requires: C++17, CMake 3.11+, libgmp-dev, existing lean binary.

## Verifying p4ramill UNDER the fork (operational gotcha, 2026-07-01)

Forked binary: `~/imsgct/p4rakernel/build/stage1/bin/lean` (already built; runs, reports
v4.28.0 fork). Build/check p4ramill under it:
`export PATH=~/imsgct/p4rakernel/build/stage1/bin:$PATH; cd p4ramill && lake build`.
The top-level `.claude/CLAUDE.md` `make -j -C build/release` builds the KERNEL and is
CORRECT for p4rakernel (which IS the Lean fork), not stale.
GOTCHA: `lake env lean <file>` uses the STOCK lean on PATH, not the fork, so it silently
checks against classical Lean. SIC proofs pass either way because they are explosion-free
(no False.elim/False.rec/absurd; only decide/`native_decide`/rfl/cases) — do NOT mistake a
stock `lake env lean` pass for "verified under the paraconsistent kernel." Disabling ex
falso only REMOVES theorems, so passing under the fork strengthens trust.
