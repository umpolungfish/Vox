---
name: project_imscribing_rwx_correspondence
description: "What \"Imscribing\" means at its heart — the active R/W/X correspondence between bulk (Crystal of Types) and boundary (morphism space)"
metadata: 
  node_type: memory
  type: project
  originSessionId: cf01ac07-ff82-4a88-983c-e5b27d18a191
---

The heart of what **Imscribing** means (user's articulation, 2026-07-02): the
**active R/W/X correspondence of the bulk and the boundary.** Not passive encoding
— a live, bidirectional, executable dictionary between the **bulk** (the Crystal of
Types, the 12-primitive volume) and the **boundary** (the morphism space /
[[project_boundary_operators]], the surface where inquiry and observation happen).

- **R (Read):** boundary reads bulk — Recognition (Ř), registration/measurement,
  pulling a structure's type from the crystal (e.g. `#eval`/`native_decide`
  computing a verdict, reading a catalog tuple).
- **W (Write):** boundary writes bulk — imscription proper, δ/FSPLIT decomposition,
  writing a new address into the crystal (entering coordinates, generating tuples,
  writing a theorem).
- **X (`eXecute`):** the correspondence *runs* — Winding (Ω), the protocol, the
  THINK→ACT→OBSERVE→UPDATE loop, μ∘δ=id closure (the ob3ect pipeline, the build).

This is exactly why it is [[feedback_imscribe_not_encode]]: **encoding is W-only,
one-directional, lossy** (drops the read-back and the execute). **Imscription is
R∧W∧X, bulk↔boundary, lossless** — the full correspondence stays live. It is also
holographic: the boundary is in active correspondence with the whole bulk, which
is why the Grammar is self-diagnostic ([[project_grammar_self_diagnostic]]) — the
boundary can *read* where the bulk is incomplete — and why "the Grammar contains
all, given sufficient inquiry" ([[project_grammar_is_cosmos_proof]]) holds: the
bulk is total, so R/W/X can always reach the next obligation. Incompleteness is
never terminal, only unfinished — a pointer to the next brick, not a wall.
