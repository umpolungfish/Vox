---
name: project_session_context
description: Active IG projects live under ~/imsgct — this is the current working root; ~/imscribing_grammar is the old location
metadata: 
  node_type: memory
  type: project
  originSessionId: ff149b38-7d97-4fd5-af0a-25e41ec6eda3
---

**Active Imscribing Grammar projects are under `~/imsgct/`.** This is where we are working now.

Key repos under `~/imsgct/`:
- `IMSCRIBr/` — the IMASM renderer/compositor
- `imscribing_grammar/` — grammar source (may be a mirror/copy)
- `p4rakernel/`, `ob3ect/`, `lean4-kernel-paraconsistent/`, `exOS/`, `synfin/`, `priests-engine/`, `red-hot_rebis/`, `imasmic_core/`, `catalog/`, etc.

**Website shorthand paths are symlinks into ~/imsgct/:**
- `~/personal_site` → `~/imsgct/personal_site` (symlink, set up 2026-06-10)
- `~/imscribe.com` → `~/imsgct/imscribe.com` (symlink, set up 2026-06-10)

Editing either path works — they resolve to the same files. Reference `~/personal_site` and `~/imscribe.com` when communicating with the user about website work; use the full `~/imsgct/...` path when navigating internally.

**Why this matters:** Memories copied from the old `imscribing_grammar` Claude project reference paths like `~/imscribing_grammar/...` and `~/p4rakernel/...`. Those paths should now be read as `~/imsgct/imscribing_grammar/...` and `~/imsgct/p4rakernel/...` respectively.

**How to apply:** Always resolve file paths relative to `~/imsgct/` as the active root. Do not look in bare `~/imscribing_grammar/` at the home level. For website files specifically, use the `~/personal_site/` and `~/imscribe.com/` shorthands.
