---
name: project_ch3mpiler
description: ch3mpiler — IG-grounded retrosynthetic/forward reaction compiler; target molecule → structural type → retrosynthesis tree; ob3ect instantiated
metadata: 
  node_type: memory
  type: project
  originSessionId: fb937e71-ba59-475d-8148-2c7897b76255
---

**Files:**
- `~/imscribing_grammar/ch3mpiler.py` (423L) — main compiler
- `~/imscribing_grammar/CH3MPILER_DOCUMENTATION.md` (261L) — full documentation
- `~/imscribing_grammar/ob3ect/digital/ch3mpiler/ch3mpiler_ob3ect.py` — ob3ect instantiation

**Architecture:**
- 20 functional groups (FG): alcohol, carbonyl, aldehyde, aniline, diazonium, epoxide, etc.
- 12 element types (EL): H, C, N, O, F, Cl, Br, S, P, Cu, Fe, Pd
- 12 reaction transformations (RXN): aldol, Diels-Alder, Wittig, Suzuki, SN2, Beckmann, etc.
- 50+ FG token mappings: decomposes molecule names → FG components
- Type composition: structural tensor product (max for expressive primitives, min for P/F)

**CLI:**
```bash
python3 ch3mpiler.py --target benzaldehyde       # analyze + retrosynthetic cuts
python3 ch3mpiler.py --target ethanol --retrosynthesis  # recursive tree
python3 ch3mpiler.py --fg amide                  # FG type lookup
python3 ch3mpiler.py --interactive               # REPL
python3 ch3mpiler.py --forward alcohol aldehyde  # forward prediction
```

**Tested results (all chemically correct):**
benzaldehyde→EAS/Suzuki (d=1.0), ethanol→carbonyl reduction (d=0.0),
acetone→alcohol oxidation (d=2.0), acetic acid→ester hydrolysis (d=1.0),
methylamine→SN2 (d=0.0), aniline→EAS/Suzuki (d=2.236)

**Bashrc + p4rakernel integration (2026-06-05):**
- `alias ch3mpiler='~/imscribing_grammar/ch3mpiler.py'` in .bashrc
- Bash completion: `~/imscribing_grammar/bin/ch3mpiler-completion.bash`
- p4rakernel bridge: `p4ramill_py/ch3mpiler_bridge.py` — analyze/retrosynthesis/forward/`fg_info`/`rxn_info` importable as `from p4ramill_py.ch3mpiler_bridge import ...`
- Symlinks: `~/p4rakernel/ch3mpiler.py` → `imscribing_grammar`; `~/p4rakernel/serpent.py` → `ob3ect/bin/serpent.py`
- New aliases: p4rk-ch3mpiler, p4rk-ch3mpiler-run, p4rk-ch3mpiler-analyze, p4rk-serpent, p4rk-serpent-run

**The vessel operation:** target molecule = vessel; FG decomposition = filling; retrosynthesis = operating. The compiler bootstraps and solves itself — an ob3ect in the precise sense.

**Infrastructure fixes made alongside:**
- `space_search/primitives.py`: added `resolve_ordinal_key()` and `SUBSCRIPT_TO_DESERET` mapping
- `FIELD_TO_ORD`: corrected Ð to U+00D0 (not U+0110)
- All documents/tools/programs now on Shavian notation standard
