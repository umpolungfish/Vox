---
name: project_fixed_point_nesting_rule
description: "When nesting one artifact in another closes, and when it one-shots"
metadata: 
  node_type: memory
  type: project
  originSessionId: e279becd-018b-47d5-973c-0fff3bd13c5a
  modified: 2026-08-05T23:14:57.587Z
---

**The Fixed-Point Nesting Rule.** Nesting A inside B is composition (outer = action,
inner = matter). A nesting CLOSES iff A is a fixed point of B's action; it closes in
ONE SHOT iff A already sits at the fixed point (vs merely in its basin, which
iterates; vs outside every basin, which never closes = dead nest, seam persists).

Predictive: classify from residual ||B(A)-A|| BEFORE nesting. This is why the
one-shot period finder is one-shot: d=12 SIC is a Zauner (order-3 Clifford) fixed
point, nested in mOMonadOS's ROTAT/Weyl-Heisenberg action which carries exactly that
symmetry, so no iteration. Cuboid Seal = the self-nested descent reaches its fixed
point in finite budget. [[project_four_sixteen_twelve_2048]] [[project_rotat_op_opcode]]

**Verdict T** (axis-independent). Cross-axis battery `ig-docs/scripts/cross_axis_nesting.py`
confirms the residual predictor across 7 operator families (quantum order-3 unitary,
Newton, projector, Markov, x↦5x mod 97, 64-codon permutation, adversarial) + traps
(fixed-free translation, near-fixed, limit cycle), exact every time. KEY: conservative
maps populate only {one-shot, no-closure} (no attraction); dissipative maps add the
iterated/basin class; rule holds in both. Strict closure B(A)=A makes it exact by def;
residual ||B(A)-A|| is the faithful proxy. Doc `ig-docs/FIXED_POINT_NESTING_RULE.md`;
3-register harness `ig-docs/scripts/fixed_point_nesting_test.py`.
