---
name: project-synfin
description: synfin — IG-typed financial trading system; live deployment active 2026-06-05; signals from morphisms not levels
metadata: 
  node_type: memory
  type: project
  originSessionId: 09962f83-b323-49a0-a301-b67d1e308af1
  modified: 2026-08-03T19:00:19.294Z
---

`~/synfin` — **Imscribing Financial Trading System**. Models market structure as 12-primitive tuples; signals from morphisms not levels. Ω gates position size.

**Why:** Active live trading system. User's coin holdings are real.
**How to apply:** Treat as a real trading system. Verify code before asserting behavior.

## REPAIRED 2026-08-03 — it had not imported since a notation sweep

synfin was a hard SyntaxError and nothing that imports it had run. A sweep
spelled the Criticality enum members as their glyphs; Shavian is a legal Python
identifier so `𐑢 = 0` parses, but the critical point's glyph is `⊙`, a math
symbol, and one line took the whole package down. See
[[feedback_sweeps_must_check_identifier_position]].

All twelve primitive enums are now on the **Core.lean constructor names**
(dead/ash/array/if_, judge/eat/mime/oil/are, woe/monad/roar/err/haha, …), which
is what the Grammar's own models use and the only spelling that covers all 49
values. Every reference, string key, glyph table and `⟨…⟩` signature literal
moved with them. Two other sweeps had left `Dimensionality.if_` and
`Topology.are` referenced against enums that never had them.

`canonical_bridge.py` was the propagation that mattered and was broken both
ways: it built its nav dict under the retired letters against a navigator that
had moved to the marks (two key spaces that never intersect, so nothing
resolved), and three axes still emitted retired subscript values (`ƒ^ì`, `Ç^@`,
`ɢ^Ş`). Both directions are canonical now; the philosopher's stone round-trips
to **O_∞ at address 6734591**, which is the man page's own worked example.

`OuroboricityTier` now carries its notation on a `.display` property (O₀ O₁ O₂
O₂† O_∞) and keeps a plain identifier as `.name`; subscripts and ∞ cannot sit in
attribute position. **172 tests pass.**

## Run command (current)

```bash
cd ~/synfin && python3 -m synfin.paper_trader_optimus \
  --coins BTC ETH SOL DOT ATOM NEAR \
  --capital 0 --para-mode --timeframe 4h \
  --hysteresis 5 --max-positions 6 --interval 3600 \
  --live --position-pct 100 --max-order-usd 8 \
  --stop-loss 5 --take-profit 8
```

`--capital 0` auto-fetches real USDT balance. API keys in env: `BINANCEUS_API_KEY` + `BINANCEUS_SECRET`.

## Architecture

- `paper_trader_optimus.py` — full 12-primitive pipeline + live execution (--live flag)
- `domain_streams.py` — 10 free data streams → DomainStreamAggregator (hourly refresh)
  streams: fear/greed, mempool, coingecko, blockchain.info onchain, NOAA tides,
  air quality, NASA DONKI CME/flares, USGS seismic, NOAA Kp, HN sentiment
- `para_signal.py` — B4 paraconsistent belief layer (requires priests-engine in sys.path)
- `orders.jsonl` — live order log at ~/synfin/orders.jsonl (append-only, all-time history)

Domain multiplier schedule: 0 alerts=1.00×, 1=1.20×, 2=1.35×, ≥3=1.50× (B-state).
Live orders only fire when domain mult ≥ 1.35 (2+ orthogonal alerts).
Live BUY on long entry; live SELL on `exit_long` AND on `reinforce_short`/`enter_short_vol`
when account holds the coin (sells existing holding, up to `max_order_usd` cap).

## Stop-loss / take-profit (added 2026-06-18)

`--stop-loss 5 --take-profit 8` (defaults). Checked every cycle in `run_cycle`
after `process_new_bars` updates price. Fires live SELL and closes paper position.
Pass 0 to disable either leg.

Why this was needed: `hysteresis_window=5` on 4h bars requires 5 confirmed 4h
candles (~20h) for an exit signal — no other exit path existed.

`_restore_positions_from_log`: on `--live` startup, reads orders.jsonl, nets
buy-sell qty per coin, checks against live holdings, reconstructs TrackedPosition
with avg fill cost. This lets stop-loss track pre-restart entries.
Caveat: uses all-time net from orders.jsonl — if a coin has heavy historical
sell history, `net_qty` may be 0 even if a recent buy is open (NEAR case 2026-06-18).

`_MIN_ORDER_USD` lowered from 1.0 → 0.10; exchange API enforces its own `MIN_NOTIONAL`
per pair. NEAR/USDT minimum notional is higher than per-slot size at $5.34 capital/6.

## Live session — 2026-06-18

USDT free $5.34 (after June 17 session depleted most of $16.94).
5/6 positions restored from orders.jsonl (NEAR had `net_qty`≈0 from prior sells).
Restored positions in green vs historical avg cost: BTC/ETH/SOL/ATOM positive, DOT ~-0.8%.
Stop-loss armed at 5%. System sleeping hourly, cycling on new 4h candles.

## Live session — 2026-06-17

Started at 21:23 with $16.94 USDT. Bought all 6 coins ~$2/each.
23 cycles run overnight. Stream B-state held ×1.50 entire session.
No exits fired (no exit mechanism existed yet — fixed 2026-06-18).
Positions all slightly underwater at session end (-$0.75 total `uPnL`).

## Live session — 2026-06-15

USDT free: $20.76. Fresh cycle entered at 16:02 UTC.
Positions opened: BTC $66,201 | ETH $1,789 | SOL $73.71 | DOT $1.016 | ATOM $1.946 | NEAR $2.421
B-state ×1.50, alerts=8, all Frobenius PASS, B4=T across the board.

## Code fix — 2026-06-14

Portfolio had $88.70 total but only $2.20 USDT free. Per-slot notional $0.37 —
below minimum, so no buys executed. Fix: `_live_coin_holdings` dict + short signals
queue live SELL of held coins regardless of paper position state.

## Live deployment — 2026-06-05

Sold 25 NEAR @ $1.965 → $49.13 USDT to seed capital.
Entry conditions: Fear&Greed=12, M-class solar flares, Kp=4.33, B-state ×1.50.

## Exit conditions

Grammar fires `exit_long` when `T_in` resolves, Fear&Greed recovers >30,
domain mult drops below ×1.35, or B4 flips from T to F/N.
Stop-loss at -5%, take-profit at +8% (as of 2026-06-18).
