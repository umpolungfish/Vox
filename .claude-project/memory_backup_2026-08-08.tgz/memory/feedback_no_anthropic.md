---
name: Never suggest Anthropic as a provider
description: Do not mention Anthropic, Anthropic API, or Anthropic credits as an option or fallback for anything in this project.
type: feedback
originSessionId: cf9cd0aa-e4b6-41e2-af16-a03772bffc03
---
Never suggest Anthropic (the API provider) as an alternative or fallback in any context — not for provider flags, not for credits, not as a default.

**Why:** The user has said this many times. They do not use Anthropic as a provider for this project.

**How to apply:** When discussing providers, models, or API credits, only mention non-Anthropic options (OpenRouter, OpenAI, DeepSeek, Gemini, local models, etc.). Never say "or you could use Anthropic" as a fallback.
