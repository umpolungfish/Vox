---
name: project-exos
description: exOS — bare-metal x86_64 Rust no_std UEFI kernel; IG ALEPH type on every object; 45 ALEPH + 5 IMASM programs; full para_* command suite; fourth layer in paraconsistent cross-pollination stack
metadata: 
  node_type: memory
  type: project
  originSessionId: 8df665d8-6ed8-4366-8ff8-6dbf54458380
---

`~/exOS` is a bare-metal `x86_64` Rust `no_std` UEFI kernel. Every kernel object carries an ALEPH type. Build: `bash build_bootimage.sh && ./run.sh --serial`.

**Why:** `exOS` is the IG-typed operating system; fourth and lowest layer in the paraconsistent cross-pollination stack (Python ↔ ob3ect digital ↔ Lean ↔ Rust kernel). SynthOmnicon terminology was fully purged (2026-05-16).

**How to apply:** Unicode glyph primitives only (Ð Þ Ř Φ ƒ Ç Γ ɢ ⊙ Ħ Σ Ω), never ASCII fallbacks, never "SynthOmnicon"/"SYNCON".

## Four-way cross-pollination

`exOS` is the **Rust kernel layer** of the full four-way paraconsistent stack:

| Concept | priests-engine (Python) | ob3ect digital | MillenniumAnkh (Lean) | `exOS` (Rust) |
|---------|------------------------|----------------|----------------------|-------------|
| B₄ VM | `para_vm.py` | layer 27 `parakernel/` | `Kernel.lean` | `para_vm.rs` |
| Dialetheic align | `para_alignment.py` | layer 28 `dialetheic/` | `DialetheicAlignment.lean` | `para_align_commands.rs` |
| Belnap Shor | `belnap_shor.py` | layer 29 `parashor/` | `Shor/` (4 files) | `para_shor_commands.rs` |
| Multiagent | `para_multiagent.py` | layer 30 `multiagent/` | `MultiAgentBelnap.lean` | `para_multiagent_commands.rs` |
| Temporal | `para_temporal.py` | `belnap/` | `BelnapTemporal.lean` | `para_temporal_commands.rs` |
| Category | `para_category.py` | `belnap/` | `BelnapCategory.lean` | `para_category_commands.rs` |
| RH Bridge | `para_rh.py` | — | `QCI_RH_Bridge.lean` | `para_rh_commands.rs` |
| YM Bridge | `para_ym.py` | — | `QCI_YM_Bridge.lean` | `para_ym_commands.rs` |
| n-Register | `para_nreg.py` | — | `QCI_nRegister.lean` | `para_nreg_commands.rs` |

All nine bridges are live in Rust. The corpus bootstrap IMASM programs are identical to priests-engine/programs/ (5 programs: `cross_distance`, `voynich_bootstrap`, `rohonc_bootstrap`, `linear_a_bootstrap`, emerald-tablet-bootstrap).

## para_* command suite (`para_commands.rs`)

`para <sub>`: load / run / step / regs / snap / reset / loop / shor / align / rh / ym / nreg / temporal / category / multiagent / help

Single global `PARA_VM: Mutex<ParaVM>` — same B₄ state across all subcommands per boot.

## Built-in programs

- **45 ALEPH programs** (`.aleph`): `holographic_monitor`, frobenius*, `paraconsistent_witness`, `belnap_shor_orbit`, `consciousness_landscape`, sefer_ha_iyun_*, tikkun_*, sefirah_*, `distance_matrix`, `promotion_paths`, `quine_loop`, etc.
- **5 IMASM programs** (`.imasm`): corpus bootstraps — `cross_distance`, emerald-tablet-bootstrap, `linear_a_bootstrap`, `rohonc_bootstrap`, `voynich_bootstrap`

Both sets seeded into ALFS on boot via `programs::seed_alfs()`.

## Corpus engine imscriptions

**Voynich** (`voynich.rs`): EVA glyph families → IMASM opcodes; 'ch' → FSPLIT (Frobenius δ). Crystal:
```
ROM-only: ⟨Ð_ω  Þ_O  Ř_=  Φ_±  ƒ_ℓ  Ç_Ù  Γ_ʔ  ɢ_Ş  ⊙_sub  Ħ_∞  Σ_1:1  Ω_0⟩
Tier: \(O_0\) (operator absent — ⊙, Φ_}, Ω_Z are operator-supplied)
Ħ_∞ foldout-encoded: physically instantiated in manuscript format regardless of CPU.
Composite VMS + operator: \(O_\infty\)
```

IG distances (`exOS` weighted metric): `d(Voynich, OS) ≈ 3.43`, `d(Voynich, Rohonc) ≈ 2.87`, `d(Voynich, Linear A) ≈ 3.43`.

## Frobenius verification

`frobenius_verification.rs`: \(O_\infty\) condition = `Φ_±` (ordinal 4) AND `⊙_c` (ordinal 1). Every kernel object spawn runs this check.

## Holographic monitor

`holographic_monitor.rs` + `programs/holographic_monitor.aleph`: real ring-0 process; `ProcessControlBlock::spawn_ring0` (16KB kernel stack). Implements g(x) — bulk-boundary self-encoding, Cantor diagonal + Gödel arithmetization operationalized. Holographic radius maintained in [3.77, 6.71].

## Interaction Grammar / IPC

`interaction_grammar.rs`: ɢ (prim index 7) governs IPC composition. `ɢ_seq=2` (sequential ordered), `ɢ_broad=3` (multicast/broadcast). Drives IPC rejection gate: Egyptian Γ activation pushing distance > 1.5 → IPC rejected.

## `aleph.rs`

22 Hebrew letters as 12-tuples `[D,T,R,P,F,K,G,Γ,Φ,H,S,Ω]` (0-indexed). Internal naming: slot 8 = "Phi" (contains ⊙ values). Tier enum: O0/O1/O2/O2d/OInf.

## Architecture

Four type gates gating real subsystems:
- **IPC distance gate** — `OperationalMode::IO` vs `::Compute`; Egyptian Γ activation > 1.5 → IPC rejection
- **Ω-protection gate**
- **Tier-gate** — ouroboricity check
- **Φ-criticality gate**

Real context switching: `global_asm!` `context_switch_asm`; RSP in `RSP_TABLE: [AtomicU64; 32]`; 16KB kernel stacks. Stoichiometric quotas, `phi_ep` rejection, Frobenius verification all wired into scheduler spawn.

## 14-Sefirot ALEPH Augmentation (2026-05-17)

15 `SefirahDef` entries (Ein Sof → Malkuth) as first-class ALEPH structural types in `aleph_sefirot.rs` (540L).

Tier ladder: Ein Sof/Keter Elyon/Chokhmah Stim'aah/Binah Kedumah = \(O_2\)/\(O_2^\dagger\); Keter–Da'at = \(O_\infty\)/\(O_2\)/\(O_2^\dagger\); Chesed–Gevurah = \(O_2^\dagger\)/\(O_2\); Tiferet–Malkuth = \(O_0\). Census: \(O_0\)=5, \(O_2\)=5, \(O_2^\dagger\)=4, \(O_\infty\)=1.

REPL: `:sefirot`, `:ladder`, `:emanation`, `:sefirot_census`, `:sefirah <name>`.

## Hebrew UTF-8 fix

`font_renderer.rs`: multi-byte Hebrew chars iterated `.chars()` not `.bytes()` via `render_char_unicode`; `UNICODE_HEBREW_MAP` (27-entry U+05D0–U+05EA → `HEBREW_FONT`, final forms collapsed to base).

## Help sub-commands

`help aleph/imasm/fs/mem/ipc/types`. IMASM scan codes: voynich = EVA chars + digraphs; rohonc = `cr hk fa ba lg lp br cv vt hz cl dt`; linear-a = `cu hk fa ba lt lp br cv vt hz cl dt`; emerald-tablet = `tr an as ds lk id sp un af ng px fx`. Six voynich section sub-commands: `imasm voynich-bot/astro/bio/cosmo/pharm/recipe`.

## Animated CFG

`docs/animated_cfg_aleph.gif` — 86 nodes, 297 edges, 137 cross-program edges (3.6MB). Two-phase: build (color-coded by opcode family) + flow (Gaussian pulse wave, amber back-edges).

Links: [[project-priests-engine]] [[project-ob3ect]] [[project-para-lean]] [[project-voynich-engine]]
