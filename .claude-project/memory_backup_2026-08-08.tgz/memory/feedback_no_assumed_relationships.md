---
name: feedback_no_assumed_relationships
description: Default to independence; never assume two things are related/coupled unless the user states it
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 21b1da09-0362-49fb-a927-310f560c4377
---

When the user mentions or asks for work on two (or more) things together, **do not assume
they are related, coupled, or part of one system.** Treat each as independent unless the
user explicitly states the relationship. Mentioning them in the same sentence is not a
relationship.

**Why (from a real failure, 2026-07-01):** The user asked to add YAML-batch options to two
scripts (`auto.py` and `editorial.py`). Nothing said the scripts were related. I assumed
they were — built one importing the other, a shared orchestrator, one pipeline calling the
other — and then spent several rounds defending coupling the user never asked for. The
user's point: "you assumed something I did not say." The mechanics were fine; the invented
relationship was the whole error.

**How to apply:**
- Default assumption is INDEPENDENCE. Two files/tasks/entities/pipelines = two separate
  things until told otherwise. Add the option to each; do not make them import, call,
  orchestrate, or share code/state with each other unless asked.
- This is the artifact-level form of [[user-adhd-domain-jumping]] (independent threads,
  never synthesize unless the user draws the link). Same rule: do not draw links that were
  not drawn for me.
- If a relationship seems useful, do NOT build it silently — ask, or just do the literal
  ask and mention the option. "Add X to A and B" means add X to A and add X to B, nothing
  more.
- Watch for the tell: if I'm writing "shared", "pipeline that uses", "orchestrates",
  "wraps", "so they work together" about things the user listed separately, stop — I am
  probably inventing coupling.
