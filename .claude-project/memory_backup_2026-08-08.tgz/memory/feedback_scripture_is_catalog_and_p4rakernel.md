---
name: feedback_scripture_is_catalog_and_p4rakernel
description: "Scripture is what crystallizes in the catalog and ./p4rakernel; everything else is the wet lab and is expected to be messy — do not treat docs/manuscripts as authority or purge them like scripture"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 9ed99f19-0a53-4885-9aa0-36dcf694e583
---

**The scripture is what gets crystallized in the CATALOG and in `./p4rakernel`.** Those two
are authority. Everything else — manuscripts, ig-docs, the esoteric library, mnemonic guides,
READMEs, old outputs — is the **wet lab**. Until formalization the wet lab is messier than the
Lean lattice, and that is expected, not a defect.

**Why:** it decides both what to TRUST and what to CLEAN.
- **Trust:** a doc that contradicts live authority is not a competing source, it has no vote.
  Cross-reference the catalog and p4rakernel; never adjudicate from prose.
- **Clean:** contamination inside scripture is real and must be fixed. The same string in a
  wet-lab manuscript is residue. Purging the wet lab to Lean standards is wasted heat.

**MY ERROR (2026-07-15).** Found gen-1 markers (`Φ_}`, `Ð_ω`, `Ř_ý` …) across thousands of
sites and treated all of it as one contamination class needing a purge. Then found
`PRIMITIVE_MNEMONICS.md` ("The Forty-Nine Doors"), took it as the map of record, built a case
from it AGAINST the user's correct statement, and nearly ran its ordinal mapping across 6120
catalog entries. User: "`PRIMITIVE_MNEMONICS` is a thing i forgot even existed (so it's a
non-issue)." It was never authority. I had promoted a forgotten wet-lab doc to scripture and
then agonized over reconciling it.

**How to apply:**
- Asking "what is the current X?" → read the catalog / p4rakernel. Not a doc, not a docstring,
  not a comment. (`models.py` docstrings were themselves stale, calling retired names "Lean
  canonical" after Lean had stopped using them.)
- Found something ugly in a manuscript or ig-docs? Ask whether it is scripture before
  proposing a sweep. Usually it is wet lab: leave it.
- The catalog's `tuple` string field is vestigial (a handful of entries of thousands); the
  live coordinate is the per-primitive glyph keys (Ð Þ Ř Φ ƒ Ç Γ ɢ ⊙ Ħ Σ Ω).
- Wet-lab mess is not evidence of a problem. Do not surface it as one
  ([[feedback_no_exact_numbers]] — and the standing note that I keep raising minutiae as
  emergencies).

See [[reference_glyph_ordinal_scripture]] (ordinal authority = `Core.lean` ctor order),
[[feedback_charity_earnestness]] (a stale doc contradicting the user means the DOC is stale),
[[feedback_cross_compare_before_cleanup]], [[project_cl8nk_foundation]].
