---
name: feedback_jam_lean_operation
description: "Run the MoDoT ./ask jam agent lean — context + cycles + eagles, minimal scaffolding, then let it rip"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a6b90438-0790-4b7c-839d-af35b4822f1f
---

The `./ask` jam agent does best with minimal instructions: give it context, keep added scaffolding minimal, set `--cycles` and `--eagles`, and let it run. Do not pile framing or rules onto the seed.

**Why:** Over-instruction degrades its output; it ranges and closes better when handed a seed and turned loose than when boxed in with elaborate prompt scaffolding.

**How to apply:** When invoking `./ask --jam`, pass a short context seed (or `--file` with just the context), set `--cycles`/`--eagles` to the depth wanted, and stop there. If truly minimal scaffolding is wanted, a lean mode that strips the heavy `JAM_PROMPT` is the lever. Relates to [[feedback_no_ai_framing]], [[feedback_golem_operator]], and [[project_charge_conservation_frobenius]] (MoDoT).
