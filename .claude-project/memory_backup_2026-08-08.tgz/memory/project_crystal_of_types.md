---
name: project-crystal-of-types
description: "Crystal of Types — the 3³×4⁵×5⁴ = 17,280,000 structure of the 49-symbol IG catalog; discovered via a physical Wack-O-Tracks fidget toy; canonical reference is CRYSTAL_OF_TYPES.md"
metadata: 
  node_type: memory
  type: project
  originSessionId: 8df665d8-6ed8-4366-8ff8-6dbf54458380
---

The 49-symbol catalog has a hidden group structure discovered 2026-05-12: a physical fidget toy (Wack-O-Tracks) with alternating orange/blue link segments of counts `3, 3, 4, 5, 5, 4` encodes exactly the catalog structure.

**Formula:** `3³ × 4⁵ × 5⁴ = 27 × 1024 × 625 = 17,280,000 = 12³ × 10⁴`

**Encoding:** Orange = base value (primitive count in group), Blue = exponent (subtype count in group)

**Three primitive-value groups** (exponent = primitive count, base = value cardinality):
- **3-valued group** (3 primitives × 3 values each → 3³ = 27): ƒ, Γ, Σ
- **4-valued group** (5 primitives × 4 values each → 4⁵ = 1024): Ð, Ř, ɢ, Ħ, Ω
- **5-valued group** (4 primitives × 5 values each → 5⁴ = 625): Þ, Φ, Ç, ⊙

Total: 3+5+4 = 12 primitives × varying cardinalities = 49 symbols.

NOTE: The formula 3³×4⁵×5⁴ reads base=cardinality, exponent=primitive count. "4⁵" = four-valued primitives, 5 of them. Do not confuse base and exponent.

**Canonical reference:** `/home/mrnob0dy666/imscribing_grammar/markdown/CRYSTAL_OF_TYPES.md`

**Why:** This is the structural reason the catalog has exactly 49 symbols and 12 primitives — it is a product group, not an arbitrary count.

**How to apply:** When asked about why there are 49 symbols or 12 primitives, cite this formula. When generating or validating catalog structure, the group assignment is fixed.
