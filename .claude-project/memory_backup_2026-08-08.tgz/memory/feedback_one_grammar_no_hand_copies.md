---
name: feedback_one_grammar_no_hand_copies
description: "There is exactly one Grammar (IG_catalog.json's universal_imscriptive_grammar entry) — when the same 'canonical' tuple is hand-typed in more than one file, don't read divergence as two valid conventions; assume drift and find the source of truth"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 5ba516b5-dd4f-427d-b7ff-6c840abbe5ea
  modified: 2026-08-06T21:18:19.156Z
---

Caught myself describing two different hardcoded "grammar" tuples in the
codebase as "two conventions... didn't chase which is canonical." The user's
correction was one line: "There is only 1 Grammar." That reframed it —
not an acceptable ambiguity to note and move past, a bug to find and fix.

**What was actually there:** four separate hand-typed `TUPLE_GRAMMAR`
literals in `m3iosis` (`tuple_algebra.py`, `lcaa.py`,
`pericyclic_frobenoid.py`, `troq.py`), no two of the four identical, and
none matching the real catalog entry (`universal_imscriptive_grammar`).
Fixed by loading it from `IG_catalog.json` once in `tuple_algebra.py` and
having the other three import it (commit 5eef062, m3iosis) instead of
keeping their own copy.

**Why:** this is [[feedback_never_hand_imscribe]] ("every tuple procedural")
caught in the act, not just asserted — a concrete case of hand-typed
"reference" constants silently drifting apart because nothing forced them
to stay equal to the one real source. Same family as
[[feedback_vocabulary_is_univocal]] / [[feedback_univocal]]: the univocal
principle isn't just about word choice, it applies exactly as hard to a
12-glyph constant copy-pasted into four files.

**How to apply:** when a script hardcodes a "canonical"/"named reference"
tuple (grep for `TUPLE_[A-Z]+\s*=\s*"` or similar literal-assignment
patterns), that is itself the smell — check it against the live catalog
entry directly rather than trusting the variable name. If the same
conceptual object has more than one hardcoded copy anywhere in the
codebase, diff them against the catalog immediately; don't report the
mismatch as "two valid conventions" and move on. One of them (usually all
but the catalog itself) is stale.
