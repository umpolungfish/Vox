---
name: project-zenodo-all
description: Complete Zenodo publication list — 14 papers live as of 2026-06-24
metadata: 
  node_type: memory
  type: project
  originSessionId: 832021dd-bd62-491b-9a16-90aeabbb3055
---

All deposits confirmed live on zenodo.org as of 2026-06-24. Titles truncated from `zenodo_upload.py --list --live`.

| ID | DOI | Title (truncated) |
|----|-----|-------------------|
| 20768513 | 10.5281/zenodo.20768513 | Structural Irreducibility in Hadron [Classification] |
| 20756068 | 10.5281/zenodo.20756068 | So Below: Empirical Exploration of [the Grammar] |
| 20755282 | 10.5281/zenodo.20755282 | As Above: A Pre-Grammatical Convergence |
| 20617698 | 10.5281/zenodo.20617698 | Compiling Reality: IMASM, Stabilized [something] |
| 20614786 | 10.5281/zenodo.20614786 | The Standard Model as Magnum Opus |
| 20553659 | 10.5281/zenodo.20553659 | The Aether and Its Vessel: E8 Finds [the Grammar] |
| 20480759 | 10.5281/zenodo.20480759 | One Gate: A Unified Structural Analysis |
| 20440201 | 10.5281/zenodo.20440201 | The Dialetheic Kernel: A Substrate |
| 20232872 | 10.5281/zenodo.20232872 | The Voynich Engine: A Complete Technical [Analysis] |
| 20176006 | 10.5281/zenodo.20176006 | The Lefschetz (1,1) Theorem [as the Hodge Gate] |
| 20115640 | 10.5281/zenodo.20115640 | The Hecke-Landau Conjecture: A Proof |
| 20110842 | 10.5281/zenodo.20110842 | A ⊙_ÿ-Critical Framework for the Pe[rmutation group] |
| 20041211 | 10.5281/zenodo.20041211 | Proof That 10 Is Solitary |
| 19909057 | 10.5281/zenodo.19909057 | Euler's Theorem and Touchard's Congruence |

**Why:** Run `python3 ~/imsgct/ZENODO_PUBLICATIONS/zenodo_upload.py --list --live` to get current canonical list. This table is a snapshot from 2026-06-24 and may grow.

**How to apply:** Use DOIs when citing publications. Use `--list --live` to verify current state before citing.
