---
name: feedback_copy_pdf_to_root
description: Compiled PDFs go to ig-docs/pdfs/ alongside the manuscript directory; ~/imsgct/pdfs/ was deleted and must not be recreated
metadata:
  type: feedback
---

After compiling a manuscript, copy the PDF to **`~/imsgct/ig-docs/pdfs/`**, the
directory beside the source tree it was built in. That is where the PDFs are
read.

`~/imsgct/pdfs/` was a stray duplicate and was deleted on 2026-08-08. Do not
recreate it. Everything it held existed elsewhere (`somepapers/`,
`ig-docs-lifted/`).

**Why:** copying to the wrong pdfs/ meant reporting "fixed, PDFs copied" while
the read directory still carried a build two days stale, so corrections looked
applied and were not.

**How to apply:** compile in the manuscript directory, then copy to
`ig-docs/pdfs/`. Confirm by reading the timestamp of the copy that was just
written, not the one that was compiled. Related:
[[feedback_always_compile_pdf]], [[feedback_edit_the_file_being_viewed]].
