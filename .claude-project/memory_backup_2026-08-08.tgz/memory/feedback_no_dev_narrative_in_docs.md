---
name: no-dev-narrative-in-docs
description: never narrate bug-fix/change history inside docs or code comments describing how a system works now; that belongs in commit messages or a changelog
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2006ca5c-6115-489b-95ba-1455f96fc6e2
---

Documentation, READMEs, and any file explaining how a system works must describe the system AS IT IS NOW, in present tense, for a reader who wants to understand or use it. Never write "before this, a bug X sat underneath it... now it does Y instead" — that's development history, not documentation. Nobody reading a doc to learn how something works needs to know what it used to do wrong.

This is the same failure mode as [[feedback_no_exact_numbers]] and [[feedback_writing_prohibition_strength]]: leaving traces of the process in the artifact instead of just stating the result cleanly.

**Why:** called out explicitly 2026-07-16 in `vae_vita/SENSE_ORGAN.md` — a paragraph explained a prior bug ("a real bug sat underneath it... `name=\"7\" description=\"7\"`...") instead of just stating what the function does now. User: "who is it for? this should be relegated to a changelog or a commit. and you do this a lot" — confirmed as a recurring pattern, not a one-off.

**How to apply:** Before writing any doc/README/code-comment sentence, check if it describes a past state or a fix ("used to X", "before this", "a bug caused", "previously"). If so, cut it or move it to a commit message. Docs get only the current, working description. Comments should explain WHY current code is shaped the way it is only when non-obvious — never a fix's before/after story.
