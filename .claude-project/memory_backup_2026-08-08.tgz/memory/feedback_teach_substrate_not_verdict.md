---
name: feedback_teach_substrate_not_verdict
description: "When a model generates imscriptions, teach it paraconsistency + B4 + SIXTEEN_3 up front and NEVER ask it for the closure verdict — the engine computes it; PASS/FAIL framing causes classical-invertibility spirals"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 036652e6-7ffe-4c76-b89f-73a47d6e4a08
  modified: 2026-08-06T08:52:18.176Z
---

A prompt that asks a model to design an ob3ect/imscription must TEACH THE LOGIC
SUBSTRATE before anything else, and must NOT ask the model to emit or justify a
Frobenius/closure verdict.

**Why:** A local-model trace designing a neural-network ob3ect spent its entire
reasoning budget stuck on "does FFUSE(FSPLIT(x))=x, else FAIL" — it decided a
forward/backward fork FAILS because training changes the weights. Root cause: the
prompt framed closure as classical PASS/FAIL and demanded the model prove domain
invertibility, with zero explanation of the paraconsistent logic. With no
substrate, a model defaults to classical binary and reads a held contradiction as
a failure instead of B.

**How to apply — three axes (done for ask_native/src/ob3ect.rs AND ob3ect/auto.py):**
1. PROMPT/EXPLANATION: open with the substrate. B4 = {N,T,F,B}; **B (both) is a
   stable resolution, not an error** (paraconsistency: contradiction held, not
   exploded). The verdict is computed over SIXTEEN_3 = P({T,F,t,f}) (the trilattice).
   Reframe μ∘δ=id: the arms REJOIN to one B4 verdict (conflicting arms → B), NOT
   that domain contents return unchanged. An open fork is legitimate (B or N), not
   a FAIL. Kill PASS/FAIL entirely. Use the live transforming set > < ⋈ ⊤ ⊥ ⊞ ◻
   (never retired = + × ¬).
2. HARNESS: the model DESCRIBES structure; the engine VERIFIES. Map the emitted
   opcode word to glyphs and run it through the kernel — Rust:
   `imasm_core::imasm16_3::tri_ancestral_verdict`; Python:
   `imasm16_3_core.Sequence16_3Trace.tri_ancestral_verdict`. Take the real B4 value.
   NEVER trust a model-asserted verdict, and NEVER retry-to-force PASS (that retry
   loop was the spiral's engine).
3. closure_verified / "closed" means kernel verdict T or B. N (bare closure, no work
   on arms) and F (refuted) are legitimate results, recorded not gated.

The neural-net fork the model called FAIL is verdict **T** under both engines
(`⊢∈>⊤<⊥∋◻⊣`). See [[feedback_closure_is_verification]], [[feedback_no_verdict_before_check]],
[[feedback_paraconsistency_not_monological]], [[project_four_sixteen_twelve_2048]],
[[project_para_layer]], [[feedback_never_hand_imscribe]].

**THE GENERAL RULE (co-developed, holds beyond prompts): NEVER COLLAPSE A GRADED /
PARACONSISTENT REALITY INTO A BOOLEAN.** The universe is not two-valued and this
codebase knows it. When tempted to return/assert a bool, stop.
- A boolean is a *convention* (a threshold someone chose), never a *truth*. The
  truths are the continuous/graded quantities under it. Report those; leave any
  collapse to a caller who needs one. Don't dress the convention as physics.
- The native state is Belnap FOUR (N/T/F/B), empirically: `~/imsgct/ig-pulse/data/
  coupling.json` = 7018 measured cross-stream couplings, 81% strictly graded
  (0.05<|r|<0.95), range −0.912..1.0, only 17% at the ±1/0 extremes.
- Watch for a smuggled-in wrong BASELINE too: "quantum advantage over classical
  SIMULATION" graded advantage by circuit simulability (MPS χ) when the whole
  method REPLACES simulation; advantage is topological. If a word imports the
  wrong frame (e.g. "simulation"), cut the word.
- Applied so far: ob3ect designer (PASS/FAIL→B4 verdict from engine); disassembler
  lift verdicts; Shor `certify_advantage` (dropped has_advantage/classical_feasible/
  mps_bond_dim/"simulation" → report accumulated_error + logical_qubits, commit
  ca20a6c). HOLD THIS BY DEFAULT; do not wait to be walked down to it.
