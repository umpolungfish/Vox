---
name: project_imasm_close_condition
description: "IMASM/Frobenius close condition = μ∘δ over a TRANSFORMED object, not a cycle, not identity"
metadata: 
  node_type: memory
  type: project
  originSessionId: 1d793126-545f-494d-8b9b-927c0b30ae06
---

The close / type-check condition for an IMASM composition (and for μ∘δ Frobenius closure generally) is: **δ (FSPLIT) splits, the arms carry a genuine TRANSFORMATION (do distinct work), then μ (FFUSE) fuses them back.**

Two things it is NOT:
- **Not a cycle.** A bare loop (β = circuit rank ≥ 1 with no δ/μ, e.g. IMSCRIB→AFWD→AREV→back) is not a closure. β is not diagnostic of closure.
- **Not identity.** Split→fuse with nothing between is μ∘δ=id — it verifies nothing. IMSCRIB is the identity morphism, so arms carrying only IMSCRIB do no work.

The kernel already formalizes this crux in `p4ramill/Imscribing/Paraconsistent/BelnapSplitFuse.lean`: `fsplit B = (T,F)` (distinct arms) but `fsplit s = (s,s)` for every other state — theorem `B_is_the_only_bifurcation_point`. So only the dialetheic B genuinely bifurcates (transforms); all else is a diagonal copy. `split_fuse_id`: ffuse∘fsplit = id. `CLINK.lean` and `BootstrapSequence.lean` model a valid sequence as a chain of type TRANSFORMATIONS (base→final), not identity.

**How to apply:** implemented rust-native in `ask_native/src/imasm.rs` — `closure_state` returns Closed (transform+reconnect) / Identity (reconnect, no work) / Open (fork dangles) / None (no δ/μ). `imasm check` gives the Belnap verdict; `imasm prove` takes the class to the real kernel via `prover::compile_lean` against BelnapSplitFuse. See [[feedback_closure_is_verification]], [[feedback_tools_rust_native]], [[project_para_lean]], [[project_majorana_fixed]] (B = SIC fiducial = the bifurcation point). Don't reinvent closure semantics — p4ramill defines them.
