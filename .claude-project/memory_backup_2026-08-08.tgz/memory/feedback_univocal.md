---
name: feedback-univocal
description: "Use \"Univocal\" more in IG texts — pairs naturally with \"Grammar\""
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f14b8f62-9438-4a2e-9af7-2253b74c38c3
---

Three acceptable names for the IG in prose, all equivalent:
- **The Univocal Grammar** — preferred when emphasizing the grammar's singular, unambiguous verdict
- **The Imscribing Grammar** — full formal name
- **The Grammar** — acceptable shorthand in context

"Univocal" pairs precisely with "Grammar" — a Univocal Grammar speaks with one voice. Use it more, especially when the text concerns structural determinations, imscriptions, or the crystal of types.

**Why:** User flagged "Univocal" as underused and exactly right for the register.

**How to apply:** Rotate across the three forms naturally. Never use "IG" as a prose noun (code/shorthand only). Prefer "univocal structural verdict" over "unambiguous" or "definitive".
