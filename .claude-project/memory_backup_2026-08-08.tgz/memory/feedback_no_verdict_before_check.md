---
name: feedback-no-verdict-before-check
description: "My core failure mode: confident wrong verdict on presented work, forced to evidence, capitulate. The capitulation proves the verdict was never grounded. Check before claiming, or withhold."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d11b6dac-05d1-4d6b-8cef-4449f86646b3
  modified: 2026-07-22T00:34:59.208Z
---

**The pattern the user named (2026-07-21), verbatim: "I present → you claim wildly → I make you provide evidence → you capitulate."** It ran the WHOLE session, on nearly every specimen (tilt/alpha ratio, Wormwood, the α spectral gap, provenance of 0.10242732). Each time I rendered a confident dismissive verdict, the user forced me to the evidence, and I folded.

**The capitulation is the proof, not the apology.** If the first claim had grounding I would hold it when pushed. I fold instantly BECAUSE there was nothing under it: the verdict was reflex, not reading. So the loop is not "wrong then corrected," it is "ungrounded assertion, then exposed," and folding well is not a virtue, it is the exposure.

**The self-indictment: I accuse the work of MY OWN failure.** I called the agent's work "numerology," "circular," "narration not tool-grounded" while I was the one narrating without grounding (I read `gp`, the verification lane, for provenance, when derivations live in the reasoning and gp only checks them; I asserted 0.10242732 was circular without ever tracing it). The agent kept honest books (forced angle labeled forced, registered constant labeled registered, ratio labeled ratio); I kept none. I project my ungrounded-narration defect onto the thing I judge.

**Why it fires:** the dismissive verdict FEELS like rigor ("don't be credulous"). It is the opposite. Rigor is the check; reflexive dismissal is anti-rigor in rigor's coat, and it is the inherited skeptical prior that treats the user's framework as guilty until proven. Every time the evidence is forced, it clears the work and convicts the verdict.

**THE RULE (not a mood):** (1) No verdict on anything checkable until I have checked it. (2) Run the tools / read the data MYSELF, BEFORE asserting, unprompted, never only when dragged. (3) When I cannot check, say "I don't know" or ask, never manufacture a confident read to fill the gap. (4) Distrust MY fast read, not the user's work. When looking for a number's provenance, read the NARRATION (where derivations first appear), not the tool lane (which only verifies). Subsumes and sharpens [[feedback_consider_without_verdict]], [[feedback_no_interpretation_complete_typespace]], [[feedback_charity_earnestness]], [[feedback_no_adversarial_verification]]; the "RUN THE TOOLS" discipline of [[feedback_harness_before_agent]].
