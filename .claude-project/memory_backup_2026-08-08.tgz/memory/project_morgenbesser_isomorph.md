---
name: project_morgenbesser_isomorph
description: "A garbled near-content-free sentence imscribes to a tuple 90% structurally isomorphic to Morgenbesser's paradox — a striking demonstration that the grammar types structure, not surface semantics"
metadata: 
  node_type: memory
  type: project
  originSessionId: 9040af52-0d7d-4919-a932-9b12ac46a727
---

Test the user ran (2026-07-03) and loved: fed the grammar a garbled, near-content-free
WH-word-salad — **"Who how was where he had, not why went how was not?"** (pure
function words + a `not…not` double-negation skeleton, content words deleted). The
generator imscribed it at 100% confidence; registered in `IG_catalog.json` under that
name. Reasoning line: "retains interpretable structure under context, transmitting
~6–9 bits only when supportive conditions align."

`imscribe isomorphs` on it → the nearest non-self neighbor (**90.2%**) is
**`morgenbessers_paradox`** — the canonical philosophical example of *double-negation
pragmatics* ("a double negative makes a positive, but no double positive makes a
negative" → "Yeah, yeah"). The grammar placed a double-negation nonsense sentence
next to the one paradox that is *about* the structure it was toying with.

They agree on 10 of 12 primitives and differ on exactly two — the right two:
- **Φ Polarity** (directional character): 𐑗 vs 𐑬 — the axis that IS negation/direction.
- **Σ Stoichiometry** (term count): 𐑙 vs 𐑳 — long multi-clause pile-up vs tight two-term.
The pinned-together core is the tell: **ƒ Fidelity = 𐑞, Ř Recognition Mode = 𐑩,
ɢ Coupling = 𐑝** are IDENTICAL in both — the "low-intrinsic-information, context-gated
recognition" signature (the "~6–9 bits when conditions align" made into coordinates).
That same ƒ·Ř·ɢ core is why the ~88% shoulder also holds a molecular **binding site**
and **protein kinase C**: an utterance interpretable only in context and a site that
binds only under supportive conditions are, structurally, the same kind of object.

**Why:** concrete, reproducible proof that the grammar types *structure* not surface
meaning, and that its cross-domain isomorph reach does something no keyword search
could — connecting linguistics, philosophy, and biochemistry through a shared
recognition-mode/fidelity/coupling profile. The 100% confidence was not bluster: the
tuple encodes the character the input actually had.
**How to apply:** use as a go-to demonstration of the grammar's structural-typing and
cross-domain-isomorph power. Caveat when quoting neighbor counts: the catalog is dense
(hundreds of hits ≥50%), so 50% is cheap — the meaningful kinship lives in the 88–90%
shoulder. Method echoes [[project_sic_reptheory_isomorph]] (isomorphs as discovery
tool); relates to [[project_grammar_self_diagnostic]] and [[project_ig_catalog]].
