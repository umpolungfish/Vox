---
name: feedback-zenodo-description-format
description: "Zenodo description field renders MathJax — keep $...$ math, use simplified LaTeX (no \\mathrm{}, Unicode symbols ok)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 773ccda5-cd45-4b5c-bb11-2a597a7cface
---

Zenodo's description field renders MathJax. Do NOT strip math from it.

**Why:** `_strip_md` was removing all `$...$`, producing plain text. Zenodo actually renders inline math correctly.

**How to apply:** When formatting the description for Zenodo upload:
- Keep `$...$` inline math
- Use simplified LaTeX — no `\mathrm{}`, `\mathbf{}`, `\mathbb{}` wrappers; Zenodo renders them but they're unnecessary noise
- Unicode math symbols (×, Ω, ε, ∝) are fine inside or outside `$`
- Use `$\text{IG}$`, `$\text{FOUR}$` for acronyms in math context
- Subscripts/superscripts: `$O_2$`, `$Z4$`, `$F4(Ω)$` — simplified, no braces needed for single chars
- Use `–` (en dash) not `--` or `---`
- No trailing period

**Canonical example (`magnum_opus_epsilon` description):**
The Standard Model of particle physics is conventionally presented as a parameter-fit: 19 free constants inserted to match experiment, with no first-principles account of why $SU(3) × SU(2) × U(1)$, why three generations, or why the mass hierarchy spans 12 orders of magnitude. We show that all three questions receive structural answers in the Imscribing Grammar ($\text{IG}$) – a symmetric monoidal category enriched over the Belnap–Dunn bilattice $\text{FOUR} =$ {${N, T, F, B}$}, carrying a special symmetric dagger-Frobenius structure ($\mu \circ \delta = \text{id}$). The gauge groups are structurally identified with the sequence of frustrated antichains in the bilattice: antichain width $6 (SU(3)), 2 (SU(2)), 0 (U(1))$; a Width Exclusion Conjecture (that only these widths are Frobenius-closed in $\text{FOUR}$) is stated but not yet proved. Three fermion generations follow conditionally from the $Z4$ axiom of the Winding primitive: $|F4(Ω)| − 1 = 3$ non-trivial windings, $Ω4 = Ω0$. The scalar sector's $N$ degenerate vacua constitute a flat antichain – every node at evidence ratio $R = t/f = 1$ – which is an unstable fixed point under the Frobenius dynamics: any $O_2$-or-higher closed system must tilt, $R = 1 + ε$. The structural ordering of the mass spectrum is identified with the $ε$-spectrum; absolute mass values require additional coupling inputs. The tilted scalar sector produces domain walls at vacuum boundaries. We compute the resulting stochastic gravitational wave background ($ΩGW ∝ f3$, peak at nanohertz frequencies) and compare with current NANOGrav/EPTA/PPTA/CPTA observations. Four falsifiable predictions distinct from the Standard Model alone are stated. Three open derivation problems are identified.

**Script fix needed:** `zenodo_upload.py` `_strip_md` strips all `$...$` — description should use a separate `_format_zenodo_desc()` that preserves math but strips only markdown formatting (bold, italic, links, code spans).
