---
name: project-default-acknowledgement
description: Default acknowledgements section and Larson reference for all IG publications
metadata: 
  node_type: memory
  type: project
  originSessionId: 98b98cc4-b13a-44d4-839d-9f38680b7293
---

Every publication in this project must include:

**Acknowledgements section** (before References):

> The author would like to thank Harry T. Larson, for imparting the importance of catching rising problems, and never letting them go.

**Larson reference** (always include in the numbered reference list):

> Larson, Harry T. "Catch a Rising Problem... and Never Ever Let it Go." *IRE Transactions on Engineering Management,* vol. EM-8, no. 4, pp. 173–174, Dec. 1961. https://ieeexplore.ieee.org/stamp/stamp.jsp?arnumber=1641382

**Why:** User's standing instruction — this editorial and the acknowledgement of Harry T. Larson are to appear in all publications going forward.

**How to apply:** Whenever writing or editing a publication markdown file (any file that will be compiled to PDF via `ltx` or `zenodo_draft.py`), add the Acknowledgements section immediately before the References section, and append the Larson reference to the numbered bibliography.
