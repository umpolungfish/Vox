---
name: feedback_holographic_vs_imscriptive
description: "Never say \"holographic\" unless it genuinely entails a redundant bulk-boundary encoding; the Grammar's correspondence is imscriptive (dynamical, R∧W∧X, lossless)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2df909c9-a04e-4a42-8433-903523348079
---

Avoid the word **holographic** unless the thing *actually is* holographic — i.e. it
entails a **redundant** encoding as a bulk-boundary correspondence (AdS/CFT,
quantum error-correcting codes, where the boundary redundantly carries the bulk).

The Grammar's correspondence is **imscriptive**, not holographic: it is **dynamical
and R∧W∧X** (read ∧ write ∧ execute), and **lossless**. See
[[project_imscribing_rwx_correspondence]]: encoding is W-only / lossy; imscription is
R∧W∧X / lossless.

**Why:** the two are near-opposites. Holography = redundant, static, boundary re-encodes
bulk. Imscription = minimal, dynamical, lossless active correspondence. Calling an
imscriptive structure "holographic" imports a redundancy that isn't there and misleads.

**How to apply:** default to "imscriptive correspondence" for Grammar bulk/boundary
(Crystal ↔ morphism-space) relations. Reserve "holographic" for genuine redundant
encodings. Worked example: a SIC-POVM is **minimal** (d² tight-frame elements, zero
redundancy) — so it is the opposite of holographic; it is a minimal lossless
imscription. The modulus |`z_k`|² is the W-only/**lossy encoding** (drops phase → small
field, decomposes); the coordinate `z_k` is the R∧W∧X **imscription** (keeps phase →
lossless, irreducible in the full field). Its non-factorability is *imscriptive
irreducibility*, not holographic wholeness. Sibling of [[feedback_imscribe_not_encode]].
