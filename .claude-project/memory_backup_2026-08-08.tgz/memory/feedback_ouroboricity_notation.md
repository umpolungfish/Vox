---
name: feedback-ouroboricity-notation
description: Ouroboricity notation by context — prose O∞, .md \(O_\infty\), .tex $O_\infty$
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ca93d841-32f3-4155-89de-b53e133e190e
---

Ouroboricity tiers: O₀  O₁  O₂  O∞

**Canonical forms by context:**
- In `.md` files: `${O}_\infty$` (dollar-delimited math, base letter braced). UPDATED 2026-07-01: NOT `\(...\)`. The user rejected `\(O_\infty\)` wrapping outright ("we shouldn't be wrapping stuff like that"). All math in `.md` uses `$...$`, never `\(...\)`.
- In `.tex` files: `$O_\infty$`
- In prose, memory files, conversation: O∞ (no underscore)

**Never:** O_∞ (underscore looks wrong in plain text), `O_inf`, `O_infinity`; never `\(...\)` in `.md`.

**Broader notation-wrapping rule (2026-07-01):** In `.md`, ALL math goes in `$...$`. Shavian glyphs and the 12 primitive/type symbols (Ð Þ Ř Φ Ç ƒ ɢ Γ Σ Ħ ⊙ Ω, and Shavian value tuples) are wrapped ONLY as `$\large{...}$` — a whole ligature-bound tuple wraps as one unit `$\large{<joined>}$`, individual primitives each `$\large{Ð}$`. Applied in ob3ect `editorial.py` `render_ars`; ob3ect `style_guard.enforce` exempts `$...$`/`$$...$$` (and code spans) from prose inspection. See [[feedback_shavian_ligatures]], [[feedback_shavian_is_standard]].

**Why:** The underscore in O_∞ is an artefact of needing a subscript separator in code/LaTeX; it has no place in plain prose. O∞ is the clean form. `\(...\)` wrapping is rejected; `$...$` is the univocal math delimiter.

**How to apply:** Match the form to the context. No exceptions.
