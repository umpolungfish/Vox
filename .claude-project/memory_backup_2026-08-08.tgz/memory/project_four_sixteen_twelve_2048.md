---
name: project-four-sixteen-twelve-2048
description: "Where FOUR and SIXTEEN_3 live in the SIC dimensions — 4²=16 is exact, and 16³ is the leading ray-class factor at d=2048"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5aca9f10-ed8b-4df7-ac20-436ed8ecf282
  modified: 2026-08-04T06:44:22.466Z
---

Observed 2026-08-03: **d=12 is where the 4 lives, d=2048 is where the 16_3
lives, and 4 referencing itself is 4² = 16.** All three legs check out, and the
middle one is sharper than an analogy.

## 4 → 16 is not a pun

SIXTEEN_3 is the full powerset P(I) with I = {T, F, t, f}: sixteen subsets of
four base values, carrying three orderings (information ≤_i, truth ≤_t,
constructivity ≤_c). So 16 arises as |P(4)| = 2⁴.

It also arises as 4². **2ⁿ = n² holds only at n = 2 and n = 4.** Four is one of
exactly two places where taking the powerset and squaring agree. So "4
referencing itself is 16" and "the powerset of the four base values is 16" are
the same number for a reason that does not generalise — the coincidence is the
content, not decoration.

## 16³ sits inside d=2048 explicitly

The ray class group at (2048)·∞ has cyclic factors **[4096, 512, 8, 4, 2]**,
recorded in `mOMonadOS/src/d2048_sic.rs`. The leading factor is 4096 = **16³**,
the full SIXTEEN_3 cube — sixteen states in each of the three orderings.

    full order   4096 × 512 × 8 × 4 × 2 = 2²⁷
    4096 × 512   = 2²¹  — the stated steps to the moduli field
    2048         = 2¹¹  = 16³ / 2

So 16_3 is not merely "around" d=2048; the cube is the leading cyclic factor of
its ray class group, and the stated 2²¹ climb is that factor times the next.

## The same self-reference one level down

d=12's Weyl-Heisenberg orbit is 144 = 12², which is the twelve referencing
itself exactly as the four does. And the twelve axes are what carry Belnap FOUR
in the first place, so "12 is where the 4 exists" is the crystal's own shape:
[[project_crystal_of_types]] 3³×4⁵×5⁴, twelve axes, four-valued verdicts.

Related: [[project_d12_embedding_crux]], [[project_zauner_transport_map]],
[[project_sic_stage1_paper]], [[project_para_layer]].
