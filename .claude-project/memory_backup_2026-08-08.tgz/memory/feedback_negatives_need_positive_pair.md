---
name: negatives-need-positive-pair
description: "In agent briefs/prompts, positive instructions may stand alone; any negative (MUST NOT, do not) must be paired with its positive complement"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 64b0268e-5cba-4c28-bb68-6452f4e105ec
---

When writing briefs, prompts, or instruction sheets for agents: positive
instructions can go uncoupled, but a negative reinforcement (e.g. "You **MUST
NOT** X") must always come paired with the corresponding positive complement
(what to do instead).

**Why:** in the user's words: a negative instruction without the complement is
"you're fucking up" without "here's how to not fuck up". A bare prohibition
leaves the agent at a wall with no direction; the paired positive is the door. Related: [[no-ai-framing]],
[[golem-operator]], [[jam-lean-operation]].

**How to apply:** for every "do not X" in a brief, write "do Y; do not X" or
"X is done by Y, never Z". Audit briefs for unpaired negatives before
submission.
