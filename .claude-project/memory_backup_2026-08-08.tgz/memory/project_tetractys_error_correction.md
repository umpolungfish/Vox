---
name: project-tetractys-error-correction
description: Tetractys protocol and dual-imscription error-correcting metric — how the grammar validates and self-corrects imscriptions
metadata: 
  node_type: memory
  type: project
  originSessionId: 82b5f61d-cbe5-43f5-94e8-c33a1cbd6d68
---

The grammar has a formal error-correcting mechanism built into the imscription process. Two related components:

## Dual Imscription (the "two ways")

Every system can be imscribed in two structurally distinct routes:
- **Holistic**: top-down, treating the system as a unified whole
- **Compositional**: bottom-up, assembled from tensor products of components

**Conflict distance:** $d_c = \sqrt{|\text{conflict set}|}$ — the gap between the two encodings.

Veracity classes:
| Class | $d_c$ | Meaning |
|-------|-------|---------|
| Transparent | 0 | holistic = compositional; fully grounded |
| Near-grounded | $\sqrt{1}$–$\sqrt{2}$ | one or two localized emergence claims |
| Partial emergence | $\sqrt{3}$–$\sqrt{6}$ | multiple unresolved mechanism claims |
| Aspirational | $\geq \sqrt{7}$ | claims largely exceed construction |

Each conflicted primitive = an explicit, falsifiable emergence claim. Either find the mechanism or revise downward.

## Overdetermined Composition Test

Both candidate imscriptions (holistic, compositional) are composed with **overdetermined catalog entries** — entries like `on_water_interface` (21 confirmed additive decompositions) that have dense consistency constraints from multiple independent paths. Outputs that violate known structural properties are **nixed**. The surviving candidate is accepted.

## Tetractys Protocol (three winds)

Extends dual imscription to three independent trials:
- Wind 1: informed by prior knowledge/context
- Wind 2: de novo, stripped of context  
- Wind 3: de novo, independent of Wind 2

If all three agree → catalog accepts.
If they disagree → justify each conflict primitive by primitive, naming correct value and why.

*"The grammar does not accept a type on a single vote."* — `twelve_gates_poem`.md §"The Tetractys"

## Combined Error Floor

A wrong imscription must simultaneously fool: holistic, compositional, 2–3 independent de novo trials, AND every overdetermined catalog entry. At 0.01% lattice occupancy with the catalog's algebraic constraints, this is structurally impossible for a systematic error.

**Sources:** `IG_DIAPHORICS`.md §LIII (holistic/compositional, $d_c$, veracity classes); markdown/poetry/`twelve_gates_poem`.md §"The Tetractys — Three Winds, One Truth"

**How to apply:** When explaining why imscriptions are reliable, or when discussing the grammar's self-correcting properties, reference these mechanisms. The Tetractys is the formal protocol; the overdetermined composition test is the discriminant when winds conflict.
