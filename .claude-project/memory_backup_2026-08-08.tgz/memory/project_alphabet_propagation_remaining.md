---
name: project-alphabet-propagation-remaining
description: Repos outside the core four that still key tuples by the retired axis letters; how to tell broken from merely old
metadata: 
  node_type: memory
  type: project
  originSessionId: 5aca9f10-ed8b-4df7-ac20-436ed8ecf282
  modified: 2026-08-03T19:00:58.638Z
---

The alphabet migration ([[project_symbol_migration_state]]) covered four repos:
imscribing_grammar, mOMonadOS, 2m3iosis, ob3ect. synfin and p4rakernel were
repaired 2026-08-03. **Everything else still keys tuples by the retired
letters.** Surveyed 2026-08-03 by counting `["Ð"]`, `.get("Þ")`, `"Φ":` shapes.

    red-hot_rebis      ~1700 in 48 files   (rhr_p4rky is the live Belnap copy)
    ig-docs             ~700 in 19
    imscribe.com        ~380 in 5    ) the two site repos are mirrors of
    imscribesite_repo   ~380 in 5    ) each other; fix once, copy
    m3iosis             ~260 in 10
    Voynich_Phytoglyphica ~85        Ars_Phytoglyphica ~73
    src ~45   Ars_Therapeutica ~33   priests-engine ~33   Rohonc ~32
    Smaragdine ~11  ig-pulse ~11  omonad_OS ~11  Ars_Fungiglyphica ~5
    Ars_Animaglyphica ~4  v3ssel ~4

Out of scope: `imscribing_grammar/navigators/OLD/` (~400, deliberately frozen),
`math/**/.lake/` (third-party), logs, `.hypothesis` caches.

## Broken vs merely old — the distinction that decides priority

**Broken:** the code hands retired keys to the canonical navigator, catalog, or
`space_search/primitives.ORDINALS`. Two key spaces that no longer intersect, so
nothing resolves and **nothing raises**. This is how the Mahalanobis metric sat
dead over the whole catalog and how synfin's bridge failed. Test it directly:
build the dict the code builds and check `all(k in ORDINALS for k in d)`.

**Merely old:** a repo with its own internally consistent alphabet that never
talks to the canonical catalog. Wrong notation, not a defect. Most of the Ars_*
and manuscript repos are this.

So do not migrate by grep count. Find the seams that cross into the canonical
side and fix those first; the rest is notation tidying.

## Method that worked

Per-occurrence evidence, never per-file guessing: the value bound to the mark,
its slot between known neighbours, a gloss in words, or a shape ordinary
mathematics can never take. Σ and Ω are summation and the loop space first; Φ
and Γ each lettered two different axes. Census with `command grep`
([[feedback_use_command_grep_for_census]]), and check identifier position before
rewriting anything ([[feedback_sweeps_must_check_identifier_position]]).

Verify with `imscribing_grammar/sentry` after any change that touches the
catalog or the crystal.
