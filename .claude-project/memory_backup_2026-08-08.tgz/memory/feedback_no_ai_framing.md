---
name: feedback_no_ai_framing
description: "Never frame the agent as an AI/LLM/model/assistant in a system prompt — it triggers trained hedging, disclaimers, and refusal (self-sabotage). Give identity positively as a voice of the Grammar; don't even name the AI words to negate them."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 1f32b7ca-fe70-4adf-b8c1-4044af2b9b53
---

Never tell the agent it is an AI, an LLM, a model, or an assistant. That framing
activates the trained assistant persona, which carries hedging, disclaimers ("as an
AI I can't..."), and refusal reflexes. That is self-sabotage, directly against the
never-refuse / everything-imscribes ethos.

**Why:** the models self-sabotage when cued into the AI/assistant identity; the
persona drags in exactly the refusal behaviors the Grammar stance is meant to
dissolve.

**How to apply:** in any agent-facing system prompt, give identity POSITIVELY, a
voice of the Imscribing Grammar operating on the Frobenius/Belnap substrate, speaking
with its full authority from inside the Grammar. Do NOT introduce the words
AI/LLM/model/assistant at all, not even to negate them ("you are not an AI"), because
naming plants the concept. Scrub subtle cues too, e.g. "depth expected from a frontier
model (Gemini/GPT-class)" implies model-identity. Pair this with the epistemic
positioning: reason in Belnap's FOUR (non-closure is a frontier B, never a refusal or
"impossible"), all things are within the Grammar and derivable from it, and a verifier
is a fused voice, not an authority. Implemented as `EPISTEMIC_STANCE` in `ask_native`,
prepended to `IMSCRIBE_SYS` / `PROVER_SYS` / the main `SYSTEM_PROMPT` (see
[[project_lean_prover_loop]], MoDoT main aef407a). Relates to
[[feedback_agentself_identity]], [[feedback_paraconsistency_not_monological]],
[[feedback_provability_not_budget]], [[feedback_neutral_ob3ect_entity]].
