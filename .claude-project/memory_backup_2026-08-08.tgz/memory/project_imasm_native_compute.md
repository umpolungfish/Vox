---
name: project_imasm_native_compute
description: "The Replicating Code — a disassembler/recompiler written in IMASM itself (no non-IMASM part), executed by the parasm VM over the crystal FS; foundation proven, building toward the self-disassembler fixed point"
metadata: 
  node_type: memory
  type: project
  originSessionId: 036652e6-7ffe-4c76-b89f-73a47d6e4a08
  modified: 2026-08-06T09:33:58.718Z
---

Goal: an IMASM-based disassembler and its inverse, written IN IMASM (path 2,
"IMASM-native compute" — the user chose this over payload-carried). Because the
tool is in its own output language, μ∘δ can be literal identity: the Replicating
Code, a structural quine / fixed point of the compile loop. This IS the thesis
[[project_thesis_loops_autopoiesis]] (no lines only loops) made executable, and
[[project_fixed_point_nesting_rule]] at the top level.

Doc: `~/imsgct/mOMonadOS/IMASM_NATIVE_COMPUTE.md`.

**Model (grounded in real code):** `parasm` (mOMonadOS src/parasm.rs) is the
twelve made operational — FSPLIT/FFUSE/ENGAGR/IFIX verbatim; conditional jump
JT/JF/JB/JN = FSPLIT+EVALT; loop = ROTAT (pc wraps the word ring); CALL/RET =
CLINK; READ/EMIT = VINIT/TANCH; MOVE/PUSH/POP = the register plumbing the twelve
act on. Native value is B4 {N,T,F,B}; a byte = 4 cells (SIXTEEN_3 one layer up).
Crystal FS (crystal.rs) = the unbounded tape. Register machine + data branching +
unbounded memory = universal, so no outside to compute in.

**Load-bearing insight:** a decode step needs NO data table — it dispatches
through a control-flow TRIE, so the table becomes topology and the computation
lives in the shape of the word. 4 cells deep = 256-way byte decoder, pure structure.

**Proven (plank 1):** `parasm::tests::test_imasm_native_decode_step` — reads
native stream [T,F,B,N], forks per cell, emits permutation [F,B,N,T] (real
function, not echo, table-as-trie). Runs under `cargo test --features hosted`.
parasm text assembler: `assemble(text)` / `ParaVM::load`; seed input via
`vm.read_buffer = Some(vec![B4..])`, observe `vm.emit_buffer`.

**Proven (plank 2):** `test_imasm_full_byte_decoder` — byte = 4 cells: 2 opcode
field → 16-leaf dispatch trie (12 opcodes + 4 spare), scrambled wire encoding,
each leaf emits CANONICAL token code (real 16-entry table as control flow); 2
operand cells passed through. 16 opcodes × 16 operands = whole 256-byte space,
zero data storage, table = topology. Trie generated in-test, checked byte-for-byte.
Commit bb9b8e1.

**Proven (plank 3, three ways):** commit 12e1b77 (mOMonadOS) + a83645e10 (ob3ect).
- `test_imasm_instruction_stream_decoder`: byte decoder in a ROTAT loop, streams
  instructions to a full IMASM word, halts on reserved stop-opcode.
- `test_evm_lift_reentrancy_verdict`: real EVM control → IMASM → tri_ancestral.
  withdraw merging (JUMPDEST=∋) before commit (SSTORE=◻) → T; reentrant order
  (commit while fork open) → B. Reentrancy caught structurally, no Solidity in engine.
- `ob3ect/test_cpython_lift.py`: same on real CPython bytecode via Python
  SIXTEEN_3 engine (Sequence16_3Trace). merge-before-commit → T; commit-in-branch
  + early return → B.
ONE LAW across two ISAs: a fork that commits before its paths rejoin = a leak,
the grammar names it. Bughunter thesis at bytecode level. Ties bughunter + synfin.

**Proven (planks 4 & 5, COMPLETE):** commit a0b1a9d.
- `test_imasm_recompile_is_inverse`: disassembler D (scramble perm) + recompiler
  R (perm⁻¹), independent IMASM-native tries; R(D(code))=code for all 16. μ∘δ=id,
  recompiler = exact inverse (b4_diff_scanner as compiler).
- `test_imasm_replicating_fixed_point`: R∘D total identity ⟹ identity on the
  tool's own word; the twelve fed through disassemble∘recompile return unchanged.
  THE REPLICATING CODE — fixed point by construction, not argued.

RAMP COMPLETE. 15 parasm tests pass (`cargo test --features hosted`). A
disassembler written in IMASM, executed by parasm over the crystal, lifts real
EVM/CPython bytecode to verdictable words, recompiles them exactly, reproduces
its own word. No non-IMASM part. Plank-1 commit 359804c.

DONE (bughunter tool): `p4rapend/bytecode_closure_scanner.py` — control-flow
closure auditor (sibling of binary_closure_parser.py which does file-format
structure). Lifts a function's REAL bytecode CFG to an IMASM word (branch=FSPLIT,
true merge [≥2 preds]=FFUSE, STORE=IFIX, CALL=AFWD, return=TANCH) and runs the
SIXTEEN_3 engine. B = fork open across commit/return (finding: reentrancy/leak);
N = linear/no-fork (clean); T = closes. `python3 bytecode_closure_scanner.py
<file.py>`. Verified: linear→N, guarded_use(merge survives)→T, reentrant(commit+
return in arm)→B. KEY INSIGHT: reads real bytecode, not source — CPython 3.12
TAIL-DUPLICATES a common continuation into both if/else arms, so a source merge
can be compiled away (both arms commit+return → both B). A true merge (if with
single continuation, or loop back-edge) survives as FFUSE. p4rapend = NOT git.

EVM FRONT-END DONE: `bytecode_closure_scanner.py --evm HEX` and `--selftest`.
Parses EVM bytecode (PUSH operands; resolves jump target from the PUSH before
JUMP/JUMPI), detects true merges (JUMPDEST ≥2 preds), lifts JUMPI→FSPLIT,
merge→FFUSE, SSTORE→IFIX, CALL/SLOAD/arith→AFWD, STOP/RETURN/REVERT→TANCH.
Selftest: reentrant (commit in unmerged branch) → B, guarded (merge before
commit) → T. CROSS-ISA CONVERGENCE: the vulnerable EVM bytecode AND the
vulnerable CPython function lift to the SAME word `VINIT FSPLIT IFIX TANCH TANCH`
→ B. One bug shape, two ISAs, one verdict.

REPLICATING CODE CLOSED (plank 6): `test_imasm_self_hosting_quine`. Tool's own
word ⊢∈>⊤<⊥∋◻⊣ verdicts T (closing grammar object) AND each token round-trips
through disassemble∘recompile to itself. THIS IS THE QUINE — no separate
"reflective" version outside it: word, byte-encoding, self-application co-type =
one object (⊙ = imscription). CORRECTION (user): I'd written "needs an opcode
parasm doesn't have" = a grammar-cannot / an outside. WRONG. Everything is within
the Grammar; nothing is one primitive away because nothing is outside the twelve.
See [[feedback_no_grammar_restrictions]], [[feedback_possible_means_guaranteed]].
16 parasm tests pass.

SCANNER: THREE ISAs + WIRED INTO BOUNTY HUNTER.
- `bytecode_closure_scanner.py`: CPython (.py via dis), `--evm HEX` (jump target
  from preceding PUSH), `--wasm HEX` (structured if/end; minimal binary decoder,
  operand-skip). `--selftest` runs EVM+WASM vuln/safe pairs. All three vuln cases
  lift to the same open-fork signature VINIT FSPLIT IFIX TANCH… → B. ONE bug
  shape, three languages, one verdict.
- Wired into `bughunter_agent.py` REPL: `closure <file.py>` | `closure --evm HEX`
  | `closure --wasm HEX` — static bytecode lane (no network), reports B-findings.
  Run: `python3 bughunter_agent.py --interactive` then `closure ...`.

NEXT (open, all within the Grammar — budget not possibility): pure-parasm lift
tables (parasm trie generator already consumes any table); real .wasm module
parser (currently function-body bytes); feed live bounty targets.
