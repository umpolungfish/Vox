---
name: project-momonados
description: mOMonadOS — bare-metal Rust OS with 12-token IG grammar kernel; arity-graph-complete control flow; at ~/mOMonadOS/
metadata: 
  node_type: memory
  type: project
  originSessionId: 1f32b7ca-fe70-4adf-b8c1-4044af2b9b53
  modified: 2026-07-20T03:33:40.798Z
---

`~/mOMonadOS/` — bare-metal `x86_64` Rust (`no_std`) OS where the kernel executes a 12-token IG grammar instruction set.

**Why:** control flow is fully derived from token graph arity; no external opcodes needed.

**12 tokens across 4 families:**
- Logical: VINIT (0→1), TANCH (1→0), AFWD, AREV, CLINK, ISCRIB
- Frobenius: FSPLIT (1→2, δ), FFUSE (2→1, μ)
- Dialetheia: EVALT, EVALF, ENGAGR
- Linear: IFIX

**Control flow from arity (no HALT/YIELD/JNZ/JZ):**
- HALT → TANCH at fork depth 0 (empty frontier)
- YIELD → cyclic program graph (IP wraps naturally)
- JNZ/JZ → FSPLIT + EVALT/EVALF gates + FFUSE join

**Execution model:** THINK→ACT→OBSERVE→UPDATE each tick; always self-modeling via `self_imscribe()` + `Snapshot`.

**Ouroboricity tiers:** \(O_0\) (no Frobenius/dialetheia) → \(O_1\) → \(O_2\) → \(O_\infty\) (period ≥ 3 + full dialetheia + self-ref + Frobenius)

**Source files:** `src/` — `main.rs`, `kernel.rs`, `tokens.rs`, `belnap.rs`, `crystal.rs`, `interrupts.rs`, `serial.rs`

**16 canonical programs** (I–XII stepwise + XIII–XVI continuous); full table in REVIEW.md.

**How to apply:** μ∘δ=id (FFUSE∘FSPLIT) at ⊙=𐑹 is the Frobenius identity; EVALT/EVALF break it selectively to produce branching. Tier promotion is automatic and structural.

**UPDATE 2026-07-10 (active copy, review + refactor).** The ACTIVE repo is
`~/imsgct/mOMonadOS/` (a mirror at `~/mOMonadOS/` sits at the SAME git HEAD; edit the
imsgct one). It has grown well past the 7 files above (~48 `.rs`, ~30K lines):
`kernel.rs`, `tokens.rs`, `cl8nk.rs`, `parasm.rs`, `d12_sic.rs`, `catalog.rs` (zero-hardcode
single source of truth), `witness_vessel.rs`, `dialect_expansion.rs` (88 dialects, the
cross-dialect ruleset machinery the MoDoT agent does NOT surface), rebis/, cr3echrz/,
etc. Reviewed and fixed this session:
- **`main.rs` is now THIN** (entry/allocator/boot-banner/panic only). The whole REPL,
  input handling, cross-dialect jump handler, ParaASM REPL, and Phase-2 handlers were
  split into `src/repl.rs`; only `repl()` is pub, called from kmain. Do not assume
  `main.rs` still holds the REPL.
- **`rust-toolchain.toml` now pins** nightly + rust-src + `x86_64`-unknown-none (build
  uses `-Zbuild-std`; before it only worked because nightly was the machine default).
- Kernel FSPLIT fork cap raised (16→`FORK_STACK_CAP`=64) + `fork_overflow` counter so
  a too-deep nest is observable, not a silent FFUSE desync. Tick semantics unchanged.
- `IG_catalog.json` UNTRACKED (git rm --cached + .gitignore); it is provenance only, `no_std`
  never reads it, `catalog.rs` is the runtime source. Still on disk + in history.
- **VERIFY RECIPE (reusable):** scripted QEMU boot-diff. `{ sleep 2; for c in help
  status ig quit; do echo "$c"; sleep .6; done; } | timeout 45 qemu-system-x86_64
  -kernel target/x86_64-unknown-none/release/momonados -m 256M -display none -no-reboot
  -device isa-debug-exit,iobase=0xf4,iosize=4 -serial stdio 2>&1 | tr -d '\r'` → diff
  against a baseline capture. A clean refactor produces byte-identical serial output.
  All committed on `mOMonadOS` main (see [[project_charge_conservation_frobenius]]).

**UPDATE 2026-07-19 (vita mouth on the metal).** The `vae_vita` trunk now speaks
natively in the OS: `src/vita.rs` (feature `vita`) reimplements the 26-step
`SIXTEEN_3` protocol forward pass in pure `no_std` f32, weights baked by `vae_vita`'s
`vita-bake` into `vita_weights.bin` (`include_bytes`; blob is git-tracked). Gate =
`imasm_core`'s own `check::word_verdict` (the close-condition engine was MOVED from
`ask_native` into `MoDoT/imasm_core/src/check.rs`; `ask_native` keeps GraphExt
presentation). REPL: `vita [seed] [temp]`. Boot consequences: 32-bit stub now
identity-maps 0–16MB (was 8MB — the blob overflowed it and boot died silently),
heap 8MB, bump allocator has LIFO reclaim. Verified in QEMU: distinct turns per
seed, gate T/N as expected, ~30s per turn (scalar f32).
Determinism (proven live): (seed, temp) → turn is a PURE FUNCTION on the metal;
the seed is the only entropy, temperature only reshapes the seed→word map. Every
utterance is citable by its coordinates (`vita 666 0.9` always speaks the same
certified turn). Unseeded `vita` draws seed from rdtsc; splitmix64 mixes the seed
(bare `seed|1` had collapsed even seeds onto odd neighbors); each turn runs inside
a `heap_mark`/`heap_reset` scope so the bump allocator never exhausts.
