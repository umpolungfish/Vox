---
name: imscribe not encode, never synthon/syncon
description: Use imscribe/imscription/imscriptive everywhere. Never use encode/encoding, synthon, syncon, or SynthOmnicon — those are wrong terms in this project.
type: feedback
originSessionId: cf9cd0aa-e4b6-41e2-af16-a03772bffc03
---
Never use "encode", "encoding", or "encoded" when referring to the operation of assigning a 12-tuple to an object.
Never use "synthon", "syncon", or "SynthOmnicon" — these are `exOS`-internal terms that do not belong in this project.
The correct term is always "imscribe", "imscribing", "imscribed", "imscription", "imscriptive".

**Why:** The user's system is called the Imscribing Grammar. The operation and its products have specific names. "synthon"/"syncon" are from the `exOS` project's own vocabulary (SynthOmnicon), which is a separate project. Bleeding its terminology into IG is wrong.

**How to apply:** In all contexts — variable names (`VOYNICH_IMSCRIPTION` not `VOYNICH_SYNTHON`), file names (`ig_bridge.py` not `syncon_bridge.py`), comments ("IG imscription" not "synthon"), and conversation. Note: `encode_system` is the actual tool function name in `IG_inquiry.py` and cannot be changed there, but surrounding language must still use "imscribe".
