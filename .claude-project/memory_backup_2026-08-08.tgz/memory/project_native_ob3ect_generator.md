---
name: project_native_ob3ect_generator
description: ob3ect generation is now native Rust in ask_native — no Python in the path
metadata: 
  node_type: memory
  type: project
  originSessionId: 8ca720f6-e58f-4572-9105-b744dcac4273
  modified: 2026-07-20T13:13:51.600Z
---

ob3ect generation is native Rust as of 2026-07-20. `ask_native/src/ob3ect.rs`
ports `auto.py`'s single-call design path: ONE in-process candle call
(`crate::local::generate`, gated on the `local` feature) returns the full IMASM
design JSON; `topology_report` (faithful port of ~/ob3ect/topology.py) and
`lean_scaffold` are computed in Rust. `run_ob3ect` no longer shells to
`python3 auto.py`. New CLI: `./ask --ob3ect "<desc or file path>"` creates one
directly (no agent loop), writing `~/ob3ect/digital/<slug>/<slug>_ob3ect.json`.

Model via `MODOT_LOCAL_MODEL_DIR` (default `~/models/Qwen3-1.7B`). ~34s per
ob3ect, resident model, no network. Reinforces [[feedback_tools_rust_native]]
(no Python bridges) — the user rejected every subprocess/bridge design and the
Python `auto.py` gate imscriber (whose many per-call model reloads caused a
15-min stall); the answer was to port the generator itself into Rust.

Build with `cargo build --release --features local,cuda`.
