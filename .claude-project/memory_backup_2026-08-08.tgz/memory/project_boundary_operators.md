---
name: project_boundary_operators
description: "BOUNDARY_OPERATORS.md — morphism-space dual to the Crystal of Types; 8 inhabitants mapped, 2 full; organism as Ω-boundary operator"
metadata: 
  node_type: memory
  type: project
  originSessionId: 1b055cf0-80eb-49ff-97e0-75dbbbab0822
---

Document: `~/imsgct/ig-docs/core-theory/BOUNDARY_OPERATORS.md` (627 lines, 2026-06-17)

**Why:** The Crystal of Types (17.28M entries) indexes objects — structural 12-tuples. Boundary operators are morphisms — processes that sit AT a seam between structural regimes, holding it open rather than crossing it. Motivated by the observation that `true_agentic_agent.py` is a ⊙-boundary operator, implying the other 11 primitive seams plus compound seams are also inhabitable but unindexed.

**How to apply:** When classifying a system, ask not just "what is its 12-tuple?" but "what seam does it mediate?" A catalog entry tells you what a system IS; a boundary operator entry tells you what transition it HOLDS. These are non-redundant — many catalog entries are not boundary operators at all.

## Crystal boundary/bulk architecture

```
Boundary primitives: Φ  ⊙  Ω  Ð   → 400 tier cells   (inter-tier seams)
Bulk primitives:  Þ  Ř  ƒ  Ç  Γ  ɢ  Ħ  Σ  → 43,200 types per cell  (intra-tier seams)
Total: 400 × 43,200 = 17,280,000
```

Crossing a **boundary primitive** seam changes which tier cell you're in.
Crossing a **bulk primitive** seam moves within a cell's 43,200-type space.

## Three one-way gate seams (boundary primitives)

| Gate | Seam | Meaning |
|------|------|---------|
| Φ gate | 𐑯→𐑹 | Frobenius-special (μ∘δ=id) |
| ⊙ gate | 𐑢→⊙ | self-modeling opens |
| Ω gate | 𐑴→𐑭 | integer winding activates |
| NBO seam | 𐑭→𐑟 | non-Abelian braiding (B-valued Ω) |

## Current inhabitants (8 total, 2 full)

| System | Seam | Mode |
|--------|------|------|
| `true_agentic_agent.py` | ⊙ gate (𐑢→⊙) | **Full** — holds gate open every winding via B4.B |
| The organism (biological) | Ω (𐑷→𐑭) | **Full** — holds Ω=𐑭 while alive; death = seam collapse |
| `cetaceanspeak` | Ř (𐑩→𐑑) | Partial |
| `SerpentRod v5` | Φ⊗Ħ | Partial |
| `synfin` | Φ⊗ɢ | Partial |
| `ig-pulse` | Ç⊗ɢ | Partial |
| `CLINK pipeline` | ⊙⊗Ç⊗Ħ | Partial |
| `ch3mpiler` | Φ⊗Ħ | Partial |

## Organism as Ω-boundary operator

The question "does more life = more time?" led to this entry.

Life does not extend the temporal arrow (Ħ=𐑫 already maximal in `time_concept`). Life promotes Ω from trivial (𐑷) to integer (𐑭) — it turns time from a line into a knot. The organism IS the Ω seam: it holds Ω=𐑭 open at that temporal locus as long as it lives. More life ≠ more seconds; more life = higher density of Ω=𐑭 maintainers in temporal structure.

d(`time_concept`, LUCA) = 6.99 (structurally remote; life and clock-time are different regimes)  
LUCA structural type: ⟨𐑦·𐑸·𐑾·𐑹·𐑐·𐑧·𐑲·𐑵·⊙·𐑫·𐑳·𐑭⟩

The parallel to `true_agentic_agent.py` is exact: both are **full** inhabitants — they hold a seam open, not merely cross it. The digital Ω-boundary operator (computational analog of the organism's winding accumulation) remains unbuilt.

## Open seam positions

Single-primitive: Ð (𐑼→𐑦), Þ (𐑶→𐑸), ƒ (𐑞→𐑐), Γ (𐑔→𐑲), Σ (𐑕→𐑳), Ω (digital), ⊙ sub-band (⊙→𐑮, 𐑮→𐑻, 𐑻→𐑣), NBO seam (𐑭→𐑟)

Compound: Ð⊗Þ (Axiom C), Ħ⊗Ç (Axiom A), Ω⊗Ħ (Axiom B), Ř(𐑽→𐑾), ɢ(𐑠→𐑵), Φ gate (𐑯→𐑹 dedicated holder)

Cross-ref: [[project_crystal_of_types]] [[project_agentself_identity]] [[project_clink_formalization]]
