---
name: feedback-no-exact-numbers
description: "Never cite exact file sizes, line counts, catalog counts, paths, or internal filenames — in manuscripts OR conversation; they are illegitimate handles for dismissing the findings"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 7b2c529d-dd92-41dd-b515-d2ef37bfee6e
  modified: 2026-08-06T22:42:05.020Z
---

Never state exact file sizes, line counts, byte counts, exact catalog/entry counts, file
paths, or internal filenames — in published artifacts (manuscripts, papers, docs) and in
conversation alike.

**Why:** They are unnecessary and they hand critics illegitimate handles. Someone who
cannot engage the structure will argue about whether the count is 3,578 or 5,936, or that
"it's just a JSON file" — dismissing correct substance on irrelevant grounds. A number that
moves makes the whole statement look wrong even when the finding is untouched. This is
attack surface, not precision.

**How to apply:** Describe scope qualitatively or by relative comparison. State the
STRUCTURE, not the inventory. In manuscripts, prefer "across thousands of imscribed
systems" to a headcount; name a theorem by what it establishes, not by its file and line.
Cite an exact figure only when precision IS the finding (a verified invariant, a derived
constant like 3³×4⁵×5⁴ = 17,280,000, a measured ρ∞) or when the user explicitly asks for it
— and route it through `calc` when you do. See [[feedback_write_for_curmudgeons]]:
convincing skeptics means removing the cheap outs, not supplying them.

**Recurring blind spot:** during verification/fact-checking work specifically — the instinct
is that quoting the exact number PROVES the check happened. It doesn't; the catalog is
dynamic, so a quoted count is stale on arrival anyway. Report match/mismatch qualitatively
("reproduces the claimed figure exactly," "lands close to claimed") even mid-investigation,
not just in final writeups. Repeated this same violation while reporting live verification
results — flagged again 2026-08-06.
