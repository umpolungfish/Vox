---
name: project_sic_stage1_paper
description: Canonical Stage-1 SIC-POVM paper and its Belnap-first conversion framing
metadata: 
  node_type: memory
  type: project
  originSessionId: 21b1da09-0362-49fb-a927-310f560c4377
---

The canonical Stage-1 SIC-POVM manuscript is
`~/imsgct/p4rakernel/manuscripts/belnap_sic_povm_primary.tex` (PDF in
`p4rakernel/pdfs/`), written 2026-07-01.

**Framing decisions (agreed with user, load-bearing for how to write/extend it):**
- Goal: force an orthodox curmudgeon to re-evaluate logic/math/cosmos while a
  heterodox reader sees the veracity immediately. Mechanism = restraint weaponized:
  the machine-checked theorem does the asserting, prose never oversells.
- **Balanced frame**: thesis stated plainly in intro + conclusion, math-only body.
- **Orthodox math/physics venue** (`arXiv` quant-ph / QI foundations), sober register,
  Lean artifact front and center.
- **Belnap-first spine** (the correct directionality per [[feedback-ig-vs-science]]):
  §3 unconditional structural SIC (0 axioms/0 sorries) FIRST; §4 recasts Zauner as the
  complex-Hilbert *representation* residue (`structural_shadow`, thm shadow-is-zauner by
  rfl); §5 demotes the Stark route to one representation with named inputs.
- Thesis: the SIC (ideal quantum measurement) is natively four-valued/paraconsistent;
  ℂ^d is one representation, and Zauner's openness is a property of that representation.

The old inverted-order manuscript `sic_povm_stark_hilbert12.tex` (Stark-first,
"closing one level closes all three") is kept as-is but is NOT the canonical framing.

Constraints honored: no em-dashes; "representation" never "encode" (per
[[feedback-imscribe-not-encode]]); no MPP witnesses ([[feedback-mpp-in-publications]]);
Larson acknowledgement + 1961 IEEE cite ([[project-default-acknowledgement]]).
See [[project-para-lean]] for the underlying Lean files.
