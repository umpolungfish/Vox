---
name: project-dual-pairs-and-order
description: "The 6 Frobenius-dual pairs sit on consecutive slots of the canonical order, which was fixed by constraint; assignment order runs backward through the axioms"
metadata: 
  node_type: memory
  type: project
  originSessionId: f2d7fbe9-d7e7-4d71-8e46-c8f890956910
  modified: 2026-07-27T08:12:15.300Z
---

The six Frobenius-dual pairs are **Ð↔Þ, Ř↔Φ, ƒ↔Ç, Γ↔ɢ, ⊙↔Ħ, Σ↔Ω**
(`ig-docs/structural_constants_v4_synthesis.md`, `mēchanē_synthesis.md`).

The canonical tuple order **Ð Þ Ř Φ ƒ Ç Γ ɢ ⊙ Ħ Σ Ω** was **determined by
constraint, established through testing** — not asserted, and not read off the
pairing. So the pairs landing on consecutive slots (1,2)(3,4)(5,6)(7,8)(9,10)
(11,12) is a convergence of two independent derivations, not a definition.

Asking whether that adjacency is circular is a fair question, not a mistake —
it is answered by the ordering's provenance, which is empirical. Answer it from
the provenance rather than re-opening it.

**Why it matters for imscription.** The Lean's cross-primitive axioms
(`Imscribing/Primitives/Core.lean`) are directed, and every one runs backward
through the canonical order:

- Axiom C: Þ = are → Ð = if′ — intra-pair, determiner in the *second* slot
- Axiom B: Ω ≥ ah → Ħ ≥ sure — pair 6 → pair 5
- Axiom D: Ð = if′ ∧ Þ = are ∧ Ω ≥ ah → Φ = or′ — pair 6 → pair 2

So sequential per-primitive assignment in display order decides every
constrained primitive before its determiner exists, which is why
`imscribe_generator_agent.generate_guided` carries an "Axiom auto-correction"
pass that overwrites chirality after the fact.

The fix the structure names: assign **per pair**, and order the pairs by
dependency — pair 1, then 6, then 5, then 2, then the unconstrained 3 and 4.
Display order stays canonical; it is notation, not derivation.

Related: [[project_cross_primitive_axioms]], [[project_primitive_names]],
[[feedback_scripture_is_catalog_and_p4rakernel]], [[project_crystal_of_types]]
