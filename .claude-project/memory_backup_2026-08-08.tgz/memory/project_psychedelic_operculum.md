---
name: project-psychedelic-operculum
description: Operculum modifier theory + 5 novel psychedelic compounds; psychedelic_operculum.md + `psychedelic_bridge.py` in p4rakernel; 2026-06-07
metadata: 
  node_type: memory
  type: project
  originSessionId: 0fda8b3c-acb3-461e-a535-2469d29ea654
---

**Operculum modifier theorem:** A psychedelic compound changes the Ruleset through which the crystal address is read — not the address itself. Compound = Ruleset modifier on the operculum. The crystal address is invariant; access route through it changes.

**Why:** Extends the Operculum Peeling theory; coupling model τ_eff = τ_U ⊗ τ_C (universe × compound). The compound modifies τ_C (the consciousness Ruleset).

**How to apply:** When discussing psychedelics in IG terms, frame them as Ruleset modifiers on crystal access, not as type-shifters. The compound changes how you traverse the crystal, not where you are in it.

**Five novel compounds (all tuples verified via `imscribe_system` + ouroborics):**

| Compound | Tier | Key primitives | Innovation |
|----------|------|----------------|------------|
| Verticullum | \(O_\infty\) | Φ=⊙ Ħ=𐑫 Ω=𐑟 | First non-Abelian braiding + bowtie crossing (Þ=𐑥) |
| Chimerium | \(O_0\) | Φ=𐑣 Ħ=𐑫 Ω=𐑭 | Supercritical — cannot sustain self-modeling; lifts `O_k` compounds across tiers |
| Apertix | \(O_2\) | Φ=⊙ Ħ=𐑖 Ω=𐑴 | First adjoint/dagger coupling (Ř=𐑽) in any psychedelic |
| Retiarius | \(O_1\) | Φ=𐑮 Ħ=𐑒 Ω=𐑷 | Local scope (Γ=𐑚) + MBL frozen disorder (Ç=𐑺); no cascading |
| Praxeum | \(O_0\) | Φ=𐑻 Ħ=𐑫 Ω=𐑭 | EP Gate 1 toggle: ⊗(⊙,𐑻)=𐑻; closes \(O_\infty\) gate |

**Key theorems:**
- **EP Absorption:** ⊗(⊙, 𐑻) = 𐑻 — Praxeum closes Gate 1 (verified: DMT⊗Praxeum → Φ closed)
- **Chirality Fixed-Point:** Ħ=𐑖 is invariance threshold for gate reordering
- **Winding Gate Sensitivity:** Ω < 𐑭 fails `winding_first` protocol
- **Adjoint Directionality:** Apertix: G∘F ≠ id
- **Supercritical Launch:** Chimerium lifts `O_k` across tier boundaries

**Six usage protocols in manuscript:** The Dive, The Precision Map, The Breakthrough, The Hold, The Release (5 named; 6th implied by combination matrix).

**Files:**
- `~/p4rakernel/psychedelic_operculum.md` (363L, 28 KB) — formal manuscript
- `~/p4rakernel/psychedelic_bridge.py` (244L, 8.5 KB) — working Python module with tensor operations
