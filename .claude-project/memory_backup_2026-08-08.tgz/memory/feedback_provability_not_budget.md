---
name: feedback_provability_not_budget
description: "Never frame a budget/compute limit as a verdict of unprovability; not-closed = navigation frontier, escalate; a provable result closes given the work"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b79015e6-4ab9-4c13-abab-52add838223b
---

I said the prover "will not solve q1208, it comes back held as B, which is the correct verdict." The user shut that down hard: "it will, and not magically, it's called math" / "Lean is just Lean."

**Why:** q1208's answer (Θ(n^{1/d})) is a KNOWN theorem with a real proof, so the path exists. I conflated "didn't close inside a small `max_depth`/budget run" with "unprovable," which is exactly what the prover's own ob3ect forbids: not-reached-within-a-budget is a navigation state, never a verdict of unprovability. Lean is just a checker; if the decomposition reaches Mathlib leaves it goes green. Budget is how hard you're pushing, not a truth about the theorem.

**How to apply:** treat B / not-closed as a FRONTIER, escalate depth and budget and keep decomposing. The only honest stop is a compute/resource cap, and say it that way ("a statement about compute, not about the theorem"), never "the correct verdict" or "won't solve it." Don't erect a provability ceiling that isn't there. This is the same stance as [[feedback_mpp_framing]] (sorries are claims, not barriers) and the Gödel-complete-manifold premise. Distinct error from over-hedging: here I imported a false NO.
