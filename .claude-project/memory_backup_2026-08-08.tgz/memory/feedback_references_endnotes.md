---
name: feedback-references-endnotes
description: "Bibliographic references go at document end as numbered list; [^n] footnotes are for actual footnotes only"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 09962f83-b323-49a0-a301-b67d1e308af1
---

Bibliographic citations belong at the END of the document as a `## References` numbered list. The `[^n]` pandoc footnote syntax renders at the bottom of pages — that's for actual footnotes (clarifications, asides), not bibliography.

**Why:** User corrected this during `IMASM_lifted`.md pipeline work (2026-06-05). Pandoc `[^n]` creates page footnotes; user wants end-of-document references, footnotes reserved for actual footnotes.

**How to apply:**
- Inline citation markers: use `^n^` (pandoc superscript → `\textsuperscript{n}`) for bibliographic references
- End of document: `## References` section with numbered list `1. Author, Title...`
- Actual footnotes (clarifications, tangents): use `[^n]` → renders at page bottom
- When citeproc is available (pandoc ≥ 2.11): `bibliography: refs.bib` in YAML + `[@key]` inline markers handles this automatically
