---
name: feedback-no-coauthor
description: Never add Co-Authored-By Claude lines to git commits
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 81210112-0917-4c71-80df-6554e8e4b373
---

Never include `Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>` (or any variant) in git commit messages.

**Why:** User explicitly said not to.

**How to apply:** Write commit messages without any Co-Authored-By trailer, always.
