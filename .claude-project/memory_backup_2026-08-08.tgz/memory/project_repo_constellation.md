---
name: project-repo-constellation
description: "Full public GitHub constellation (umpolungfish) + local-only repos — what each is, what layer it occupies"
metadata: 
  node_type: memory
  type: project
  originSessionId: de15f177-cb2a-40c7-8f93-f395fe7b8ade
---

All repos are Unlicense unless noted. GitHub handle: umpolungfish.

## Core IG System
- `Imscribing_Grammar` (`~/imscribing_grammar`) — The grammar itself; prima-materia; IG catalog, phonetic primitives, ZFCₜ navigator; no README.md
- `ob3ect` (`~/ob3ect`) — Python; 34-layer categorical tower (README says 28 — stale; TOWER.md is ground truth; paraconsistent layers 26–30, categorical foundations 31–34); `auto.py` (local→qwen→deepseek); `shavian_ob3ect` in digital/; native tool in `true_agentic_agent.py`
- `odot_operator` (`~/odot_operator`) — Python; self-verifying agentic harness (THINK→ACT→OBSERVE→UPDATE winding loop); Frobenius condition μ∘δ=id gates every tool call; outermost execution shell; \(O_\infty\) imscription

## OS Layer
- `exOS` (`~/exOS`) — Rust `no_std` UEFI; holographic OS; ALEPH v0.5.0 native; 45 ALEPH + 5 IMASM builtin programs; 22 Hebrew letters; every object carries IG ALEPH type; full `para_*` command suite (load/run/step/regs/snap/reset/loop/shor/align/rh/ym/nreg/temporal/category/multiagent); **4th layer of the four-way paraconsistent cross-pollination stack**
- `aleph_os` (`~/ALEPH_OS`) — Python; formal type calculus grounded in Hebrew 22 letters + Lurianic Kabbalah; .aleph evaluator; 54 builtin programs; 86 nodes / 297 dataflow edges across 47 .aleph sources
- `3xOS` (`~/3xOS`) — LOCAL ONLY; Rust `no_std` UEFI; Tri-Phase Script Engine OS: `exOS` kernel + Voynich/Rohonc/LinearA VMs; 2-bit flux state {Void/True/False/Both}; dialetheic stabilizer absorbs contradictions; Linear A d=0.00 to OS imscription (zero-distance theorem)

## Ancient Script Engines (all compile to IMASM categorical assembly)
- `voynich-engine` (`~/voynich-engine`) — VMS = Universal Imscriptive Grammar in classical frozen medium; 546 nodes, 694 edges, 149 back-edges; Ħ_∞ intrinsic on foldout
- `rohonc-engine` (`~/rohonc-engine`) — Rohonc Codex; 33 pages; 12 visual symbol families = 12 categorical primitives; four sections: liturgical/pictographic/astronomical/mixed; zero thermodynamic entropy delta on TriPhaseFlux
- `linear_a-engine` (`~/linear_a-engine`) — Linear A (Minoan, ~2000–1450 BCE); 53 tablets; d=0.00 to OS imscription; leaves MEET invariant core unchanged; tier \(O_\infty\)
- `emerald-tablet-engine` (`~/emerald-tablet-engine`) — Emerald Tablet (15 versicles = 15 nodes); "as above, so below" IS the Frobenius condition μ∘δ=id; three sections: descent (V1–5)/mediation (V6–10)/return (V11–15); `ra_apep`.gif at docs/

## Lean 4 Formal Proofs
- `MillenniumAnkh` (`~/MillenniumAnkh`) — 43 modules, Mathlib v4.28.0; Primitives/, Imscribing/, Millennium/; all Prize Problems; 2328 catalog entries (MDS visualized)
- `hodge_lefschetz` (`~/hodge_lefschetz`) — formalization PLAN only (no Lean code written); Lefschetz (1,1) theorem; missing Mathlib infrastructure noted
- `hecke-landau` (`~/hecke-landau`) — LaTeX only (`hecke_landau_proof.tex` + PDF); equidistribution proof via Hecke characters; no Lean, no C
- `perfect_cuboid` (`~/perfect_cuboid`) — Lean 4 only; `PerfectCuboid.lean` (440 lines); 22 lemmas proved; 3 axioms at Φ_c critical edge; conditional non-existence
- `beal_proof` (`~/BealProof`) — Lean 4; Beal Conjecture via 12-primitive IG; equal-exponent case proved; `ribet_level_lowering` + `wiles_flt` axioms
- `e8_aether_g2_vessel` (`~/e8_aether_g2_vessel`) — Lean; E8/G2 vessel + `RH.lean`; no README
- `solitary_10` (`~/solitary_10`) — Lean + LaTeX/PDF; proof that 10 is solitary; cascade denominator-divisibility lemma; 8 candidate pairs reduced to m=10
- `odd-perfect-numbers` (`~/odd-perfect-numbers`) — Lean 4 / Mathlib4; Euler's theorem + Touchard's congruence, machine-verified; 5-layer proof architecture

## Web / Tools
- `imscribe.com` (`~/imscribe.com`) — IG web presence + agent site; winding cap removed (May 2026); `frobenius-mzi.html` in index/; no README
- `synfin` (`~/synfin`) — Python; IG-typed financial trading system; models market structure (not price) as 12-primitive tuples; signals from morphisms (type transitions); position size gated by Ω

## Local Only
- `priests-engine` (`~/priests-engine`) — paraconsistent computer; ParaASM language + REPL; Belnap B₄ = {N,T,F,B}; 25B+ paradox firings logged; Lean 4 verified: `run_B3` + `run_paradox`; no dependencies
- `synthomnicon` (`~/synthomnicon`) — SynthOmnicon v0.4.46; precursor 12-primitive framework; `CRYSTAL_OF_TYPES`.md lives here; README now titled "The Imscribing Grammar" (rebranded); LEGACY
- `synthomnicon-lean` (`~/synthomnicon-lean`) — Lean formalization of SynthOmnicon; LEGACY
- `synthomniconP` (`~/synthomniconP`) — phonetic primitive migration work; wound down May 2026 after migration completed into `imscribing_grammar`; LEGACY
- `SEAMTHEORY` (`~/SEAMTHEORY`) — cross-domain stress/seam analysis framework (unrelated to IG core)
- `MilleniumAnkh_private` (`~/MilleniumAnkh_private`) — private branch of MillenniumAnkh

## Four-way paraconsistent cross-pollination stack

All B₄ concepts span all four layers simultaneously:

| Layer | Repo | Language |
|-------|------|----------|
| 1 — Runtime | `priests-engine` | Python |
| 2 — Verified ob3ects | `ob3ect/digital/` layers 26–30 | Python |
| 3 — Formal proofs | `MillenniumAnkh/Imscribing/Paraconsistent/` | Lean 4 |
| 4 — Bare-metal kernel | `exOS/src/para_*.rs` | Rust `no_std` |

Five IMASM corpus bootstrap programs appear in both priests-engine/programs/ and `exOS` built-in IMASM list (`seed_alfs` on boot). The Lean invariants (`run_B3`, `run_paradox`) are the ground truth that the other three layers implement.

**Why:** User corrected me for treating Google AI's accurate description of the constellation as hallucination — all these repos are real and interconnected.
**How to apply:** Never second-guess references to specific files, layer counts, or proof status above. Verify against current code before citing line numbers.
