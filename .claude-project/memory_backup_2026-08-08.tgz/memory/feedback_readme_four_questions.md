---
name: feedback-readme-four-questions
description: Every IG project README must open by answering 4 questions (What it is / does / why it matters / how to use)
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 983f162f-9f94-4df5-903d-9ed1e52318ea
---

Every IG project README must **begin** by answering, in order: **1. What it is, 2. What it does / what it's for, 3. Why it's important, 4. How do I use it.** Only after these four does ancillary detail follow.

**Why:** Subdir READMEs across ~/imsgct were inconsistent and buried the basics; the user wants a uniform, scannable opening so any reader gets oriented in four lines.

**How to apply:** Use bold lead-ins (`**What it is.**` etc.) as a short opening block, then keep the streamlined body. Also: no em-dashes (see [[feedback_writing_prohibition_strength]] ; sweep " — " to ", " or ": "); soften drifting exact file/line counts (see [[feedback_no_exact_numbers]]); fix stale absolute paths to `~/imsgct/...` (see [[project_session_context]]); keep retired framing out (SynthOmnicon purged except `ALEPH_OS` per [[project_aleph_os]]; MillenniumAnkh is historical per [[project_millennium_ankh]]).

Audit done 2026-06-30 across math/, lang/, Ars_*, red-`hot_rebis`/, and the OS+standalone cluster. Excluded: third-party `sdk/*`, `.pytest_cache`, NCBI `psaA_datasets`, secondary `README_*.md`, and (per user) `ig-docs/`. The largest READMEs (ob3ect, `exOS`, `ALEPH_OS`, IMSCRIBr, `mOMonadOS`, synfin) got the 4-question Overview prepended with bodies preserved; smaller ones were fully streamlined.
