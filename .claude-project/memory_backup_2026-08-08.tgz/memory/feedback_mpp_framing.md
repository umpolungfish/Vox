---
name: feedback-mpp-framing
description: "MPP sorries are the grammar's original mathematical claims, not impossibility barriers — never frame them as \"cannot be discharged without original mathematical work\""
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f84fb4c1-7abb-4962-bed7-03ce0be89612
---

The MPP OpenProblem sorries ARE the original mathematics. The Imscribing Grammar is the proof methodology. When the user asks "where are we with the MPPs," they want to know how developed the structural argument is — not a sorry count treated as a ceiling.

**Why:** User explicitly corrected this framing twice. The `DONE_TODO`.md file contains the wrong framing ("cannot be discharged without original mathematical work") — do NOT reproduce it. The grammar derives the crossing condition from primitive axioms; formalizing that derivation in Lean is the remaining work.

**How to apply:** Whenever discussing MPP progress, frame sorries as "the structural claim the grammar is making" and "frontier of formalization," never as "wall" or "impossibility." The grammar asking the question already contains the answer.

Related: [[feedback-distill-to-optimal]]
