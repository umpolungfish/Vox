---
name: project_cetaceanspeak
description: cetaceanspeak repo — WAV whale vocalization to IMASM translation pipeline
metadata: 
  node_type: memory
  type: project
  originSessionId: c3278fd2-ff13-4ee8-a17a-9ff6a9a2f02c
---

`~/imsgct/cetaceanspeak/` — WAV file → cetacean vocalization translation via the IMASM compiler pipeline. A 38-second humpback recording produces 125 acoustic units, Frobenius closure ratio 1.0, ranked against six human expression archetypes via the Watkins database; closest match found was "song" (d=65.95). Real repo (`pyproject.toml`, `uv.lock`, `whale_audio.py`, `data/`). Ties to the same eight-step Frobenius loop used elsewhere ([[project_simulations_as_proofs]]). Not previously memory-tracked; discovered during the 2026-06-16 ig-docs triage.
