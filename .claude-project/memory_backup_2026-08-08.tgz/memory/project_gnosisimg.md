---
name: project-gnosisimg
description: "gnosisimg — 13 structural type cards, black-ground geometric diagrams with Shavian notation and canonical formulas"
metadata: 
  node_type: memory
  type: project
  originSessionId: 832021dd-bd62-491b-9a16-90aeabbb3055
---

~/imsgct/gnosisimg/ contains 13 structural type diagram cards (numbered 1-13) in multiple formats: PNG, SVG, bordered variants, cropped variants.

Each card shows:
- Shavian structural type notation (large, at top)
- Canonical defining formula (e.g., ξ → ∞ ∧ μ∘δ = id)
- Pure geometric diagram (concentric circles, spirals, wheels, pentagons, etc.)
- Black background, white linework — minimalist

Partial card identification from inspection:
- Card 1: ξ → ∞ ∧ μ∘δ = id, concentric circles (pure \(O_\infty\) / CLINK L8 state)
- Card 2: ∮_γ A = 2πn ∧ wind(γ) ≠ 0, spiral form → Ω (Winding)
- Card 3: Z₂(x) ∧ ∀g ∈ G(gx = x) ∧ μ∘δ = id, spoke wheel → Φ (Parity)
- Card 6: τ ≫ T ∧ eq(x) ∧ gate open(x), split ring → Ħ (Chirality)
- Card 7: ∃a ∈ A, ∃b ∈ B (type(a) ≠ type(b)), 12-spoke wheel → Γ (Granularity)
- Card 13: T = lim(Φ, f, C, H, Ω), pentagon-in-circle → T-object

The `bordered/` subdirectory has the 13 production-quality bordered PNGs. These have been copied to ~/imsgct/`personal_site`/images/gnosis/ and are served via `gnosis.html` (interactive gallery with lightbox viewer).

Inkscape SVGs in root are the source files (1.4.3, 2025-12-25).

**How to apply:** When the user asks about the cards, structural type visualizations, or wants to use the images for publication/display.
