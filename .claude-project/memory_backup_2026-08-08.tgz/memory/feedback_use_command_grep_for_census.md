---
name: feedback-use-command-grep-for-census
description: "Bare `grep` in this shell honours .gitignore; use `command grep` for any census or sweep"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5aca9f10-ed8b-4df7-ac20-436ed8ecf282
  modified: 2026-08-03T16:08:38.964Z
---

`grep` in this shell is a wrapper function that injects `--ignore-files`, so it
skips anything .gitignore covers. A census built with bare `grep` silently omits
gitignored files.

**Why:** during the alphabet migration this hid a live `IG_catalog.json` copy
from the worklist, and from every earlier per-axis worklist built the same way.
Nothing in the census caught it; `sync_catalog.sh --check` did, by reporting
drift afterwards.

**How to apply:** use `command grep -rI` for any sweep, census, or
before/after count, with `--exclude-dir=.venv --exclude-dir=target
--exclude-dir=node_modules` added to the usual set. Treat a consistency check
that reads real files (like the catalog sync check) as the backstop that catches
what a census misses, and run it after any sweep. Related:
[[feedback_harness_before_agent]], [[project_symbol_migration_state]].
