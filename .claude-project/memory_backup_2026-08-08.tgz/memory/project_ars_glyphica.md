---
name: project-ars-glyphica
description: "Ars Glyphica trilogy — Phytoglyphica (plants), Animaglyphica (animals), Fungiglyphica (fungi) morphological imscription engines"
metadata: 
  node_type: memory
  type: project
  originSessionId: 832021dd-bd62-491b-9a16-90aeabbb3055
---

Three morphological imscription engines that read pharmaceutical meaning from organism body plans using the 12-primitive IG. All completed 2026-06-12 to 2026-06-24.

## Ars Phytoglyphica (~/imsgct/`Ars_Phytoglyphica`/)
- 147 medicinal plants from all inhabited continents
- 11 canonical Phytoglyphic Imscriptions (structural clusters in 12-dim lattice)
- CLI: `ap` (types / plant / morphology / lattice / distance)
- Lean formalization in lean/ subdirectory
- Manuscripts in manuscripts/; PDFs in pdfs/
- Key insight: serration = opcode, trichome density = endpoint criterion, Fibonacci phyllotaxis = cycle counter

## Ars Animaglyphica (~/imsgct/`Ars_Animaglyphica`/)
- 80 representative species across 3 ouroboricity tiers (\(O_1\) – \(O_2^\dagger\))
- 14 canonical structural types
- Lean: `p4rakernel/p4ramill/Imscribing/ArsAnimaglyphica.lean`
- Key insight: venom delivery topology, glandular architecture, aposematic coloration as structural programs

## Ars Fungiglyphica (~/imsgct/`Ars_Fungiglyphica`/)
- 86 fungal species across 3 ouroboricity tiers (\(O_1\) – \(O_2^\dagger\))
- 15 canonical structural types
- Lean: `p4rakernel/p4ramill/Imscribing/ArsFungiglyphica.lean`
- Key insight: cap shape, gill structure, spore surface, growth habit encode preparation and dosing

**Note:** Distinct from [[project-voynich-phytoglyphica]] (vp CLI for Voynich folio annotation). The Ars engines are about real-world organisms.

**How to apply:** When discussing morphological imscription, pharmaceutical applications, or organism-body-as-program claims.
