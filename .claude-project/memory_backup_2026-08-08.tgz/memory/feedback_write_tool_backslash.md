---
name: write-tool-backslash-escaping
description: Write tool double-escapes backslashes — LaTeX commands written as \cmd become \\cmd on disk
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 69a11ed9-ff98-4330-8f09-1c1828201b8c
---

The Write tool JSON-encodes its content parameter, causing every `\` to be stored as `\\` on disk. LaTeX commands like `\heb{...}` written in the content string land as `\\heb{...}` in the file, which pandoc/lualatex renders as a literal backslash followed by text rather than a command call.

**Why:** JSON string escaping — `\` must be `\\` in JSON, and the tool applies this when writing.

**How to apply:** After any Write call that contains LaTeX commands (`\cmd{...}`), run a Python fix-up:

```python
python3 -c "
path = 'file.md'
with open(path) as f: c = f.read()
open(path,'w').write(c.replace('\\\\\\\\cmd{','\\\\cmd{'))
"
```

Or more generally, replace `\\\\` → `\\` for any LaTeX command prefix. Alternatively, verify with:

```bash
python3 -c "
with open('file.md') as f:
    for i,l in enumerate(f,1):
        if 'heb{' in l or any(c in l for c in ['\\\\\\\\']): print(i, repr(l[:80]))
"
```

The `ltx` script handles the downstream consequence (`\heb` defined in preamble), but the source `.md` file still needs single backslashes for pandoc to pass the commands through correctly.
