---
name: project_imasmic_core
description: "imasmic_core repo — bridge code connecting CLINK, organoid simulation, and p4rakernel via Frobenius verification"
metadata: 
  node_type: memory
  type: project
  originSessionId: c3278fd2-ff13-4ee8-a17a-9ff6a9a2f02c
---

`~/imsgct/imasmic_core/` — bridge package: `clink_organoid_bridge.py`, `p4rakernel_organoid_bridge.py`, `frobenius_verify.py`. Connects the CLINK pipeline ([[project_red_hot_rebis]]) and organoid simulation work to [[project_para_lean]]/p4rakernel via Frobenius-closure verification. Packaged repo (`pyproject.toml`, `.egg-info`, `build/`). Not previously memory-tracked; discovered during the 2026-06-16 ig-docs triage.
