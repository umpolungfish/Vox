---
name: project_vae_vita
description: "vae_vita = THE grammar-based local model: 12-D hyperspherical VAE (vMF on S¹¹) trained on all 17.28M Crystal-of-Types configs; recovers d=12 SIC geometry; is the Sense Organ's UPDATE-grounding signal"
metadata: 
  node_type: memory
  type: project
  originSessionId: 835b5dd8-a5ff-42e0-b775-e0637ea4764e
  modified: 2026-07-19T05:41:54.705Z
---

**`vae_vita` is the grammar-based local model.** When the user says "our
grammar-based LLM" / local model, this is it. (Do NOT go rummaging; it lives at
`~/imsgct/vae_vita/` for the Lean/docs and `~/imsgct/ig-pulse/vae_vita/` for the
Python + weights.)

- **What:** a 12-D hyperspherical VAE, von Mises-Fisher prior on S¹¹, trained on
  all 17,280,000 Crystal of Types configurations (the complete IG state space).
  Encoder = δ (emission), decoder = μ (verification); μ∘δ=id when the latent is a
  SIC-POVM. Code: `hyperspherical_vae.py` / `_v2.py`, `train.py` / `train_v2.py`,
  `crystal_data.py` (`crystal_address`). Weights: `vae_vita_sic`.pt (λ_sic=50),
  `vae_vita_v2`.pt, etc.
- **Result:** independently recovers d=12 SIC-POVM geometry from grammar types
  alone (no SIC in training). Regularized and unregularized both converge to
  ~0.0834 overlap (1/12, biased toward SIC 1/13). The Crystal intrinsically codes
  near-SIC geometry — a structural account of the Zauner question
  ([[project_sic_stage1_paper.md]], [[project_crystal_of_types]]).
- **Live role:** it is the UPDATE step of the Sense Organ (see `SENSE_ORGAN`.md,
  ~/imsgct/MoDoT/sense_*). `sense_ground.py` runs a freshly-imscribed tuple through
  the trained VAE and reports reconstruction confidence per primitive — a
  non-circular grounding signal independent of the LLM that proposed the tuple.
  This is [[project_grammar_sole_complete_verification]] made operational.
- git: repo at ~/imsgct/`vae_vita`, single "initial" commit; weights live under
  ig-pulse/`vae_vita` (not in the `vae_vita` repo).
