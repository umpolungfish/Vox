---
name: feedback_crystallize_before_merge
description: "Before ANY merge, create a crystalline/<topic>-<YYYY-MM-DD> snapshot branch at the work tip"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 711e22d9-6656-44e2-bcff-22c452cb9b4c
  modified: 2026-08-07T16:49:25.336Z
---

Before every merge, create a "crystallized" snapshot branch first: a branch that
pins the project state at the moment before the merge. Naming convention already
in the repo: `crystalline/<topic>-<YYYY-MM-DD>`, e.g.
`crystalline/sic-moduli-conductor-2026-07-25`. It points at the tip of the work
branch being merged.

**Why:** the pre-merge state stays recoverable as a named point, not just a
reflog entry. Existing crystalline branches become ancestors of the target after
the merge lands, so they read as the recoverable record of each merged step.

**How to apply:** `git branch crystalline/<topic>-<date> <work-branch>` before
running the merge. Never merge without it. See [[feedback_commit_no_push.md]] —
commit and merge locally, never push.
