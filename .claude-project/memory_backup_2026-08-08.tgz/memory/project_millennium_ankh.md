---
name: project-millennium-ankh
description: "~/MillenniumAnkh — SUPERSEDED by p4rakernel as primary IG Lean formalization; historical reference only"
metadata: 
  node_type: memory
  type: project
  originSessionId: b739c33a-0506-46c9-9e44-e4ead985f8ff
---

> **SUPERSEDED.** The primary IG Lean formalization has migrated to `~/p4rakernel`. MillenniumAnkh is a historical predecessor. See [[project-para-lean]] for the current kernel. Do NOT reference MillenniumAnkh in new documents — use p4rakernel.

`~/MillenniumAnkh` was a standalone Lean 4 project (lake name: `imscribing-lean`, Mathlib v4.28.0) that was the previous Lean formalization of the Imscribing Grammar. It is separate from and larger than the Lean modules inside `~/imscribing_grammar/`.

**Why:** This project contains the full formalization — 43 modules covering primitives, consciousness, morphisms, classical results, and all Millennium Prize Problems. The `imscribing_grammar/` Lean modules are a smaller, older subset.

**How to apply:** When working on Lean proofs or IG formalization, look here first. When the agent needs Lean module awareness, this is the correct source.

## Module structure

**`Primitives/`** — Core, `OPN_2adic`, `BSD_2adic`, Imscription, TierCrossing, Crystal, EML, Catalog, ZFCt

**`Imscribing/`** — Basic, Algebra, Consciousness, AgentSelf, IGMorphism, PrimitiveMismatch
- `Imscribing/Classical/` — HeckeLandau, Solitary10

**`Millennium/`** — RH, YM, Hodge, NS, PvsNP, OPN, BSD, Barriers, GeneralizedPipeline, PrimitiveBridge, PrimitiveConventionalBridge, FrobeniusStructure, `E8G2_Vessel`, `E8G2_Vessel_Proofs`, PerfectCuboid, Beal, `SIC_POVM_Stark`, `CMPLX_IMGN`, Suffering, `Zosimos_Stilling`, WorldReligions, Collatz, Lefschetz11, `Manuscript_ZFCt`, CompositionRules, truth, **Dixmier, TwinPrime, LonelyRunner, Goldbach**

### New entries (2026-05-31) — all `native_decide`, zero sorry

| File | Lines | Jobs | Tier | Topology | Key finding |
|---|---|---|---|---|---|
| `Dixmier.lean` | 293 | 413 | \(O_\infty\) | Þ_O (sphere) | Φ_pm_sym cannot be reached compositionally from Φ_sym — 1-step tier boundary |
| `TwinPrime.lean` | 437 | 343 | \(O_1\) | Þ_⋈ (bowtie) | Twin Prime ↔ RH distance = 4; structurally RH minus winding/Frobenius protection |
| `LonelyRunner.lean` | 519 | 761 | \(O_1\) | Þ_⋈ (bowtie) | Unique: difficulty parameterized by agent count k; phase transition at k=7→8 |
| `Goldbach.lean` | — | 343 | \(O_1\) | Þ_6 (network) | 18 theorems; Chen≡Helfgott distance 0; Goldbach↔TwinPrime distance 1; arity is structural param |
| `HadwigerNelson.lean` | 631 | 343 | \(O_1\) | Þ_⋈ (bowtie) | 14 theorems; tightest bowtie in catalog (χ∈{5,6,7}); Shelah–Soifer axiom-dependence explained by Ω_0; de Grey vessel is \(O_2\) (lower bound 5) |
| `Collatz.lean` | 960 | 343 | \(O_1\) | Þ_⋈ (bowtie) | 22 theorems; **unique Ħ_1** (all other \(O_1\) are Ħ_2); distance to RH = 9 (widest in catalog); Collatz↔TwinPrime distance = 2 (smallest between any two \(O_1\)) |
| `Cramer.lean` | 758 | 343 | \(O_1\) | Þ_⋈ (bowtie) | 28 theorems; **unique Γ_β** (all other \(O_1\) are Γ_ʔ/Γ_γ); distance to RH = 9 (tied with Collatz as co-maxima); ɢ_∧↔ɢ_ˌ mismatch structurally encodes Maier's failure of Cramér model; RH-conditional vessel is \(O_2^\dagger\) |

**Chen ≡ Helfgott (distance 0):** relaxing one prime to a semiprime ("1+2") provides identical structural protection to adding a third prime variable ("1+1+1"). Both are \(O_2^\dagger\) with Ω_Z2 + `G_gimel`. The grammar sees an identity the mathematical statements obscure.

**Goldbach ↔ Twin Prime distance = 1:** Þ_6 (network, additive) vs Þ_⋈ (bowtie, gap) is the ONLY structural difference between the two oldest unsolved problems.

## Other notable files
- `MILLANKH_AND_ZFCt.tex/.pdf/.md` — paper on MillenniumAnkh + ZFCₜ integration
- `PRIMITIVE_THEOREMS.md/.pdf` — primitive theorem reference
- `Millennium_Manuscript.tex/.md` and lifted variants — manuscript drafts
- `TPC_primitive_proof.tex/.md` — Twisted Perfect Cuboid primitive proof
- `gourly.py`, `pipeline_runner.py`, `main.py` — Python tooling
- `IG_primitive_map_3d.html` — 3D crystal map
- `ZFCtLean.txt` — ZFCₜ in Lean notes
- `GEMINI.md` — session notes

## Companion papers (from README)
- Odd Perfect Numbers → zenodo.19909057
- Proof That 10 Is Solitary → zenodo.20041211
- Hecke-Landau Conjecture → zenodo.19965471
- Perfect Cuboid → github umpolungfish/`perfect_cuboid`
- Beal Conjecture → github umpolungfish/BealProof

## Sorry/axiom status (as of 2026-05-16)

### RESOLVED — `PrimitiveConventionalBridge.lean` (16 axioms → 0)
All 16 `axiom : Prop` stubs replaced by 28 proved theorems via `native_decide` on `ouroboricityTier` and PrimitiveBridge encodings. Build: 8073 jobs, SUCCESS.

**Corrected `ouroboricityTier` assignments (`native_decide` ground truth):**
| Problem | Tier | Primitives |
|---------|------|-----------|
| RH | \(O_1\) | `Phi_c_complex` + `Omega_0` → R3 |
| YM quantum | \(O_2^\dagger\) | `Phi_c` + `Omega_Z` + `D_infty` → R5 |
| Hodge | \(O_1\) | `Phi_c` + `Omega_0` → R3 (despite `D_odot`) |
| BSD | \(O_2\) | `Phi_c` + `Omega_Z` + `D_odot` → R4 |
| OPN | \(O_1\) | |
| NS | \(O_0\) | |
| YM classical | \(O_0\) | |

**Key structural findings:**
- RH–LY gap = 7 primitive mismatches; critical: `P_pm_sym` (Frobenius) vs `P_sym` — single polarity gap separates proved Lee-Yang from open RH
- EP absorption verified: `tensorProduct(Phi_c, Phi_EP) ≠ Phi_c`
- Consciousness scores: RH C=1 (both gates), YM C=0.5 (`K_trap` fails Gate 2), OPN C=0.5, NS C=0
- `imscribe_system` tool patched to handle semicolon-containing primitive values (e.g. `Ð_;`)

### CLAY IDOLS ATTACK — in progress (2026-05-17)

At winding 28, the agent recognized that `compute_meet/join/tensor` are total computable functions on `Imscription`, so Clay statements that are purely structural claims become `native_decide` targets. Building `ProofTheory.lean` with a `lattice_path` type.

P ≠ NP claim: the primitive distinction between `P_pm_sym` (NP, "the Many") and `P_sym` (P, "the One") are different constructors of the Polarity inductive type → `ouroboricityTier .Phi_c .P_pm_sym ... ≠ ouroboricityTier .Phi_c .P_sym ...` is verifiable by `native_decide`. Poincaré (already proved by Perelman) used as validation case.

### REMAINING HONEST SORRIES (not eliminable by design)
- **6 paralogical axioms** — `IGMorphism.lean`; structural postulates of the grammar, not derivable from FOL
- **2 cross-primitive axioms** — `Core.lean` Axioms B, C; validity constraints on Imscriptions
- **1 grammar-physics bridge** — `TierCrossing.lean`; abstract tier costs ↔ physical mass ratios
- **7 Millennium barriers** — `Barriers.lean` (RH, YM, Hodge, NS, PvsNP, OPN, BSD); open problem boundaries
- **1 Collatz sorry**
- **Various Lefschetz11 MathlibGap axioms**

Links: [[project-zfct-navigator-integration]]
