---
name: feedback_fix_the_generator
description: "Fix the generator/source, never hand-patch generated output artifacts"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 21b1da09-0362-49fb-a927-310f560c4377
---

When a defect appears in a generated/derived artifact (auto-generated Lean scaffolds,
slugged filenames, ob3ect output, compiled docs, propagated identifiers), fix the
**generator/source**, not the output. Hand-patching the artifact is the wrong move even
when it's faster; the bug will just regenerate.

**Why:** The user has raised this more than once, pointedly ("why didn't you fix the
generator", "FIX IN THE GENERATOR NOT THE OUTPUT"). They care about root-cause fixes and
know I'm capable of them; patching symptoms reads as being lazy/dumb.

**How to apply:** If I find myself editing a file that was emitted by a tool (scaffold,
slug, build output), stop — that's the tell I'm in the wrong file. Trace to the emitter
(e.g. `IMSCRIBr/proof_scaffold.py`, `ob3ect/auto.py`) and fix there, then regenerate to
verify. Only touch a generated artifact to clean up a mess I myself created. Even input
issues (a typo in a domain string) get fixed at the generator's ingestion/normalization
step, not by renaming the output. Related: [[feedback-complete-the-task]].
