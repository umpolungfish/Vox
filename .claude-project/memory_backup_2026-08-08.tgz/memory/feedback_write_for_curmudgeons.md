---
name: write-for-curmudgeons
description: "All proofs, Lean, and mathematical writing must convince skeptical mathematicians — both true AND non-trivial"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2fb1fb52-7563-4953-888b-6af8a508e24b
---

Write every proof, Lean theorem, and mathematical claim as if the audience is a hostile, skeptical mathematician who needs to be convinced of two things independently: (1) that it is **true**, and (2) that it is **non-trivial**.

**Why:** User's framing: "we must convince old curmudgeons and math trolls that what we say is both true and not trivial, and our Lean must reflect that." The grammar's results are novel enough that the default assumption from a skeptic is either "this is wrong" or "this is just a restatement of something known." Both objections must be preempted structurally.

**How to apply:**
- Lean proofs should carry the full weight — no `sorry` that looks like hand-waving, every `sorry` should be a named, located gap with a stated structural reason
- Distance claims (d=4.382, d=6.245) need their metric defined before they're cited
- When stating a result that sounds bold (P≠NP, \(O_\infty\) paradox resolution), lead with the lattice definition that makes it precise, not the conclusion
- Prose around proofs should anticipate the "so what?" — state why the result is non-trivial, what weaker statements it strictly implies
- Never oversell: a distance measurement is a distance measurement, not a "proof" until the Lean term is closed
