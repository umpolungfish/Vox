---
name: feedback-no-backward-compat
description: "Never add backward-compatibility shims; freeze a branch to preserve the old state, then strip the old form out to the root"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 24b94f29-97bb-435a-9d7a-6a02bd1a43ad
  modified: 2026-08-03T11:05:47.247Z
---

Do not add compatibility layers, aliases, fallbacks, or "old form still parses"
seams. When a notation or schema changes: cut a frozen branch of the repo to
preserve the current state if it is ever needed, migrate the data forward, then
strip every trace of the old form out to the root.

**Why:** compat shims are why the pre-Shavian value names (`Ð_point`, `ƒ_noise`,
`Ω_C`, `Þ_torus`) survived roughly seven attempted purges over weeks. Each purge
left the aliases "just in case", so the old form kept being readable, kept being
written by something, and grew back. A dict literal holding `"Ð_point"` beside
`"𐑛"` is the visible symptom: two alphabets alive at once because neither was
ever actually killed.

**How to apply:** `git branch frozen/<what>-<date>` first, then delete the old
form entirely: enum members, collapse maps like `_CANONICAL_MAP`, `_RETIRED`
fallbacks, extra `from_symbol` aliases, parse aliases. Repoint every reference to
the canonical member rather than leaving a translation. If stored data still
carries the old form, migrate the data in the same pass — do not keep a reader
for it. Related: [[feedback_fix_the_generator]], [[feedback_cross_compare_before_cleanup]].
