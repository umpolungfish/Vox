---
name: feedback_ob3ect_provider_model
description: "For constructing ob3ects, always use provider openrouter + model google/gemini-3-flash-preview unless the user specifies otherwise"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f4cd0d57-3ebb-4a84-9ce3-f195fa6c95dc
---

When constructing ob3ects (`auto.py`, batch yamls, any ob3ect generation), always use
provider `openrouter` and model `google/gemini-3-flash-preview` as the default,
unless the user explicitly specifies a different provider/model for that run.

**Why:** User's standing default for the ob3ect pipeline. Do NOT read the ambient
`IG_MODEL` env var as the intended model — at 2026-07-07 it was set to
`deepseek/deepseek-v4-pro`, but the user corrected that the ob3ect default is
`google/gemini-3-flash-preview`. The env default and the ob3ect-construction default
are not the same thing.

**How to apply:** In every batch yaml's `design:` block and every `auto.py` invocation
for ob3ect construction, set `provider: openrouter` and `model: google/gemini-3-flash-preview`
explicitly (matches the existing `d2048_a0_moduli_pin_batch.yaml` and `reflexivity_prefix.yaml`).
Note the older [[project-ob3ect]] memory says the provider chain is local→qwen→deepseek —
that is the fallback chain, NOT the intended ob3ect-construction default. See also
[[feedback_no_anthropic]] (never Anthropic) and [[feedback_no_max_tokens]].
