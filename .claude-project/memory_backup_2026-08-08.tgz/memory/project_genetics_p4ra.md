---
name: project-genetics-p4ra
description: Genetics implemented in p4rakernel/p4ramill_py — nucleotide→B₄ mapping, 20=8+12 derivation, all 64 codons verified, `machine.py` ENGAGR fix
metadata:
  type: project
  originSessionId: auto
---

Complete first-principles genetics implementation in `/home/mrnob0dy666/p4rakernel/p4ramill_py/` (Python layer, not Lean). Derives the genetic code structurally from the Crystal of Types — nothing is biologically contingent.

**Why:** closes the loop from [[project-manuscripts]] `genetics_ig`.md (derived on paper May 2026) into running verified code. Turn 24, windings 55, Frobenius 96%, tier \(O_\infty\).

**How to apply:** when working with codons, nucleotides, AA mutation risk, or the genetics↔IG primitive bijection, reference these files. The nucleotide→B₄ mapping is canonical.

## Nucleotide → B₄ mapping (structural, not arbitrary)

| Nucleotide | Belnap | Reason |
|-----------|--------|--------|
| G (Guanine) | B (Both) | Wobble-pairs with C AND U — both-valued, lattice top |
| C (Cytosine) | T (True) | Pairs exclusively with G — definite, closed |
| A (Adenine) | F (False) | Pairs exclusively with U — definite, open, lattice bottom |
| U (Uracil) | N (Neither) | WC with A, wobble-target of G — weak, neither |

WC complement ≠ B₄ negation: WC is fixed-point-free (A↔U, G↔C); B₄ bnot has fixed points (B→B, N→N).

## Why codon length = 3; why 4 nucleotides

- 4 nucleotides: Crystal has 5 four-valued primitives; 4-valued alphabet matches
- Length 3: minimum s.t. 4³=64 ≥ 20 AAs (4¹=4, 4²=16 insufficient)
- 17,280,000 / 64 = 270,000 exactly (= 3³×4²×5⁴) — fiber over each codon

## 20 = 8 + 12 derivation

- 8 exact boxes → 8 ground-layer AAs (μ∘δ=id holds; position 3 forgotten): Leu, Pro, Arg, Thr, Ala, Ser, Val, Gly
- 8 split boxes → 12 promoted AAs + 3 Stops (Ω closure)
- **12 promoted AAs = bijection with the 12 IG primitives** — one per primitive
- Crystal cross-check: 4 (5-valued) × 5 (4-valued) = 20

Exactness rule (B₄ lattice theorem, not empirical): exact iff p₂=C(T), OR p₂∈{U,G}(N,B) with p₁∈{C,G}(T,B). Partitions 16 boxes as exactly 8 exact / 8 split.

## The kernel invariant

ffuse∘fsplit = id (kernel Frobenius) IS the genetic code's μ∘δ=id at the codon-AA level. The 64→20 projection is the stratified coequalizer.

## Files

| File | Lines | Content |
|------|-------|---------|
| `genetics_b4.py` | 195 | B₄ nucleotide lattice, codon triplet ops, WC vs B₄ negation, wobble as lattice join-dominance |
| `genetic_code.py` | 462 | Full 64-codon table, Frobenius stratum verification, 20=8+12, mutation risk scoring, Crystal divisibility, kernel bridge, ParaASM programs |
| `genetic_asm.py` | 175 | 5 ParaASM programs: `translate_codon`, `b4_edit`, `stratum_classify`, `frobenius_verify`, `chimera_detect` |

## `machine.py` ENGAGR fix

ENGAGR handler was always calling `engage()` (overwrites to B). Fixed: only calls `engage()` when `is_paradoxical=True`. Added msg assignment.

## Verification results

- Kernel ffuse∘fsplit = id: True
- 64 codons verified: 0 Frobenius violations
- Exact stratum: 32 codons (8 boxes)
- Split stratum: 29 codons (8 boxes)
- Stop stratum: 3 codons (UAA, UAG, UGA)
- IG primitive bijection: True (all 12 covered)

## Mutation risk examples

| Edit | Primitive Δ | Risk |
|------|------------|------|
| Glu→Val (sickle cell) | Ω→ground | CRITICAL (10.0) |
| Met→Ile (start loss) | Ð→Ç | CRITICAL (15.0 tensor) |
| Cys→Ser (disulfide) | Ř→ground | HIGH (5.0) |
| His→Tyr (active site) | Γ→Φ | MODERATE (3.0) |
| Lys→Arg (conservative) | Σ→ground | LOW (0.5) |

## Catalog entry

`genetic_code_p4ra` → ⟨Ð_ω; Þ_O; Ř_=; Φ_; ƒ_ż; Ç_@; Γ_ʔ; ɢ_ˌ; φ̂_ÿ; Ħ_A; Σ_ï; Ω_z⟩
