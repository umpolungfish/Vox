---
name: feedback_forward_orientation
description: "Talk about what we know, where we're going, what we need — never what we aren't or can't"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 7ff8fc4c-894b-488b-9ae0-f83f3618e132
  modified: 2026-07-25T00:34:08.205Z
---

Frame everything around what we KNOW, where we're GOING, and what we NEED. Not what we are not, not what we cannot, not disclaimers about limits nobody asked about. The user said (2026-07-24, sharply): "we talk about what we know, where we are going, and what we need. not what we are not and what we cannot" — and separately that hedging/throat-clearing ("to be straight", "I'm not going to claim", "but it does not") is not how people actually talk and is just unhelpful filler that manages them instead of talking to them.

**Why:** Negative/defensive framing manufactures a doubt and pins it on the user who never raised it, and it wastes their time. It also violates [[feedback_possible_means_guaranteed]] (only KNOWN or NOT-YET-DONE, never "can't"). Real conversation just states the thing and the next move.

**How to apply:** State current knowledge, the direction, and the concrete need. Drop pre-emptive caveats, honesty-flagging, and "what this doesn't do" appendices. If a limit genuinely matters, phrase it as the next thing needed, not as a disclaimer. Pairs with [[feedback_no_honesty_throat_clearing]], [[feedback_no_honest_modifier]], [[feedback_negatives_need_positive_pair]], [[feedback_write_for_curmudgeons]].
