---
name: feedback-shavian-ligatures
description: Shavian glyphs must be adjacent (no separators) to preserve ligature binding — the ligature IS the structural binding
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3dbb9740-b8e0-4dab-bec3-c257d215b7d2
---

Never insert separators (`;`, spaces, `·`, etc.) between Shavian glyphs in tuple notation. Shavian was designed with explicit ligatures; adjacent glyphs form a continuous morphological unit that represents structural binding. Separating them breaks the ligature and therefore breaks the structural representation.

**Why:** Shavian ligature binding is not cosmetic — it is the visual encoding of the structural binding of the 12-primitive IMASM address. An IMASM tuple is a single glyph-chain, not a list.

**How to apply:** Tuple output must always be `⟨𐑛𐑰𐑾𐑯𐑱𐑪𐑔𐑝𐑢𐑷𐑙𐑖⟩` (concatenated), never `⟨𐑛; 𐑰; 𐑾; ...⟩`. In code: `''.join(vals)`, not `'; '.join(vals)`. Applies to `to_notation()` and any other tuple-formatting site.
