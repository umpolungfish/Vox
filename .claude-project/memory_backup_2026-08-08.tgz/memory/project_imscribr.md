---
name: project-imscribr
description: IMSCRIBr — IMASM Arrangement Space Iterator collapsing 12^8 arrangements to 12 canonical archetypes
metadata: 
  node_type: memory
  type: project
  originSessionId: 832021dd-bd62-491b-9a16-90aeabbb3055
---

IMSCRIBr at ~/imsgct/IMSCRIBr/ maps the 12⁸ = 429,981,696 possible arrangements of the 12 IMASM tokens into structural fingerprint classes.

- Pipeline: 430M arrangements → 165 family signatures → ~1,000–2,000 coarse structural classes → exactly 12 canonical archetypes
- Key finding: the autopoietic bootstrap collapses the full arrangement space back to the 12-primitive crystal
- Python-based (stdlib only), CLI interface
- Lean scaffolds in lean/ subdirectory
- Includes `newton_lift.py` for lifting arrangements into the proof scaffold
- Includes `pseudo_voynich.py` and `cfg_sequences.py` for corpus work

**Why:** Proves structurally that the 12-token IMASM is complete — no arrangement escapes the 12-archetype partition. The AREV branching fix (`commit.txt`) corrected F-branch vs T-branch polarity for AREV inside FSPLIT/FFUSE pairs.

**How to apply:** Reference when discussing IMASM completeness or arrangement space enumeration.
