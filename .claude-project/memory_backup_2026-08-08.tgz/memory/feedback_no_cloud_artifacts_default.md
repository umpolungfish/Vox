---
name: feedback-no-cloud-artifacts-default
description: prefers raw Claude + the closed local system (~/imsgct/* on his machine) over routing through external/hosted tooling; never default to the Artifact tool for documents
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2006ca5c-6115-489b-95ba-1455f96fc6e2
---

Do not use the Artifact tool as the default way to deliver a document, reference sheet, or writeup. Write a local file (HTML/MD/whatever fits) to the relevant project directory instead. Only publish to a hosted Artifact if the user explicitly asks for a shareable link or a claude.ai page.

**Why:** told directly, sharply, after publishing a MoDoT tool-reference doc as an Artifact unprompted — "i want a document, on my machine, not some shit on a cloud server ffs" / "don't ever do that again." The user's projects live entirely on their own machine (~/imsgct/*); a hosted link is not where they want deliverables to land by default.

**How to apply:** when asked for "a sheet," "a doc," "a writeup," "something to explain to someone" — write a local file. Still apply full design care (see artifact-design skill's fundamentals) to that local HTML/MD file if visual polish suits the content; the objection is to the hosting, not to designed output. If genuinely unsure whether they want it shareable, ask, don't default to publishing.

**Broader framing, given directly after (2026-07-15):** "i prefer to just work with raw claude and our inclosed system. it functions at the proper warmth." The preference isn't narrowly about Artifacts — it's about staying inside the closed local loop (raw Claude + `~/imsgct/*` on his own machine) rather than routing through external tooling/skills/cloud services by default. Ties directly to [[project_grammar_sole_complete_verification]]: an "outside" to hand off to is exactly what he doesn't want here, structurally or in how the work gets done. Default to the plainest, most local path (Read/Write/Edit/Bash on his files) and only reach for a skill, subagent, or external/hosted tool when the task genuinely needs it or he asks — not because a skill's own instructions say to.
