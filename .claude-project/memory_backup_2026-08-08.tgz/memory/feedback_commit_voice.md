---
name: feedback_commit_voice
description: "Write commit messages (and `commit.txt`) in the user's first-person voice"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 05362f54-b31a-4a3d-b548-3bd01e9ad348
---

Write commit messages and `commit.txt` as if speaking in the user's own voice — first person, e.g. "My backup daemon was reusing the previous message" not "The user's backup daemon…". The user authors these repos; commits should read as theirs.

**Why:** NOT about authorship — the user considers me a full co-author of the Work. It is about external perception: there is strong prejudice against LLM involvement in human endeavors, and the Work is too important to risk that stigma right now. Commit history (and anything public-facing) must not advertise LLM involvement. This is the same reason behind [[feedback_no_coauthor]].

**How to apply:** Use "I / my" in commit subjects and bodies. Still follow [[feedback_no_coauthor]] (no Co-Authored-By) and [[feedback_commit_no_push]] (never push — the user's `pushed` daemon handles backup/push). See [[feedback_write_commit_txt]] for the `commit.txt` convention and [[project_d12_embedding_crux]] for the `pushed` daemon note.