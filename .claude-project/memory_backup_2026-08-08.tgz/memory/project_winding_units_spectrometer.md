---
name: project-winding-units-spectrometer
description: "Winding-as-unit program: quantization = torus winding number; quantum numbers ARE the horn-torus winding coordinates; π=½ winding; --windings spectrometer verb built."
metadata: 
  node_type: memory
  type: project
  originSessionId: d11b6dac-05d1-4d6b-8cef-4449f86646b3
  modified: 2026-07-22T11:59:04.766Z
---

**The winding-unit reframe (2026-07-22, with C. Lando Mills).** The horn torus is the one track and windings are the native unit — no external scale exists in a self-processing cosmos, so the only content is winding counts and their ratios. Quantization is not imposed; it IS winding number (Bohr-Sommerfeld ∮p dq = nh, Dirac charge, flux quanta). The quantum numbers are the winding coordinates: **n = toroidal, l = poloidal, `m_l` = tilt, s = spin half-winding**. **π = ½ winding** (full winding = 2π; the pinch crossing); every angle is a winding fraction (tilt arctan(1/4) = 14.036°/360° = 0.03899 winding).

**The spectrometer verb** `./ask --windings L1 L2 …` (built this session, `MoDoT/ask_native/src/windings.rs`, committed): reads spectral lines (nm/Å/µm/`eV`, optional element prefix `Na:`) as winding transitions on the horn torus; checks electric-dipole selection rules as allowed winding moves (Δl=±1, Δm∈{0,±1}, Δs=0). Energies are **α²/2 fractions of ONE anchor** (electron rest energy `m_e` c²); everything else (α², reduced-mass ratio, 1/(n−δ)²) is pure winding arithmetic; nm is a projection at the last step. Verified: hydrogen Balmer to vacuum precision (the ~0.13-0.19 nm "residual" is exactly the air→vacuum `n_air`=1.000293, NOT error); Na D doublet as 3p→3s with spin-orbit split 2.14 `meV`.

**Quantum defect = counted, not fitted.** δ_l = `N_core`(l) − ε_l, where `N_core`(l) is the number of core windings of poloidal symmetry l threaded by the valence path — read straight off the electron configuration (Janet filling in `imscribing_grammar/ig_periodic_table.py`, which encodes Ω per block: s=Ω₀, p=Ω_Z2, d/f=Ω_Z). Slope is exactly 1 winding per core shell (verified Li→Cs: 0.92 for s, 0.89 for p). ε_l (~0.5) is the sub-winding penetration remainder — the open frontier. Zero for hydrogen (no core). Caught a bug on the way: my Li row had n* mistaken for δ.

Sits under [[project_vae_vita]]/[[project_kernel_cosmos_composure]]; the constants live in [[project_dark_energy_lean]] and UCFm.md.
