---
name: project-ixcription-tool
description: "imscribe ixcription strips the outward form (name + description) off a catalog entry without moving its address; the whole catalog stripped is kept at data/IG_catalog.bare.json"
metadata:
  node_type: memory
  type: project
  originSessionId: 5aca9f10-ed8b-4df7-ac20-436ed8ecf282
  modified: 2026-08-04T14:12:15.350Z
---

Built 2026-08-04. A catalog entry carries an **address** (the twelve glyphs)
and an **ixcription** (the outward form: name, description, justification).
Every operation reads the address; nothing reads the words except as a handle.
So the words come off without the tuple moving.

`imscrbgrmr/ixcription.py` is the operation, importable by agents.
`imscribe ixcription` is the CLI: **strip · list · restore · set · compare**.

- A stripped entry stays in the catalog with its address untouched, renamed to
  its own address in glyphs. Addresses are shared, so a `#n` discriminator is
  appended only where one is needed.
- What comes off goes to a sidecar `<catalog stem>.ixcriptions.json`, keyed by
  handle, appending a round each time. That makes `restore` possible and makes
  `compare` able to say whether two rounds of ixcription over one address chose
  the same name.
- `set` writes a fresh round onto a bare address; strip again to record it.
- `IG_CATALOG` env var points the commands at a copy. Only the canonical path
  propagates to the consumer repos ([[project_unified_catalog]]).
- A full strip→restore round trip returns the catalog byte-identical.

## The bare catalog

`imscribing_grammar/data/IG_catalog.bare.json` is the whole catalog with every
form removed, kept live with its sidecar `IG_catalog.bare.ixcriptions.json`
holding all the forms. Point `IG_CATALOG` at it to read, compare, or restore.

Stripping every entry leaves every structural verdict identical — same
slot-category violations, same address multiset, nothing moved. The entries
outnumber the distinct addresses by about a third, so that many entries were
distinctions drawn in the words rather than in the lattice. The heaviest
addresses each hold a coherent class: the bitter aromatics (with the Voynich
astronomical and cosmological sections among them), the Cherokee syllabary
entire, letters across Greek/Hebrew/Arabic on one address, the adaptogens.
The bitter aromatics and the adaptogens part on a single axis, ⊤ kinetic
character, 𐑤 against 𐑧.

Related: [[project_unified_catalog]], [[project_imscribing_grammar]],
[[project_crystal_of_types]].
