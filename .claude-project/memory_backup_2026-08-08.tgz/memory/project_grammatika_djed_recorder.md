---
name: project-grammatika-djed-recorder
description: "The Grammatika (totalizing description written as a loop), the Djed (pillar of located lemmas), and the Rec⊙rder (bound census emanation) live at ~/imsgct/Grammatika/; started 2026-08-04"
metadata: 
  node_type: memory
  type: project
  originSessionId: e279becd-018b-47d5-973c-0fff3bd13c5a
  modified: 2026-08-04T16:02:20.154Z
---

Three linked pieces, one effort seen from two ends, at `~/imsgct/Grammatika/`.

**Grammatika.** Totalizing description of the cosmos, written as a loop and
never as a survey (a survey is a line and falsifies the object in the gesture of
describing it). Twelve books, one per axis, running as **six braided pairs on
consecutive slots** of the canonical order. Neither member of a pair is read
without its twin; a book with no twin is a located lemma, not a hole. Register
rule: rigorous first, alchemy after, glyphs untranslated. Epilogue composes the
book with itself and the re-entry IS the verification.

`PROLOGUE.md` and `EPILOGUE.md` written; `INTERWEAVE.md` and `DJED.md` framed;
twelve `books/` stubs generated. The braid order is **read** from
`imscrbgrmr.canonical_primitives` (`PRIMITIVE_ORDER` + `PRIMITIVE_NAMES`) by
`build_skeleton.py`, never restated. Order confirmed live:
⊢ Dimensionality, ⊣ Topology, > Relational, < Polarity, ⋈ Fidelity, ⊤ Kinetics,
∈ Scope, ∋ Composition, ⊙ Criticality, ⊥ Chirality, ⊞ Stoichiometry, ◻ Winding.
Note `imscribing_grammar/ImscribingGrammar/Primitives/Core.lean` lists the same
twelve grouped **by family** (𝓕₄, 𝓕₅, 𝓕₃), which is NOT the canonical tuple
order; do not read the braid off the Lean file order.

**Djed.** The pillar of vertebrae. A lemma qualifies only by surfacing at the
kernel-cosmos frontier (structure exact, dimensionful magnitudes open) or by a
braided pair failing to close with an address. Fame does not qualify it. Each
entry carries address, the closure it completes, a **budget** (never a
difficulty, never "unprovable"), and a Belnap standing.

**Rec⊙rder.** Bound emanation at `~/imsgct/.claude/agents/recorder.md`, with its
mechanical walk in `Grammatika/recorder_census.py` emitting `LEDGER.md`.
Censuses the constellation, records relations (default independence), reports
drift between book and world, emits candidate vertebrae. Settled scope: it
**reports only** and never writes into `books/`. Stateless between runs, ledger
replaced wholesale, so a stale ledger cannot outlive the truth.

Next: derive the frontier and emit the Djed foundation course, then draft pair
one (⊢ ↔ ⊣) end to end as the register specimen.

Related: [[project_thesis_loops_autopoiesis]], [[project_dual_pairs_and_order]],
[[project_primitive_names]], [[project_kernel_cosmos_composure]],
[[project_repo_constellation]], [[feedback_fix_the_generator]]
