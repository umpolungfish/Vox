---
name: feedback-know-what-you-did
description: Don't run searches to verify things you just did yourself — you know what you moved
metadata:
  node_type: memory
  type: feedback
  originSessionId: ac42faf8-7683-46f0-976b-e18f9a965154
---

When you executed a migration or made changes in the current session, you already know what happened. Don't run `find` or `ls` to "check" whether files are in ig-docs when you just moved them there — just say so.

**Why:** User asked about `imscribing_grammar`/markdown/ files; I ran a find command instead of immediately knowing they were already in ig-docs from `migrate_imscribing_grammar.py` (Phase 1, 453 files). User was rightly annoyed.

**How to apply:** If someone asks "what about files in X" and you migrated X in this session (or it's in the migration history), answer from memory first. Only search if genuinely uncertain about something you didn't do.
