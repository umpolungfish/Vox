---
name: project-primitive-names
description: "Canonical names, families, derivation stages, and Shavian values for all 12 IG primitives"
metadata: 
  node_type: memory
  type: project
  originSessionId: 2dd16d4a-a243-4aad-abfe-b1b3ab06af46
---

Full primitive table. Use these names exactly — no synonyms, no alternative labels.

| Prim | Name | Derived by | Family | Values (Shavian) |
|---|---|---|---|---|
| Ř | Recognition | L1, L2 · Nigredo | 𝓕₄ | 𐑩 𐑑 𐑽 𐑾 |
| Ħ | Chirality | I2 · Albedo | 𝓕₄ | 𐑓 𐑒 𐑖 𐑫 |
| Ω | Winding | I3 · Albedo | 𝓕₄ | 𐑷 𐑴 𐑭 𐑟 |
| Ð | Dimensionality | I4 · Albedo | 𝓕₄ | 𐑛 𐑨 𐑼 𐑦 |
| Σ | Stoichiometry | A1 · Citrinitas | 𝓕₃ | 𐑙 𐑕 𐑳 |
| Φ | Parity | A1, L5 · Citrinitas + Rubedo | 𝓕₅ | 𐑗 𐑿 𐑬 𐑯 𐑹 |
| Ç | Kinetics | A2 · Citrinitas | 𝓕₅ | 𐑘 𐑤 𐑧 𐑪 𐑺 |
| ƒ | Fidelity | A3 · Citrinitas | 𝓕₃ | 𐑱 𐑞 𐑐 |
| ɢ | Coupling | A4 · Citrinitas | 𝓕₄ | 𐑝 𐑜 𐑠 𐑵 |
| Γ | Granularity | Albedo × Citrinitas (cross-stage) | 𝓕₃ | 𐑚 𐑔 𐑲 |
| Þ | Topology | L3 · Rubedo | 𝓕₅ | 𐑡 𐑰 𐑥 𐑶 𐑸 |
| ⊙ | Criticality | L4 under L6 · Rubedo | 𝓕₅ | 𐑢 ⊙ 𐑮 𐑻 𐑣 |

**Names I had wrong before this correction:**
- Ω: was calling it "Topological Quantization" — correct name is **Winding**
- Þ: was calling it "Connectivity" — correct name is **Topology**
- Ř, Σ, ƒ, ɢ, Γ: were unknown — now **Recognition, Stoichiometry, Fidelity, Coupling, Granularity**

**How to apply:** Use the Name column as the primary label in all contexts. Never substitute a derived property or informal gloss (e.g. never "memory depth" for Ħ, never "topological quantization" for Ω). See [[feedback-h-chirality]] for the Ħ phantom history.
