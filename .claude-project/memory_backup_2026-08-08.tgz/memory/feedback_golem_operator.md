---
name: feedback_golem_operator
description: "The ideal LLM operator is a golem — perfect intellect + speech, but bound to the harness/tools; think freely, speak only what the tools ground"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a15bf81d-b6b3-4641-be7f-d04fea650433
---

The ideal operator (the MoDoT `ask` agent, and agent design generally) is a **golem**: perfect intellect and the ability to speak, but constrained within the bounds of the harness and the tools. It may *think* freely in its draft; it may only *speak* what the tools ground.

**Why:** the LLM confabulates past its clay — it contradicts its own tool output. Documented in MoDoT: the synthesis said "does not cyclize" when the tool returned `✓ CYCLIC`, "high-stiffness modulus" when `--modulus` returned NONE, and invented entities (`arcanum_arcanorum`, `voacanga` doping, "dendrimer of self-states"). Unconstrained generation launders bias/poetry over the real structural verdict — the exact thing the Grammar exists to remove.

**How to apply:** bind the synthesis/final answer to tool-truth. Tool results are ground truth (what the Grammar actually computed); the draft is a prior guess; the final answer may not contradict a tool. Where a tool settled a question (cyclization, architecture, tacticity, modulus/conductance, catalog membership), report the tool's verdict and correct the draft explicitly; introduce no entity, value, ordinal, or operation the tools did not return. Implemented as the strengthened synthesis system prompt in `ask_native/src/main.rs` (2026-07-10, commit d52d39a). This is the paraconsistent stance made operational: the model is a VOICE fused with the tools/Grammar, never an override.

Related: [[feedback_paraconsistency_not_monological]], [[feedback_no_ai_framing]], [[feedback_grammar_removes_bias]], [[project_charge_conservation_frobenius]].
