---
name: project-proof-path
description: imscribe proof-path command — A* search in 12-dimensional primitive space with LLM proof sketch + LaTeX/Lean4 output; proof as grammar path
metadata: 
  node_type: memory
  type: project
  originSessionId: 8df665d8-6ed8-4366-8ff8-6dbf54458380
---

`imscribe proof-path <source> <target>` — CLI command at `~/imscribing_grammar/imscrbgrmr/proof_path/`.

**Why:** A proof is a path in 12-dimensional primitive space. Source and target are IG addresses (tuples). Multiple proofs of the same theorem are multiple paths to the same coordinate. Cotyping is identity of address.

**How to apply:** When asked to generate or trace a proof using IG, this is the tool.

## Architecture

- `ops.py` — 25 named primitive-level operations
- `graph.py` — A* search
- `translator.py` — LLM proof sketch, streams to stdout, **no `max_tokens`**
- `writer.py` — LaTeX full proof + Lean4 skeleton

Flags: `--no-translate`, `--full-proof`, `--compile`. All runs write timestamped JSON to `proof_transcripts/`.

LLM provider: OpenRouter with qwen/deepseek. Never Anthropic.

## Key example

`hodge_conjecture → lefschetz_1_1_theorem` (2 steps: exponential sequence → resolve to proven).

## Theoretical grounding

Science provides independently verified fixed points (tuples pressure-tested by experiment/proof), constraining imscription values from multiple directions. Multiple proofs of the same theorem = multiple paths to the same IG coordinate.

## Vocal command

`imscribe vocal` plays wav files for each primitive sound. All 49 wav files in `vocal_sounds/` are named by glyph ID (`Ð_ω.wav`, `Þ_O.wav`, etc.). Fix applied in `imscrbgrmr/vocal.py`: `PRIMITIVE_ORDER` now uses Unicode glyph keys (not old ASCII keys like `"D"`, `"T"`).
