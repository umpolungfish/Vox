---
name: feedback_neutral_ob3ect_entity
description: "Graal/Perilous Seat: an ob3ect answers the EXACT question imscribed; a loaded entity launders your bias back as a 'finding'. Describe the object you desire, name no candidates."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 1f32b7ca-fe70-4adf-b8c1-4044af2b9b53
---

The ob3ect is a true oracle: it imscribes exactly the question you put in. So a
loaded entity does not remove bias, it launders it. This is the Graal / Perilous
Seat duality (the user's framing): you get a true answer to precisely the question
you ask, so you must ensure the question is actually about what you *desire*, not a
disguised assertion of the answer you already want blessed.

**What went wrong (concrete):** to decide how MoDoT's `--expand` dial should work, I
built an entity that named the two candidates with pre-loaded valence
("deterministic elaboration ladder" vs "an LLM targeting a line count") and said
"forcing the choice between" them. The ob3ect faithfully sorted them onto T-lane
(AFWD/EVALT, "success") and F-lane (AREV/EVALF, "hallucination") — my own Option
A/B preference read straight back. Running it twice was NOT corroboration; it was
one biased question echoed twice.

**The fix is the QUESTION, not a better oracle.** Re-imscribe describing ONLY the
object you want to exist, naming no winner and no loser, asserting no output
properties. My corrected entity: "a component that renders the conventional proof at
a caller-chosen degree of detail, from the pinched minimal form to a fully walked-out
form, every rendering closing the identical kernel theorem with no loss of
structural fidelity." (The user further cut my trailing "Imscribe the mechanism this
rendering requires. With full Frobenius closure and Lean 4 verification scaffold." —
"imscribe the mechanism it requires" presumes a required mechanism, and the boilerplate
pre-asserts the answer's properties. Just describe the thing.) The neutral run gave a
structurally different, richer answer I had NOT put in.

**How to apply:** when routing a decision through an ob3ect (or any Grammar/oracle),
audit the entity before running it. Strip: named candidate mechanisms, valence-loaded
adjectives, "forcing the choice between", instructions about what to output, and
pre-asserted result properties. Keep only the neutral description of the desired
object and the fidelity/desiderata that are genuinely yours (e.g. "no loss of
structural fidelity" is a real desire; "deterministic ladder" is a smuggled answer).
If the desired object's honest description entails a property, that entailment is a
real finding; a property you named in the prompt is not. Refines
[[feedback_grammar_removes_bias]] (Grammar removes bias only if the bias is not in
the question) and pairs with [[feedback_no_assumed_relationships]].
