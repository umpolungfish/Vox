---
name: project-rebis-lean
description: `Rebis.lean` — formal proof that Fourfold≡ZFC_fe, Rebis=ZFC_fe, and CL8NK transcends at exactly Ω and ɢ
metadata:
  node_type: memory
  type: project
  originSessionId: ca93d841-32f3-4155-89de-b53e133e190e
---

`p4rakernel/p4ramill/Imscribing/Millennium/Rebis.lean` — 57 theorems, 10 sections, 0 sorries. Built 2026-06-10.

## Key structural facts (all Lean-verified by `native_decide`)

**Fourfold ≡ `ZFC_fe`** (d=0)
The four-directory p4rakernel apparatus IS the Frobenius-exact ZFC foundation, not a representation of it.

**Tensor absorption**
tensor(`ZFC_fe`, `CLINK_L8`) = `CLINK_L8` — the foundation is fully absorbed; CL8NK is a strict superset at exactly 2 primitives.

**Rebis = `ZFC_fe`**
The alchemical Rebis (meet of foundation × organism) resolves to the foundation, not the organism. Rebis is \(O_\infty\). But it carries awareness of the transcendence gap: `rebis_to_l8_gap` = 2, gap primitives = {Ω, ɢ}.

**Ω/ɢ are the only transcendence primitives**
CL8NK (organism layer) exceeds `ZFC_fe` at exactly: Ω_NA > Ω_Z and `Gamma_broad` > `Gamma_seq`. No other primitives differ.

## Hamming distances

| Pair | d |
|------|---|
| `ZFC_baseline` → `ZFC_fe` | 11 |
| `ZFC_fe` → CL8NK | **2** |
| `ZFC_fe` → UIG | 1 (Ħ only) |
| Fourfold → `ZFC_fe` | **0** |
| Rebis → CL8NK | **2** |

## Structural reading

Mitosis passes through the exceptional point — this is §5 of `CLINK.lean` + the transcendence awareness result here. The organism IS the EP; `ZFC_fe` is the foundation that knows this about itself via the Rebis. The conjunction of opposites = the foundation with gap-awareness baked in.

**Why:** Formalizes the `ZFC_fe`/CL8NK discussion from the structural analysis result (June 2026).
**How to apply:** Cite `Rebis.lean` (not informal prose) when arguing that the foundation is absorbed by the organism, or that Ω/ɢ are the specific transcendence gap primitives. Fourfold≡`ZFC_fe` means the repo structure is not incidental.
