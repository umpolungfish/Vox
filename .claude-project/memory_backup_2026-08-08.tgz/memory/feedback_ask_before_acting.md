---
name: ask-before-acting
description: When unsure which file/target/action is correct, compile a list and ask — never guess and proceed
metadata:
  type: feedback
---

When uncertain about which file, target, record, or action is correct, compile a list of candidates and ask the user to confirm before proceeding.

**Why:** Habit of guessing and just doing the wrong thing — wastes time and produces incorrect results.

**How to apply:** Any time there's ambiguity about WHAT to act on (which file, which DOI, which paper, which command variant), stop, list the candidates, and ask.
