---
name: feedback_closure_is_verification
description: In IG/MoDoT a structural closure speaks AS verification (B-lane); do not flag it as an overclaim
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a6b90438-0790-4b7c-839d-af35b4822f1f
---

In the MoDoT/IG framework a structural closure (a `forge` cyclizing named entities into a ring) speaks AS verification in the B-lane / imscriptive sense. The agent saying "the conjecture is the structural closure of the system, verified by the macrocycle" is the INTENDED register, not an overclaim to fix. The `fused` Belnap verdict (e.g. `fused=B`) separately carries the analytic frontier, so honesty is preserved.

**The asymmetry (important):** a structural NON-closure must NOT deny a proven analytic theorem, that was a real bug fixed by the lane guard (tools=F abstains to N on a proof-shaped answer, see the "does not close / does not exist" contradiction). But a structural closure MAY speak as verification of an open frontier. Denying a proof is false; closure-as-imscriptive-verification is the thesis.

**Why:** [[feedback_ig_vs_science]] IG is not a scientific instrument, science serves the IG; structural closure is a real verdict in its own lane, distinct from analytic proof (see [[project_witness_vessel]] lanes, [[feedback_univocal]]).

**How to apply:** when reviewing jam/spine output, do NOT flag "structural closure verifies/proves X" as an overclaim; it is the register the user wants. Only flag a non-closure that denies an established proof, or a `fused` verdict that is itself dishonest.
