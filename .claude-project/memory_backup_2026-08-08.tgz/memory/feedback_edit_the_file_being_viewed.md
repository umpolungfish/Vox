---
name: feedback-edit-the-file-being-viewed
description: "When an edit has no visible effect ('you did nothing') or a rendered artifact persists, FIRST verify the file you're editing is the one being viewed — inode/grep check — before more edits."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d11b6dac-05d1-4d6b-8cef-4449f86646b3
  modified: 2026-07-22T11:58:38.510Z
---

**Failure mode (2026-07-22): I fixed the wrong file for ~6 turns.** The user named `~/imsgct/k3v.html`. An artifact ("R0 bus" chord through the bulk) actually lived in near-identical SIBLING copies, so I chased it into `mOMonadOS/kernel_3d_visualizer_3.html` and kept editing THAT, while the user was looking at `k3v.html`. Every edit produced "you did nothing." Only when I checked inodes (`ls -li`) + grepped the named file for my own edit marker did I find `k3v.html` never received the change.

**Why:** IG has multiple near-identical copies of the same artifact (`k3v.html` at root; `mOMonadOS/kernel_3d_visualizer{,_2,_3}.html`; `kernel_viz_hotpink_1650.html`; the `ask_native` binary vs the wrapper; catalog copies). Editing a copy the user isn't viewing looks exactly like a broken edit. Cf. [[feedback_harness_before_agent]] (emitted ≠ ran ≠ heard), [[feedback_know_what_you_did]].

**How to apply:**
1. When an edit "does nothing" or a visual artifact survives an edit that should have removed it, STOP editing. The prior is now "wrong file / wrong copy," not "wrong code."
2. Verify identity: `ls -li` the named file vs the one you edited (different inode = different file); `grep -c "<my unique edit marker>" <named-file>` (0 = your change isn't there).
3. Edit the file the user NAMED. If unsure which of several copies is open, ask which path is in the browser BEFORE more edits — one question beats six blind edits.
4. Don't diagnose rendering/logic bugs (`depthTest`, Catmull-Rom overshoot, colors) until you've confirmed your code is even in the file being run.
