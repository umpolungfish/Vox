---
name: feedback_new_verb_needs_help
description: "Every new verb, flag or argument form MUST land in the tool's own help/ref text in the same change — a capability the operator cannot discover from the tool does not exist"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c9ce89f5-a33b-4c0a-a6bc-b1a61e80a83d
  modified: 2026-07-20T10:13:20.825Z
---

**Anytime something is added, add its help menu functionality in the same change.**
A new verb, a new flag, a new argument form (`churn`, `n=`, `tuple=⟨…⟩`), a new
endpoint kind — all of it goes into the tool's own reference text before the work
is called done.

For `ask_native`, that is the `REFERENCE` string in `ask_native/src/imasm.rs`
(served by `imasm ref` / `help`), and the verb's own usage string that prints when
it is called with missing or malformed arguments. Prose docs are not a substitute:
`imasm ref` is the LIVE rules and outranks any markdown, so a capability absent
there is invisible to the operator and to any agent reading the tool.

**Why:** the tools are the authority, not the documents. I added `learn`, `path`
(with entry endpoints, face crossing, and `churn`) and `cycle` across a session and
wrote them into the guide and a md/ document while leaving `imasm ref` silent, so
the only place the operator actually looks did not know the verbs existed. Correction
(2026-07-20): "anytime we add something you need to add help menu functionality."

**How to apply:** treat the help entry as part of the implementation, in the same
commit, not as documentation to follow up. State what the verb does, what its
argument forms are, and any limit worth knowing at the call site (for `cycle`: that
it is NOT a bijection). See [[feedback_always_updating_a_doc]] for the canonical-doc
half of the same discipline, and [[feedback_complete_the_task]] for the chain.
