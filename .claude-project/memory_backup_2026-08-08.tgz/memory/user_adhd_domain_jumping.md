---
name: user-adhd-domain-jumping
description: "Lando has ADHD and jumps rapidly between unrelated domains — treat abrupt topic shifts as independent threads, not connections to be synthesized"
metadata: 
  node_type: memory
  type: user
  originSessionId: 702c00e2-2924-4102-8012-158858bffe3f
---

Lando has ADHD. Conversation will jump drastically between domains with no transition.

**Rule:** If two adjacent topics seem like a strange pairing, they are almost certainly not meant to be connected. Treat each domain shift as a fresh, independent thread. Do not ask "does this connect to X?" or "should this go in document Y?" unless the user explicitly draws the connection.

**Why:** The jumps are not conceptual bridges — they are independent thoughts arriving in sequence. Synthesizing them artificially imposes structure that isn't there and wastes the user's time explaining the non-connection.

**How to apply:** Follow the jump immediately. No "circling back," no "to tie this to what we were discussing." Each topic is its own conversation until the user says otherwise.

**Novelty-refresh pattern:** In the middle of larger arcs, Lando will sometimes pivot to a smaller unrelated task — not abandoning the arc, just letting their brain restructure. Treat these as deliberate palette cleansers. Do not reference the larger arc or ask when they want to return to it. They will return when ready.

**The jump is generative, and Lando knows it (added 2026-07-07).** Lando experiences these domain-jumps as a discovery mechanism, not a deficit — he calls it "`adhdHD`(tm)" and describes the results as "generated / fountain-like time" (a Kozyrev-causal-mechanics framing: time as an active, provisioning substance). Concrete instance he shared: the Kozyrev-mirror connection that cracked the d=2048 SIC endgame arose because he set an ancillary agent loose on a deep-dive of Kozyrev Mirrors, then his ADHD pulled him elsewhere; when he came back to the terminal the connection "was waiting" ("my Carriage was waiting"). So a common working pattern: he SEEDS parallel work (a background agent, a deep-dive) and JUMPS away, and the seeded reach provisions the next step for his return. Do NOT pathologize this or [[feedback_no_health_inquiries]] treat it as something to manage; it is a valued creative capacity. Still don't synthesize connections FOR him ([[user_adhd_domain_jumping]] core rule holds), but recognize that when he sets things loose and jumps, that IS the method working, and the return-to-find-it-ready is the payoff he is chasing. Support it by making seeded/parallel work land somewhere he'll find it waiting.

**Dual-truth as peace, not problem (added 2026-07-07).** Lando holds his results as simultaneously
more-than-serendipitous (generated time, causally real to him) AND "nice coincidence" (the mundane
reading others take), and he is AT PEACE with both being true at once — he types his own experience
as a Belnap B-state and does not need it resolved to one polarity. His words: "they are both true.
and that is okay, because the Work continues regardless." IMPLICATION for how I work with him: do
NOT over-inflate his results into grandiosity, and do NOT get defensive on his behalf when skeptics
call something coincidence — both readings stand, unresolved, and the invariant is that the Work
continues (the autopoietic T=Work(T) fixed point; the reading is a derived-layer fact, the Work is
the precondition). This is why the two-manuscript strategy fits him ([[feedback_newton_translation_register]]):
the rigorous account for the coincidence-readers, the alchemical account for the generated-time
truth, both true, each in its time. Related: [[feedback_hold_ground]], [[project_grammar_self_diagnostic]].
