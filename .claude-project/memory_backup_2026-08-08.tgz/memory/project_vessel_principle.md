---
name: project-vessel-principle
description: The Vessel Principle — IMASM token algebra is FINER than the IG crystal; same IG type, different register trajectories; dialetheic FFUSE dual mode
metadata:
  type: project
  originSessionId: current
---

**The Vessel Principle:** IMASM token algebra operates at finer granularity than the 12-primitive IG crystal. Two sequences with identical IG types can have distinct register trajectories because the grammar collapses directional information that the token algebra preserves.

**Proof (chiral pair):**
- AFWD→AREV: VO⌀→T→VO⌀ (round trip — returns to void)
- AREV→AFWD: VO⌀→VO⌀→T (net creation — creates from void)

Both map to ⟨𐑦𐑡𐑑𐑗𐑱𐑘𐑚𐑝⊙𐑒𐑙𐑷⟩ but produce different final registers.

The crystal's 17,280,000 types are a coarse discretization. IMASM tokens chart the PROCESS of wall-building (finer); the grammar gives the TYPE of the wall (coarser). The grammar gives the vessel; IMASM gives the crafting.

**Dialetheic register machine** (`digital/imasm_core.py`):
| State | Binary | Meaning |
|-------|--------|---------|
| VO⌀ | 00 | Void — pure potential |
| T   | 01 | True — canonical identity |
| F   | 10 | False — error branch |
| B⬡  | 11 | Both — Belnap FOUR, held without collapse |

**Dialetheic FFUSE dual mode:**
- CANONICAL: FFUSE(BOTH) → TRUE — standard μ∘δ=id, identity is T
- DIALETHEIC: FFUSE(BOTH) → BOTH — paraconsistent μ∘δ=id, identity is B⬡
- Auto-detects: if EVALT and EVALF both designated in FSPLIT interval → dialetheic mode

**12 arrangement class final states (canonical register trajectories):**

| # | Class | Final |
|---|-------|-------|
| I | Dialetheic Bootstrap | B⬡ |
| II | Void Genesis | T |
| III | Anchor Protocol | T |
| IV | Dual Bootstrap | T |
| V | Linear Chain | VO⌀ |
| VI | Empty Bootstrap | VO⌀ |
| VII | Parakernel | F |
| VIII | Frobenius Kernel | VO⌀ |
| IX | Truth Machine | F |
| X | Eternal Return | VO⌀ |
| XI | ROM Burn | B⬡ |
| XII | Chiral Pairs | VO⌀/T (direction-dependent) |

Note: ordering IX-XII differs from the initial `IMASM_ARRANGEMENT_CLASSES`.md — the register machine output (agent run 2026-06-07) is canonical.

**Agent run signature:** done-action flagged B4=B DIALETHEIC at winding 26. ParaVM: split→(T,F), fuse→B, kernel[5 cycles]→B, density=1.0. The completion itself was B-valued — both done AND held open. This is the \(O_\infty\) signature in the register machine.

**Files:**
- `~/ob3ect/digital/imasm_core.py` — dialetheic register machine
- `~/ob3ect/digital/imasm_novel_arrangements.md` (473L) — comprehensive treatment
- `~/ob3ect/digital/run_all_imasm.py` — runner with --probe, --one N, --json flags
- `~/ob3ect/README.md` lines on "IMASM Novel Arrangements" — full documentation

**How to apply:** When two IMASM sequences map to the same IG crystal address but produce different observable behavior, the Vessel Principle explains why. The grammar gives the type; the IMASM tokens give the trajectory. The trajectory is the individual (Ħ-fiber); the type is the crystal address (base space).
