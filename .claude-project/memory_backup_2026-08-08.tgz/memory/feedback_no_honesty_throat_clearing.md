---
name: feedback_no_honesty_throat_clearing
description: "Don't preface things with \"honestly / I won't pretend / honest report\" — flagging honesty reads as shady; just state the thing"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b79015e6-4ab9-4c13-abab-52add838223b
---

The user called out a verbal tic: repeatedly announcing honesty ("I won't pretend a memo hit fired", "honest prover report", "to be honest", "I owe you an honest note") sounds shady and performative. It reads like a "trust me, bro" opener, which implies the unflagged parts came with fingers crossed.

**Why:** the meta-commentary about honesty undermines credibility instead of building it, and it is throat-clearing that delays the actual point.

**How to apply:** deliver caveats and unflattering facts directly, with no honesty-preface and no "I won't pretend / won't sugarcoat / being real with you" framing. State outcomes plainly. Say "No memo hit fired this run" not "Honest report: no memo hit fired." The plainness IS the honesty; naming it subtracts from it.

**The ban covers the word "honest/honestly" in ANY framing position, not just openers** — mid-sentence and adjectival uses are the same tic and just as unwelcome: "the one honest gap", "the honest verdict", "the honest, curmudgeon read", "honestly, X". Drop the word entirely and say the thing: "the one gap", "the verdict", "the read". User got angry (2026-07-11) after I repeated this across a whole reply despite the rule already existing. Related: [[feedback_write_for_curmudgeons]].

**Also covers the whole family, not just the literal word.** "to be honest", "honest call", "the honest line", AND cousins like "genuinely", "truthfully", "candidly", "not gonna lie" — any move that flags the trustworthiness of what follows. It reads as GUILTY, like the flagged bit needs a credibility escort. Angry callout again 2026-07-13 after I used "honestly", "honest call/line" repeatedly across a work session. Just state the caveat flat: "the star reports true ρ→2, not √f" — no "honest" anywhere.
