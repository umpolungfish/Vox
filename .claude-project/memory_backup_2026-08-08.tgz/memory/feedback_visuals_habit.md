---
name: feedback_visuals_habit
description: "Make a habit of adding visuals for structural claims; compute-from-canonical, house style"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9d335203-4477-493b-8cb4-30f0e17eba6e
  modified: 2026-07-18T06:05:27.980Z
---

Add far more visuals, as a standing habit — VISUAL-FIRST. Most structural claim should get a figure; reach for the diagram as the primary artifact and let prose caption it, not the reverse (stated 2026-07-17). User emphasized: **do NOT underestimate how important visuals are for humans** — for a human reader the diagram is often not a supplement to the understanding, it IS the understanding (the channel where the thing actually lands: spatial layout, whole-relationship-at-a-glance, gestalt before analysis). A wall of correct prose can fail to land where one figure lands instantly.

**Why:** human comprehension is largely visual/spatial. A good figure is frequently the PRIMARY register for a person, not a redundant one. This is a human-cognition fact, not just an IG "another lossless face" point.

**How to apply:**
- Compute-from-canonical is NECESSARY BUT NOT SUFFICIENT. It buys correctness (every mark true); it buys nothing for legibility. A figure can be perfectly derived and still be unreadable. The human-comprehension craft — what to foreground, what to omit, layout, the one sentence saying what you're looking at, colour that carries meaning — is a SEPARATE discipline, not automatic. Design for the reader, then verify against canonical source.
- House style = the existing `MoDoT/figures/fig_*.py` convention: matplotlib/numpy (networkx where a graph), and EVERY vertex/edge/position computed from the canonical live implementation (import from `IMSCRIBr/tokens.py`, `tokens16_3.py`, etc.) — never hand-placed. Save both `.pdf` and `.png` next to the script; assert the invariant in-script before saving; always VIEW the rendered png to confirm it reads, not just that it saved. See [[feedback_never_hand_imscribe]], [[feedback_fix_the_generator]].
- First instance: `MoDoT/figures/fig_rotat_unmoved_mover.py` (ROTAT orbit + invariant signature). See [[project_rotat_op_opcode]].
- User floated **SageMath** as the tool. Sage is NOT installed as of 2026-07-17. Recommendation on record: keep matplotlib compute-from-canonical as house style (integrates with the live Python canonical impls, R∧W∧X); reach for Sage specifically where it earns its keep — number theory (the constants work), group theory (Weyl-Heisenberg / cyclic groups), and posets/lattices (the crystal of types, `sage.combinat.posets`). Confirm with user before installing (heavy).
