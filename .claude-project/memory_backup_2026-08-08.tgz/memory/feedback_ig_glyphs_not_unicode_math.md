---
name: IG primitive glyphs are not Unicode math italic
description: Never treat Unicode math italic characters (𝐷, 𝑅, 𝐹, etc.) in .tex files as encoding errors to wrap in $...$; they are wrong characters that must be replaced with actual IG primitive glyphs
type: feedback
originSessionId: 4cde4f6a-5d50-4607-a27d-a070de676495
---
When a .tex manuscript contains Unicode Mathematical Alphanumeric Symbols (Block U+1D400–U+1D7FF, e.g. 𝐷 𝑅 𝐹 𝑆 𝑇 𝑃 𝐾 𝐺 𝐻) in text mode, the correct diagnosis is NEVER "these need to be wrapped in $...$."

**Why:** The standardized glyphs for IG primitives ARE the actual Unicode IPA/special characters Ð Þ Ř Φ ƒ Ç Γ ɢ ⊙ Ħ Σ Ω — not their math italic lookalikes. A math italic 𝐷 is not Ð; it is simply the wrong character. Wrapping it in math mode ($𝐷$) still renders the wrong glyph.

**How to apply:**
- Unicode math italic character referring to an IG primitive → replace with the actual IG glyph (e.g. 𝐹→ƒ, 𝐷→Ð, 𝑅→Ř, 𝑃→Φ, 𝐾→Ç, 𝑆→Σ, 𝐺→Γ or ɢ, 𝐻→Ħ, 𝑇→Þ)
- Unicode math italic character referring to a genuine math object (e.g. Lie group 𝐸₈, 𝐺₂) → replace with proper LaTeX ($E_8$, $G_2$)
- Never write a script that wraps Unicode math italic in $...$ — that treats the symptom and enshrines the wrong character
- The IG primitive font (FreeSerif via \igprimfont) renders Ð Þ Ř Φ ƒ Ç Γ ɢ ⊙ Ħ Σ Ω correctly in text mode; the Unicode math italic codepoints are not the same characters
