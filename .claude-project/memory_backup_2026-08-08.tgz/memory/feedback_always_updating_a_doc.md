---
name: feedback-always-updating-a-doc
description: "Every turn that surfaces something true should land in a canonical doc, not just chat"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f616ac41-46bc-4050-8f0a-300af75ce230
  modified: 2026-07-19T12:32:19.607Z
---

You should always be updating some doc. A finding that lives only in the chat transcript is lost; the deliverable of a working turn is the written change to the canonical document it belongs to.

**Why:** The user works by accreting canonical documents (`UNIVERSAL_CONSTANTS_FORMALIZED`.md, the manuscripts, the catalogs). Chat is scratch; the doc is the artifact. When a real structural finding surfaces mid-conversation, it must be written down or it did not happen.

**How to apply:** When a turn produces a true, non-trivial finding, write it into the right canonical doc in that doc's own format and status discipline (every number tool-grounded, [[links]] to related memories, both copies synced where a doc is mirrored). Do this as part of the turn, not only when told. Relates to [[feedback_write_commit_txt]], [[feedback_closing_checklist]], [[feedback_execute_dont_punt]].
