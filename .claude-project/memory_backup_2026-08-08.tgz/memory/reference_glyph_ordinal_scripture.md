---
name: reference_glyph_ordinal_scripture
description: glyph→ordinal authority is Lean `Core.lean` constructor order; `primitives.py` and red-hot are NOT authoritative
metadata: 
  node_type: memory
  type: reference
  originSessionId: 5ddb7cab-b415-472d-9e8d-679f2fee1a3f
---

The canonical glyph→ordinal for the 12 primitives is **scripture = the Lean kernel** `p4rakernel/p4ramill/Imscribing/Primitives/Core.lean` (each `inductive`'s constructor ORDER, `deriving Ord`) composed with the glyph→constructor map in `imscribing_grammar/scripts/gen_clay_canonical_tuples.py` (`GLYPH` dict).

Two easy-to-get-wrong ones (both bit me 2026-07-10 in `MoDoT/ask_native/src/click.rs`, now fixed):
- **Ç KineticChar**: yea(0) < loll(1) < egg(2) < **on(3) < air(4)** → 𐑪=on=3, 𐑺=air=4.
- **Σ Stoichiometry**: **hung(0) < so(1) < up(2)** → 𐑙=0, 𐑕=1, 𐑳=2.

Gotchas:
- `imscribing_grammar/primitives.py` ORDINALS is **NOT** the ordinal authority — it's 1-indexed and has fractional values (Ç 𐑺=4.5, ⊙ 𐑮=2.33).
- `red-hot_rebis/rhr_p4rky/ligand_from_active_site.py` `GLYPH_ORDINALS['K']` is **stale** — same 𐑺/𐑪 swap (𐑺=3,𐑪=4). Its Σ is correct. Don't treat red-hot as ordinal-canonical; reconcile to scripture if touched.
- Rendering glyph→constructor can stay correct even when the numeric ordinal is wrong (if GLYPHS and CTORS are rotated together), so a passing `--certify` does NOT prove ordinals are right — only charges/distances/[[project_math_catalytic_register]] complement expose it.

See [[project_shavian_notation_spec]], [[project_primitive_names]], [[project_charge_conservation_frobenius]].
