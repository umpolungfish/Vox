---
name: project_igpulse
description: ig-pulse repo — 33-stream information propagation observatory; all streams in `domain_streams.py` (extreme merged into base 2026-06-27)
metadata: 
  node_type: memory
  type: project
  originSessionId: 7b2c529d-dd92-41dd-b515-d2ef37bfee6e
---

`~/imsgct/ig-pulse/` — Information propagation observatory. Maps coupling structure between physical, computational, and financial systems using the 12 IG primitives as a common vocabulary.

**33 streams total** (as of 2026-06-27) all in `ig_pulse/domain_streams.py` (single file, ~2964L). `domain_streams_extreme.py` was deleted after full merge.

Stream inventory by category:
- **Base (1–15):** `fear_greed`, mempool, coingecko, onchain, tides, `air_quality`, donki, seismic, `kp_index`, `hn_sentiment`, `solar_wind`, lightning, wikipedia, weather, `coingecko_alts`
- **Market/Macro (16–23):** `options_skew`, `yield_curve`, vix, shipping, `power_grid`, `night_lights`, gdelt, twitter
- **Biological Chiral (24–28):** genbank, pubmed, `wiki_chiral`, `arxiv_bio`, `fda_enforce`
- **Astrophysical Chiral (29–33):** `stereo_cr` (1-min), `ace_epam` (5-min), `goes_cr` (5-min), `dscovr_helicity` (1-min), `stereo_sept` (1-min directional)

**`stereo_sept`** (stream 29 in the astrophysical block) — University of Kiel STEREO/SEPT Level 2 1-minute directional electron (45–425 `keV`) + ion (84 `keV`–6.5 MeV) fluxes; 10 data products (electrons + ions × 5 look directions: omni, sun, antisun, north, south). Live data through day 100 2026. ~78-day latency. Only stream providing directional particle asymmetry for Ħ/Ω calibration. NMDB neutron monitors are dead (refuse all connections).

**Why:** chirality signals — e⁻/p⁺ ratio = parity-violation proxy; N/S asymmetry = Parker spiral handedness; sun/antisun streaming = field-aligned vs counter-streaming.

**Coupler fix (2026-06-26):** sort key changed to `(-|r|, -lag_seconds)` so long-lag causal leads surface above lag=0 batch artifacts; `cli.py` splits output into causal-leads vs zero-lag-structure sections; `--top N` flag added.

**Data:** `data/snapshots.jsonl`, `data/coupling.json`. Single aggregator: `DomainStreamAggregator` from `domain_streams`.

## Aggregator architecture (2026-06-29)

`collector.py` refactored: `run()` creates ONE persistent `DomainStreamAggregator` and loops, calling `_write_snapshot(agg, ...)`. `collect_once()` creates a fresh aggregator with `force=True` for one-shot CLI use. **Critical:** the per-stream TTL dict (`_stream_last`) and readings cache (`_stream_readings`) live on the aggregator instance — if you create a new aggregator each tick, carry-forward and TTL gating are completely non-functional. Always keep the aggregator alive in `run()`.

## Arc routing — continuous Pacific frame (2026-07-01, SUPERSEDES date-line splitting)

`solar_seismic.html` `arcSegments()` was rewritten: it now draws ONE continuous polyline (no normalize, no splitting). Both endpoints are brought into a Pacific-centred frame via `adjLon()` (`VIEW_CENTER_LON = -160`, window is that ±180), the far endpoint is nudged ±360 to take the shorter direction, then 32 points are interpolated with a sin-lift (clamped to ±84° for Mercator). Returns `[pts]` (single segment) so the old `for (const pts of arcSegments(...))` render loop still works. The prior split-at-date-line approach left visual gaps and forced every arc westward → arcs looked "cut"; this fixed that. `adjLon` is now the Pacific-frame normalizer (used for nodes/stations/`flyTo` too), NOT the old `[-180,180]` modulo.

## Map auto-refresh (2026-06-29)

`loadMapData()` wraps the `/api/solar-seismic` fetch; `setInterval(loadMapData, 60000)` runs it every 60s. Warnings/chains poll on their own 60s timers (already existed).

## Coupler performance + seismic collapse (2026-07-01)

The `seismic_network` stream emits a reading per station per event, so the stream universe exploded to ~3550 per-station streams (`seismic_{NET}_{STA}`) and snapshots grew to ~4MB each (9647 readings). `coupler.analyze()` was O(keys²)×lags → ~50 days on 2516 snapshots. Two fixes: (1) `_coupling_stream_name()` collapses per-station seismic to per-network (`seismic_net_{NET}`, ~14 nets) for coupling only — raw per-station readings untouched so the map still shows all stations; `_build_series()` single-pass, max-alert aggregation. (2) `_cross_correlate()` vectorized: r for every lag via prefix sums + one FFT `np.correlate`, p-value only for winning lag (identical to naive loop, 288× faster). Net: **~50 days → ~18s**. `analyze()` prints active-series/pair count up front.

**Consequence for `geo_viz`:** `coupling.json` now has `seismic_net_{NET}` names. `api_solar_seismic()` resolves those to the network's station **centroid** (circular-mean longitude) — else every seismic arc silently drops. Legacy per-station names still supported.

## Warnings/chains needed _load_if_needed (2026-07-01)

`/api/solar-seismic/warnings` and `/chains` read `engine._latest_snapshot` but never loaded it (only the `/api/all` geo-node path called `_load_if_needed()`), so on the solar-seismic page the alert bar + chain monitor always showed nothing (`ts:None`). Fixed by calling `engine._load_if_needed()` at the top of both endpoints.

## Deployment topology (2026-07-01) — three separate targets

- **API + Flask maps** = Fly.io app `igpulse` (region lax), domain **igpulse.imscribe.com**, GitHub `umpolungfish/ig-pulse`. Deploy: `fly deploy` from `~/imsgct/ig-pulse` (builds from working dir, NOT GitHub). `/` = `geo_map` (Datanado main map), `/solar-seismic` = `solar_seismic`. `couple` is NOT run on the container — `coupling.json` is baked into the image (`COPY data/`) and only refreshes on redeploy. `collect` runs on the container.
- **imscribe.com** = Cloudflare Pages, GitHub `umpolungfish/imscribesite`, serves from `index/`; deploys on `git push`. Serves clean URLs (`/geo_map.html`→308→`/geo_map`). Static map copies (`index/solar_seismic.html`, `index/geo_map.html`) are the ig-pulse templates with `API_BASE` = `https://igpulse.imscribe.com` (relative on localhost). Has `scripts/check_site.py` validator + pre-commit hook (fails on broken internal links / orphan pages).
- **personal site** = **landomills.com** (Cloudflare), GitHub `umpolungfish/landomills.com`, dir `~/imsgct/personal_site`; no CNAME in repo. Same static map copies.

**CORS:** `geo_viz.py` `CORS(... origins=[...])` must list every site origin — currently imscribe.com/www, igpulse.imscribe.com, landomills.com/www, localhost. Missing origin = "ig-pulse API unavailable" on that site.

**Fly infra gotchas:** no persistent volume + scaled to zero → every cold start began empty and a visitor's first fetch hit a cold-start 502 → "API unavailable". Fixes: `min_machines_running = 1` (keep one warm) AND bake `data/seed_snapshots.jsonl` (one recent snapshot) as `/app/data/snapshots.jsonl` so cold starts have data. `data/snapshots.jsonl` (~230MB) is `.dockerignore`d and `.gitignore`d (blocked GitHub's 100MB limit).

## SIC-POVM convergence / "universe is natively B" empirical result (read 2026-07-05)

ig-pulse is now **44 streams** (README) and is the empirical apparatus behind the user's
claim that "the universe at our scale is natively B, all binary collapse is forced
filtration." Canonical writeup: `ig-docs/physics/sic_povm_convergence.md`. Code:
`ig_pulse/density_matrix.py`, `sic_povm.py`. CODE-VERIFIED mechanism (not just prose):
metrics are the real QI quantities — purity Tr(ρ²), von Neumann entropy −Tr(ρ log ρ),
`fiducial_proximity` Tr(ρΠ_fid) — correctly implemented; `reconstruct()` with no active
primitive returns **exactly I/12** (B-state = maximally mixed by construction). Result
over 2394 snapshots (~100 days real public data): avg state 91.5% of max entropy
(S=2.275 vs ln12=2.485), purity 0.119 vs I/12 floor 0.083; **0% near-pure, every
snapshot a mild excitation above the B-floor** (never collapses); SIC overlap spectrum
uniform over all 144 WH directions (χ²=4.68, dof 143, p≈1). d=12 fiducial exact
F/F*=1.0000.

**HONEST-SCOPE STRUCTURE (load-bearing for any manuscript citing this; the doc itself is
this honest):** the near-I/12 *average* is CONVENTION-DEPENDENT — it uses alert-weighting
(alert=0 → I/12 baseline) which encodes the B=I/12 axiom; the code's other natural choice,
raw-value weighting (`readings_to_vectors`: weight=(val/100)(1+0.3·alert)), gives a
coupling-concentrated state instead (doc calls it a calibration artifact). So "avg near B"
partly assumes what it confirms. The CONVENTION-INDEPENDENT residuals are the strong empirical
core: (a) never-pure snapshots, (b) uniform 144-direction coverage, (c) high entropy. These
also discriminate **B (glut) from N (gap)**: maximal-mixed + uniform-full-coverage = "all
present at once" = B=(1,1), whereas N=(0,0) would show sparse/absent coverage. **DECISIVE
UNTESTED CHECK** (STAGED as entity E of the bstate-filtration ob3ect batch, not yet run):
recompute never-pure + uniform-144 under BOTH weightings; if "never collapses to a definite
state" survives the weight change it's not a B-convention artifact and "natively B,
definiteness only by filtration" stands on data alone.

**BATCH STAGED (ob3ect 32b898e, 2026-07-05): `bstate_filtration_batch.yaml`** — 6 entities
(A native-B glut/gap reading; B flat-readout Tr(`E_pq`·I/12)=1/144 all 144; C no-unitary-collapse
via purity invariance, POVM-selection-only route; D coreflector bridge ClassicalRestriction ↔
rank-1 selection; E the robustness pass above; F capstone gate = `SIC_D12_BState.lean` in
p4rakernel, `native_decide` standard, no new axioms, registers separated). Ctx frozen at
ob3ect/ctx/`bstate_filtration`/ (verbatim Grammar verdicts + `ClassicalRestriction.lean` +
`SIC_D12_Embedding.lean` + `density_matrix.py` + convergence md). FRESH ANCHORS (imscribe CLI,
2026-07-05): `void_b_state`↔`stark_unit_sic_v2` d=4.5 symmetric (re-verified); `void_b_state`↔
`quantum_measurement_collapse` d=11.3/11.7 ASYMMETRIC 0.4 (cheaper falling in — metric echo of
failed reverse adjunction), proof-path 11 moves each way (waypoints generic, ops carry finding);
tensor(`void_b_state`, `quantum_measurement_collapse`) DENIED on [D,T,R,P,Γ,S] — same signature as
vessel cargo denial. User runs: `cd ~/imsgct/ob3ect && python3 auto.py -f bstate_filtration_batch.yaml`.
Next after PASS: `SIC_D12_BState.lean` planks + the entity-E computation on banked snapshots. "Universe at our scale" is operationalized as these 44 feeds (fair but finite); primitive
basis is framework-internal (predates SIC identification, which helps). The LLM-translation
leg (§4, DeepSeek recovering d=12+hyperspherical+Crystal count) the doc itself rates
"suggestive not conclusive" w/ 4 limitations — do NOT lean on it. Ties to [[project_49h_sic_convergence]],
[[project_heat_death_dialetheic]] (max entropy = dialetheic saturation), the measurement-problem
thread (B native everywhere, classicality = coreflector/filtration [[feedback_..]] §8 of the zenith SIC paper).

Related: [[project_synfin]] (financial-only), [[feedback_execute_dont_punt]]
