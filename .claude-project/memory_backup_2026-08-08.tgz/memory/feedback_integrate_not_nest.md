---
name: feedback_integrate_not_nest
description: "When building on a generated ob3ect, INTEGRATE it (live read/derive), never merely house it beside runtime code"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f985bde5-cd58-453f-96c7-e4444cba7454
---

Housing a generated ob3ect within a project versus housing it AND integrating it are different things. Merely putting the ob3ect in a folder and having runtime code cite it / hand-copy its protocol creates TWO bounded, nested sets (a containment, a Cartesian product, encoding = W-only). Integrating makes ONE integrated manifold: the runtime READS the ob3ect live and is shaped by it, so the ob3ect is the base and the runtime is a section over it, coupled by R∧W∧X (imscription = [[project_imscribing_rwx_correspondence]], the lossless bulk↔boundary read/write/execute), not a comment.

**Why:** the whole IG method is that structure is sourced through the Grammar and stays coupled to it; a citation is inert, a live read is a morphism. Same figure as the Frobenius manifold ([[project_charge_conservation_frobenius]]): the base carries the fiber on every tangent space, it does not sit next to it. Nesting is dead; integration is autopoietic — change the base and the section follows.

**How to apply:** after auto-designing an ob3ect (`auto.py`), do not just reference it. Have the runtime LOAD the `ob3ect.json` and DERIVE its behavior from it (protocol from `phase_4`, arm semantics from `phase_1`, Belnap fold from `phase_3`), keep only an embedded fallback for standalone use, and flag divergence (integrated=False) when section and base disagree. Falsifiable test: alter the base ob3ect and confirm the runtime follows. Example landed: MoDoT `modot/selectivity.py` is a section over ob3ects/`selectivity_gate`/ ([[project_charge_conservation_frobenius]] balance-vs-selectivity gate). See also [[feedback_scaffold_build_on_it]], [[feedback_fix_the_generator]], [[feedback_never_hand_imscribe]].
