---
name: project_imasm_flow_semantics
description: "2026-07-18 IMASM dynamics locked: imasm eval/eval16 (values over SIXTEEN_3, FOUR = classical slice) + imasm compose (end-to-valence law); structure/kernel/flow are three separate verdicts"
metadata: 
  node_type: memory
  type: project
  originSessionId: 835b5dd8-a5ff-42e0-b775-e0637ea4764e
  modified: 2026-07-18T21:18:36.217Z
---

2026-07-18, `ask_native`: the IMASM dynamics are locked (md/`imasm_composition_rules`.md).

- One evaluator over the `SIXTEEN_3` carrier (subsets of {T,F,t,f}); FOUR is its
  classical slice, not a second system. `imasm eval` renders N/T/F/B,
  `imasm eval16` the full sixteen. Gates: VINIT seeds, FSPLIT fans truth/falsity
  parts, EVALT/EVALF pass-gates, FFUSE unions, AREV involutes, IFIX latches,
  TANCH reads out. All information-monotone; Kleene iteration settles on cycles.
- Three independent verdicts per program: grammar (define), kernel closure class
  (prove), flow (eval: does the fuse recover what the fork was fed). The
  canonical protocol word VINIT FSPLIT AFWD FFUSE EVALT is lossless; AREV on one
  arm breaks value-id while shape still closes.
- `imasm chaos <A> <B> [..6]`: ChaosComposer, the possibility state space of a
  program SET: walks all orderings, folds by the binding law, reports admitted/
  refused and the collapse into outcome classes (topology, closure, flow). The
  collapse is the measurement. `imasm export` writes `ob3ects/imasm_manifest.json`
  for the local visual surface `MoDoT/imasm_composer.html` (n8n-style; renders the
  manifest, only SPEAKS command lines; kernel stays the judge). Registry writes
  are atomic (`save_registry`, temp+rename) after a torn-read wipe was recovered
  by replaying `tool_calls`.jsonl.
- `imasm compose <new> <A> <B>`: binds living out-ends to living in-ends. Law:
  composition consumes valences, never mints; composite must re-satisfy grammar;
  a program with no living ends is a finished loop and does not compose
  ([[project_thesis_loops_autopoiesis]] as type discipline). Composites persist
  as wire specs, remain composable while ends remain.
