---
name: project-ig-docs
description: "ig-docs library — centralized real-file index of all IG docs; LIVE at ~/imsgct/ig-docs/ with 740 docs across 13 buckets"
metadata: 
  node_type: memory
  type: project
  originSessionId: 20ebe404-15b1-45d6-93fd-982fbbfeb5b9
---

**IMPLEMENTED.** `~/imsgct/ig-docs/` is live with 740 documents indexed across 13 buckets.

**Architecture:** Real files (not symlinks) moved into ig-docs. `build.py` scans bucket dirs directly and generates `INDEX.md`. Naming convention: `REPONAME__subpath__filename.ext`.

**Topic buckets:** core-theory/, manuscripts/, math/, applications/{chemistry,biology,finance,os-kernel,physics,language}/, bridges/, poetry-alchemy/, agents/, ops/

**Migration history:**
- Phase 1 (`migrate_imscribing_grammar.py`): 453 files from `imscribing_grammar`/ — includes entire `markdown/` subtree (now named `imscribing_grammar__markdown__*`)
- Phase 2 (`migrate_ancillary.py`, 2026-06-14): 124 files from 15 other repos — only ancillary docs; READMEs, proof-supporting papers, pipeline/protocol docs left in repos
- `reverse_migrate_all.py`: reversed a bad bulk migration (`migrate_all.py`) that wrongly swept READMEs and core docs

**Key rule — what moves vs stays:**
- MOVE: standalone essays, explorations, lifted manuscripts, poems, analysis reports not tied to code
- STAY: README.md always, build/dev docs, papers that directly correspond to Lean proofs, pipeline/protocol specs, architecture docs

**Scripts in ig-docs/:** `build.py`, `migrate_imscribing_grammar.py`, `migrate_ancillary.py`, `migrate_all.py` (mistake — keep for reference), `reverse_migrate_all.py`

**How to apply:** When user asks where a doc is, check ig-docs first. When adding new docs, use `REPONAME__subpath__filename.ext` naming and drop in appropriate bucket, then run `python3 build.py` to regenerate INDEX.md.

**MANUSCRIPTS ARE POLISHED HERE, PRIVATELY (updated 2026-07-04).** The user keeps
active manuscripts in `ig-docs/manuscripts/` (this is a PRIVATE repo) "to polish them
away from prying eyes," and removes them from their code repos (e.g. deleted
p4rakernel/manuscripts). This partially supersedes the old "papers corresponding to
Lean proofs STAY in the repo" rule: EDIT + COMPILE manuscripts here. Plain-named here
(NOT the `REPONAME__...` convention), PDF sits next to the .tex (no separate pdfs/).
Compile with `ltx <file>.tex` (2-pass, resolves refs; do NOT run a bare `lualatex`
after ltx — it overwrites the PDF with an unresolved-ref single pass; check overfull
in a scratch copy instead). Trabajo=Shavian, Everson Mono=primitives fonts.
Currently here: `sic_povm_stark_hilbert12.tex` (zenith d=12 SIC paper), 
`belnap_sic_povm_primary.tex` (Belnap-first), `witness_vessel.tex` (new, see
[[project_witness_vessel]]). 2026-07-04: added §8 "The Verification Environment: a
Paraconsistent Kernel" to the zenith paper — kernel ex-falso-disabling mods (3
interception points) + the machine-checked containment "consistent maths is a proper
coreflective subcategory of the paraconsistent" (`ClassicalRestriction.lean`:
`truth_incl_left_adjoint` coreflection, `classical_proper_subcategory`,
`frobenius_closure_inexpressible_classically`). The Belnap-first paper already had a
version of this (§"verification environment"); the zenith paper now at parity + the
inexpressibility strengthening. `\Lean` macro = \textsc{Lean\,4} (already includes
the "4" — never write "\Lean{} 4").
