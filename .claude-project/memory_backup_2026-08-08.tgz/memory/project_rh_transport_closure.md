---
name: project_rh_transport_closure
description: "RH's sole closure blocker (Ω/winding < terminal anchor 3) is removable by transport: joining RH with an already-Ω≥3 catalog type (Hodge, or an exceptional-point regime) reaches idempotent_terminal under most of the 23 gate-universes"
metadata:
  node_type: memory
  type: project
  originSessionId: 5ba516b5-dd4f-427d-b7ff-6c840abbe5ea
  modified: 2026-08-06T19:32:54.809Z
---

Continuation of [[project_jacobian_nonclosing_fork]]'s method (imscribe an open
problem, read its Grammar verdict) applied to RH via the vessel/hop transport
machinery (`m3 hop`, momonados `vessel`/`rh` bridges).

`Clay_UnclosedResistance.rh_closes_nowhere` (p4rakernel/p4ramill,
`native_decide`) proves canonical `riemann_hypothesis` reaches
`idempotent_terminal` under NONE of 23 gate-universes. Sole named cause
(`rh_ns_pnp_low_winding`, kernel-`decide`d): Ω (protection/winding) < terminal
anchor `ah` (3) — RH sits at `oak` (2). NOT criticality: BSD shares RH's exact
`roar` criticality value and still closes; criticality only mattered for a
fixed 2026-07-02 bug (`ordinalPhi`/`ordinalK` are ℚ-valued rank-faithful —
roar=7/3, err=8/3, haha=3 — NOT the simple Core.lean constructor rank; don't
trust `primitives.py`-style integer ordinals for gate arithmetic, always
`decide` from the live function per [[reference_glyph_ordinal_scripture]] —
this bit the session twice over, once historically (documented in the Lean
file itself) and once again in my own first-pass reasoning before I checked).

Tested transport: two EXISTING catalog joins (`rh_ep_join` = RH⊔exceptional-
point, `rh_hc_join` = RH⊔Hodge) both already promote Ω to `ah` (3) — found by
browsing the catalog, not constructed for this. Sourced procedurally (glyph-
inverse map, same pattern as `gen_clay_canonical_tuples.py`) into new
`ClayCandidateTuples.lean`, profiled via `#eval` against the same 23-universe
list (`ClayCandidateProfile.lean`, scratch), then asserted as `native_decide`
theorems in new `Clay_TransportedClosure.lean` (commit 299caee, p4rakernel):
- `rh_hc_join_witnessed_closure`: closes under 16/23 universes AND
  `T_CEILING`-consistent — the SAME two-part bar `bsd_witnessed_closure` /
  `hodge_witnessed_closure` clear.
- `rh_ep_join_gate_closure`: closes under 17/23 (one more: `kinetics_trap`)
  but T_CEILING = false.
- `rh_ep_join_blocker_is_kinetics`: the T_CEILING failure is Ç (kinetics),
  same axis/shape as the existing `ym_blocker_is_kinetics`.

Scope discipline (matches [[feedback_mpp_framing]]): a join is a DIFFERENT
structural type from RH alone, not RH. This is not a proof of RH and doesn't
touch `RH.lean`'s sorries. What's real: the obstruction is ONE axis, kernel-
verified, and removable by transport (join, not hand-edit) — exactly the "hop
to close it" question the session set out to answer.

Open: is there a NATURAL (not just catalog-convenient) join, or a hop
geodesic RATHER than a join, that does the same? `m3 hop --hop-origin
--hop-target --geodesic` between `riemann_hypothesis` and any of the 8
momonados hop anchors (all Ω≥3: hqe, fibonacci, berry, mbl, triple, afdmc,
dyson, troq) is unexplored — the session that started this (c06d196b) was cut
off exactly there, mid-command, on `m3 hop --help`.

Related: [[project_witness_vessel]] (the vessel/hop transport substrate this
used), [[feedback_teach_substrate_not_verdict]] (the register-vs-verdict
thread this grew out of, same session).
