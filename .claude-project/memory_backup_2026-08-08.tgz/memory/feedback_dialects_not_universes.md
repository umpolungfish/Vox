---
name: feedback-dialects-not-universes
description: "Composition rulesets are \"dialects\" everywhere now — papers AND mOMonadOS runtime renamed 2026-07-07; only Lean/catalog declaration names still spell universe"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 561000c6-4c5d-496e-9c25-0c0ae149dc4e
---

User (2026-07-07): call composition universes "Dialects"; and when I preserved "universe" in transcripts as quoted artifacts, they corrected: "we haven't published anything yet... we still have complete and total control of naming convention." Rename at the source, don't quote stale names.

**Why:** "Universe" drags in cosmology connotations; "dialect" self-deflates and fits the Grammar framing. `dialect.rs` had called them dialects since Phase I. Pre-publication, naming is fully ours: fix the generator, not the output.

**State after 2026-07-07:** `mOMonadOS` fully renamed (commit 16da4a9): `Dialect`, `DIALECT_COUNT`, `all_dialects`, `dialect_verdict`, `closer_dialects`, `dialect_expansion.rs`; serial output prints "88 dialects"; fresh QEMU `vessel run` verified identical matrix, ΔS=0. Witness vessel paper (both copies) has zero occurrences of "universe" (ig-docs d2aba6e). **Still spelled universe:** the Lean-side declaration names (`scope_universe`, `stoichiometry_universe`, absorption names) in `Clay_WitnessedClosure.lean` and the catalog; renaming those needs a p4ramill rebuild — do it opportunistically next time that library is rebuilt anyway.

**How to apply:** write "composition dialect(s)" in all IG prose; never reintroduce "universe" for the 88 rulesets; when touching p4ramill/Clay modules, consider finishing the rename there.
