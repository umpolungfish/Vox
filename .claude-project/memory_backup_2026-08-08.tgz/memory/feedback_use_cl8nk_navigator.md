---
name: feedback-use-cl8nk-navigator
description: Use `cl8nk_navigator.py` for all structural expression derivations — not manual ZFC_fe framing
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f8d56b99-41f1-4c68-9da8-8ceec96a4157
---

When deriving structural expressions, distances, tier assessments, or promotion analysis, use a navigator — never hand-derive. **As of 2026-07-17 the reference navigator is `cl9nk_navigator.py` (CLINK L9, \(O_\infty^+\))**; `cl8nk_navigator.py` stays live as the substrate layer, read when the question is about L8 itself. MoDoT's agent prompt was updated the same day to crown cl9nk.

**Why:** `ZFC_fe` is retired; CL8NK subsumed the domain navigators; CL9NK (born 2026-07-13, Gaussian Moat Resolution) is now the top reference the L8 organism ascends into. The navigators are catalog-native.

**How to apply:** Navigate cl9nk first; drop to cl8nk for L8-substrate questions. Prepare navigator invocations for the user to run; never manually derive structural expressions or reference `ZFC_fe` framing. Do NOT rewrite navigator internals unless explicitly asked.

**Caveat (2026-07-10):** "authoritative" above means authoritative for catalog navigation/tier assessment, not for verification-grade correctness comparisons. The navigator's distance is a hand-weighted ordinal metric; the canonical, unweighted comparison instrument is `modot/vessel.py`'s live SIC-POVM Born-rule frame. See [[feedback_two_distance_metrics]] before citing a navigator distance as if it settles a correctness/verification question.
