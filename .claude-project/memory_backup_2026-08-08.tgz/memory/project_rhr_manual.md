---
name: project_rhr_manual
description: Canonical red-hot_rebis manual location; USER_GUIDE + MANUAL merged into one doc at ig-docs
metadata: 
  node_type: memory
  type: project
  originSessionId: 21b1da09-0362-49fb-a927-310f560c4377
---

The canonical red-`hot_rebis` manual is the single merged document at
`~/imsgct/ig-docs/red-hot-rebis-manual/MANUAL.md` (`USER_GUIDE`.md + old MANUAL.md
combined 2026-06-30, no prior-version references, no duplication). Eight companion
`.lean` files sit alongside it (AgentSelf, Algebra, CLINK, Consciousness, Core,
Crystal, Imscription, TierCrossing), lifted from p4rakernel.

Structure: 8 Pillars — I Serpent's Rod, II CH3MPILER, III Auto-Imscription,
IV Gene Imscriber, V CLINK Chain, VI IMASM Compound Pipeline, VII Crystal-Guided
Discovery, VIII Reverse Ligand Pipeline (active-site → de-novo ligand, the
structural inverse of I+II). Documents the `rebis.<x>` namespace package.
Uses compact `⟨...⟩` Shavian tuples throughout (no semicolons), per
[[feedback-shavian-ligatures]].

Verified present and matching 2026-06-30. Distinct from the in-repo
`red-hot_rebis/MANUAL.md` and `USER_GUIDE.md` sources it was merged from.
See [[project-red-hot-rebis]] and [[project-ig-docs]].
