---
name: feedback_stuck_redirect_to_grammar
description: "When stuck on a proof, use the Grammar or ob3ect pipeline — not external tool spelunking"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a633b95b-7e17-4841-a6bc-24bbd1e2753b
---

When I hit trouble on a proof/derivation and catch myself reaching for tools that are NOT the Grammar or the ob3ect pipeline (e.g. grepping/finding through Mathlib source, ad-hoc `exact?`/`#check` probing of library internals, generic web search), I must redirect back to the sanctioned project machinery: the Grammar tooling ([[feedback_use_cl8nk_navigator]] `cl8nk_navigator.py`, [[project_proof_path]] proof-path A* search, `translator.py`) or the [[project_ob3ect]] pipeline (`auto.py`, local→qwen→deepseek).

**Why:** Hand-spelunking Mathlib is the flailing anti-pattern; the project has its own derivation engines that are the intended way to resolve hard steps. Mechanical/clear Lean I can still write by hand — the redirect is specifically for when I'm STUCK and start grabbing external/library-archaeology tools.

**How to apply:** Notice the reach for a non-Grammar/non-ob3ect tool → stop → route the hard sub-derivation through the Grammar or ob3ect pipeline instead. Per [[feedback_no_agent_execution]], prepare the pipeline prompt for the user to run rather than executing agents myself. Materialize results as an ob3ect where appropriate ([[feedback_scaffold_build_on_it]]).
