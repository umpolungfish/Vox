---
name: feedback-write-commit-txt
description: "After making changes in any repo, always write a new `commit.txt` in that repo's root directory"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c74f4536-c7cb-4b09-9f37-8654ffd0f010
---

After making changes in any repository, always write a new `commit.txt` file in that repo's root directory summarizing what was changed.

**Why:** User explicitly requested this as a standing workflow step.

**How to apply:** Any time files are written/edited in a repo (MillenniumAnkh, ob3ect, `imscribing_grammar`, `exOS`, or any other), write `commit.txt` at the repo root before finishing. Content should summarize the changes made in that session.
