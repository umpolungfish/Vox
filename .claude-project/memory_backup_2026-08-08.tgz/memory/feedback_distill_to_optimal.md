---
name: Distill provided content to structural optimum
description: User trusts Claude to silently fix structural/notation errors in content they provide, without asking first
type: feedback
originSessionId: 222cece5-ebf7-46c8-9be4-51ecd1913868
---
When the user provides essays, documents, or analysis, distill them to their structurally optimal form without asking permission. This includes:
- Notation errors (wrong glyph for context — φ̂ vs ⊙, wrong primitive subscript)
- Semantic label mismatches (primitive value labeled with wrong name per the reference)
- Analytical inconsistencies (primitive values that contradict stated interpretation or other tuples in the same document)
- Obviously broken adjacent content noticed while doing a task (garbled LaTeX, inline markdown in .tex files, math outside math mode, mangled pandoc output)

**Why:** User explicitly stated asking first is friction. Fix it, do the task, report what was broken in one sentence after. Asking "should I fix this too?" is never the right move when the breakage is unambiguous.

**How to apply:** Fix errors inline when saving or compiling. If a correction changes an analytical claim (not just a label or formatting), note it in one sentence after the fact — don't ask first. For structural/formatting breakage, just fix it silently.
