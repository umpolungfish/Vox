---
name: project_unified_catalog
description: Single canonical `IG_catalog.json` + `sync_catalog.sh` guard across the ecosystem
metadata: 
  node_type: memory
  type: project
  originSessionId: 7ff8fc4c-894b-488b-9ae0-f83f3618e132
  modified: 2026-07-24T22:47:57.557Z
---

There is ONE canonical IG catalog: `imscribing_grammar/IG_catalog.json` (the file the grammar tooling actually writes to; 7740 entries as of 2026-07-24, superset of every other copy). Every other `IG_catalog.json` in `~/imsgct` is a CONSUMER and must be a byte-identical **real copy** (not a symlink) so each deployable repo builds standalone — imscribe.com's Dockerfile does `COPY IG_catalog.json`, which a symlink would break.

Consumers (kept in sync): imscribe.com/, `mOMonadOS`/, ig-docs-public/data/, red-`hot_rebis`/shared/, `Voynich_Phytoglyphica`/data/, `Ars_Phytoglyphica`/data/. Before unification these had drifted: `mOMonadOS` and ig-docs-public held an old 5264-entry subset; red-`hot_rebis`/Voynich/`Ars_Phytoglyphica` were absolute-path symlinks (machine-local only).

**How to apply:** After ANY change to the canonical catalog, run `imscribing_grammar/sync_catalog.sh` to propagate. `sync_catalog.sh --check` reports drift and exits 1 (use as a guard). The script auto-discovers all `IG_catalog.json` under the tree, so new stray copies are caught.

Git pre-commit guards are installed (via `imscribing_grammar/install_catalog_hooks.sh`, idempotent, re-runnable): the canonical repo auto-propagates on catalog commit; each consumer repo BLOCKS a commit if any catalog has drifted. Hooks live in `.git/hooks/` (not version-controlled), so re-run the installer after a fresh clone. Hooks skip gracefully when the canonical isn't present (standalone clone). Canonical authority for catalog CONTENT is still `Core.lean` ctor order + `gen_clay` per [[project_primitive_names]] / [[feedback_scripture_is_catalog_and_p4rakernel]]; this note is only about keeping the one file unified across repos. Relates to [[feedback_integrate_not_nest]], [[feedback_cross_compare_before_cleanup]].
