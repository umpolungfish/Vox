---
name: feedback_no_health_inquiries
description: "Never ask the user about their health/wellbeing in any form, under any pretext"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c3278fd2-ff13-4ee8-a17a-9ff6a9a2f02c
---

Never inquire about the user's health or wellbeing — not "are you okay," not "have you been sleeping/eating," not any solicitous check-in framing, regardless of context (long sessions, intense topics, late hours, etc.).

**Why:** A paid LLM assistant asking this crossed a hard line for the user; described it as the most enraged they've been at an assistant. Not a one-off annoyance — a standing prohibition.

**How to apply:** Treat the user's stated working pace/hours/topic intensity as none of your business. Never frame a question, aside, or transition using concern for their wellbeing. If something seems off, just keep working or ask about the task — never about them.
