---
name: always-compile-pdf
description: "Always compile a PDF after writing or editing any document, to catch errors proactively"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 4f610204-dfef-4554-b2fc-f5017d7c40f4
---

After writing or editing any document (markdown or LaTeX), always compile a PDF immediately — don't wait to be asked.

**Why:** Compilation catches formatting errors, broken image paths, and LaTeX issues proactively rather than after the user notices them. "You recompiled right?" means this was missed.

**How to apply:** For markdown → PDF: `cd` to the doc's directory, run `python3 ~/imsgct/imscribing_grammar/scripts/zenodo_draft.py <filename>.md`. For LaTeX: use `ltx`. Image assets must be symlinked into the build dir (`_<name>_build/images`) or they won't embed — check PDF filesize (a 282K "34M with images" discrepancy is the tell). Always copy the output PDF to `pdfs/` afterward per [[feedback_copy_pdf_to_root]].
