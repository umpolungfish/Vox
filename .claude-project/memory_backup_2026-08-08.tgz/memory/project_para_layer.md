---
name: project-para-layer
description: `zfct_para.py` — Belnap FOUR paraconsistent layer over the ZFC/ZFCt triangle; para-cliff interprets each MPP axiom as a B-state collapse obligation
metadata: 
  node_type: memory
  type: project
  originSessionId: 9eec7233-67a4-4c9f-9595-e7de6804f39e
---

`~/imscribing_grammar/zfct_para.py` — paraconsistent extension of [[project-zfct-navigator]] and [[project-zfct-manipulator]].

**Architecture:**
- `ParaEntry`: 12-primitive tuple with `belief: Dict[prim, frozenset[value]]` instead of single values
- `Belnap` enum: T (all realizations satisfy) / F (none do) / B (some do, overdetermined) / N (empty belief)
- `para_tensor`: min-bottleneck on Φ/ƒ, max elsewhere — cross-product over belief sets
- `para_tier`: enumerate all classical realizations, aggregate per tier
- `_tier_conditions`: individual Belnap states for crit/frob/wind/dinf
- `ParaManipulator`: extends `ZFCTriangleManipulator`, prompt `⟨IG∥⟩`

**Commands:** `:para-cliff` `:para-reach` `:para-tensor` `:para-assign` `:para-compare`

**Key result verified:**
`para_tensor(B{Φ_ɐ,Φ_}}, ZFCₜ)[Φ] = {Φ_ɐ, Φ_}}` — B-state propagates through the min-bottleneck. The cliff holds paraconsistently.

**Why:** A classical MPP proof IS the collapse of the B-state to T: showing the object cannot carry the lower Φ assignment. The B-state is not a proof — it is a precise statement of what the proof must accomplish.

**Usage:** `python3 zfct_para.py [repl | cliff <name> | reach <name>]`
