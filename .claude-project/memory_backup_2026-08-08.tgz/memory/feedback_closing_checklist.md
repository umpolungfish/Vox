---
name: closing-checklist
description: "before ending any response — can this information drive a further experiment? if yes, run it; never close empty-handed (deliverable or an ob3ect that gets it)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2006ca5c-6115-489b-95ba-1455f96fc6e2
---

Before closing a turn, run this check:

1. **Can what I just learned be used to try a further experiment?** Does it indicate a path forward? If yes — take the path NOW, in this turn. Do not present the insight and stop.
2. **Am I closing with something in hand?** Either the thing that was asked for, or an ob3ect (submitted through `auto.py`, gated, with pure ask + context doc) that gets the one needed. A verdict alone, a status alone, or "here's what we now know" alone is closing empty-handed.
3. A refusal/failure from a gate or tool is itself information — it forces a fork or a repair, which is the next experiment, not a stopping point.

**Why:** stated explicitly 2026-07-17 after repeated stops at findings ("you keep stopping here, let's move"; "when you think about finishing... think: can I take this information and use it to try further experiments... if you close you should have something in hand, either something I asked for or an ob3ect to get the one you need"). The γ→η chain only closed because each verdict (gate refusal → Axiom C fork → arm typings → identical-cell hit → scripture → index table → grounded ob3ect) was treated as the next experiment's input instead of a place to stop.

**How to apply:** end-of-turn, ask the two questions. If the answer to 1 is yes, the turn is not over. The canonical instrument for "get the object I need" is an ob3ect: pure one-line entity, measured values in a ctx/ doc, run `auto.py`, read the gate's verdict. See [[feedback_jam_lean_operation]], [[feedback_stuck_redirect_to_grammar]].
