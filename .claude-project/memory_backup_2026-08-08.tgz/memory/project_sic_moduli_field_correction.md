---
name: project-sic-moduli-field-correction
description: "SIC moduli field: NOT totally real, one infinite place ramified. Conductor p2^(v2(d)+1)*odd*oo1 modulo class group where h>1. d=2048 = 2^21 over F. Verified 2026-07-25 by height-stability."
metadata:
  node_type: memory
  type: project
---

Moduli field of a Zauner-symmetric WH fiducial, identified from the fiducial itself (primitive element Σ k·N_k), not by enumerating subfields of the coordinate field:

| d | deg /Q | signature | conductor | ∞ | deg over F |
|---|---|---|---|---|---|
| 4 | 8 | (4,2) | p2^3 | one place | 4 |
| 8 | 16 | (8,4) | p2^4 | one place | 8 |
| 12 | 16 | (8,4) | p2^3·p3 | one place | 8 |

**Rule:** conductor = p2^(v2(d)+1) · (primes over odd p | d) · ∞₁; field = full ray class field there, **modulo the class group** where h(F)>1. d=16: p2^5∞₁, order 256 → 128 over F. d=2048: p2^12∞₁, order 2^27 → **2^21 over F, 2^22 over Q**.

**NOT totally real** — one archimedean place ramifies, so `bnrstark` refuses it and the mixed-signature Stark conjecture IS required. The chrysopoeia manuscript was right; the 2026-07-25 draft claiming total reality was wrong.

**Method, which cost a session:** integer relation reports membership in fields that do not contain the element when precision leaves room to fit noise. A genuine relation's coefficient **height is stable as precision rises**; a fitted one grows. The d=12 octic membership gave 177→287→435 bits at 600/900/1300 digits = fabricated. Genuine: N_1 minpoly degree 8 at 33 bits, Σk·N_k degree 16 at 80 bits, both constant. Also `coords_uhi.gp` is good to only ~1650 digits; relations sought beyond that fit digits that are not there.

Class-group half is independent and settled: [[project_d16_class_group_settlement]].
