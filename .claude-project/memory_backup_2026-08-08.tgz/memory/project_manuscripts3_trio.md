---
name: project-manuscripts3-trio
description: "manuscripts3 SIC trio (zenith / chrysopoeia_2048 / witness_vessel) — canonical in ig-docs/manuscripts3/, publishing copies in ig-docs_lifted/manuscripts3/*`_lifted.tex`; tetractys pass completed 2026-07-07"
metadata: 
  node_type: memory
  type: project
  originSessionId: 561000c6-4c5d-496e-9c25-0c0ae149dc4e
---

The three companion SIC papers live in TWO trees:
- **Canonical sources:** `ig-docs/manuscripts3/{sic_povm_stark_hilbert12,chrysopoeia_2048,witness_vessel}.tex` (compiled in place; PDFs also copied to ig-docs `pdfs/` AND `pdfs3/`).
- **Lifted publishing copies:** `ig-docs_lifted/manuscripts3/<name>/<name>_lifted.tex` (editorial variants: de-branded title "A Formalization…" without "Lean 4", author "C. Lando Mills", rewritten abstract; produced via ob3ect editorial pipeline, `ob3ect/igdocs_editorial_yamls/`). PDF sits next to the tex plus a duplicate at `ig-docs_lifted/manuscripts3/` root. ig-`docs_lifted` is NOT a git repo; ig-docs is.
- The OLD `ig-docs/manuscripts/sic_povm_stark_hilbert12.tex` ("the Stark Conjecture… A Lean 4 Formalization", Lando⊗⊙perator author line, has §8 verification environment) is a different, earlier generation; manuscripts3 is the current one. Chrysopoeia exists only in manuscripts3/lifted.

**Tetractys pass 2026-07-07 (ig-docs commit 3335d38), all six files fixed + recompiled:** unit-convention gap axioms (zenith §3.5 had the impossible norm-d pair; Lean was already correct), d≥4 hypotheses, Appleby refs corrected (AYZ QIC 2013 / AFMY FoP 2017 / AFMY Acta Arith 2020), moduli-field correction per [[project-sic-moduli-field-correction]] (chrysopoeia now says degree 2²⁷, mixed moduli degrees 4/8, not totally real), BSD "exactly five closer" → "twelve, closers among them", universes → dialects per [[feedback-dialects-not-universes]], MPP out of bundle prose, title/font/URL-stub mechanics. Companion citation in chrysopoeia matches the lifted zenith title.
