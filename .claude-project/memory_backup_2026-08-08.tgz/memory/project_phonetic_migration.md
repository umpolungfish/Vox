---
name: Phonetic primitive migration — complete symbol table
description: Full 49-symbol phonetic renaming applied 2026-05-08; actual code IDs are the glyph strings (e.g. Ð_ω not D_omega); imscribing_grammar is the new primary project
type: project
originSessionId: dbb84d60-7570-4135-9539-892558bb4451
---
`imscribing_grammar` (`~/imscribing_grammar`) is the primary project. `synthomniconP` is now the preparation archive.

**The IDs ARE the glyphs.** `Ð_ω` is the actual identifier, not `D_omega`. The human-readable name (e.g. "`D_omega`") is for reference only — never use it in code, tuples, or docs.

**LaTeX display:** use the glyph characters directly, e.g. `$Ð_\omega$`, `$⊙_ÿ$`.

**How to apply:** Always use glyph IDs in all code, tuples, catalog values, docs. Old names still accepted by `from_symbol()` in `imscribing_grammar/imscrbgrmr/models.py` for backward compat.

---

## Complete mapping — Code ID | Glyph pair | Human name | TIPA | Old ID

### Ð — Dimension (was D)
| Code ID | Glyph | Human name | TIPA | Old |
|---------|-------|------------|------|-----|
| `Ð_ß` | Ð+ß | wynn | \textwynn | `D_wedge` |
| `Ð_C` | Ð+C | turnthree | \textturnthree | `D_triangle` |
| `Ð_;` | Ð+; | invomega | \textinvomega | `D_infty` |
| `Ð_ω` | Ð+ω | omega | \textomega | `D_odot` |

### Þ — Topology (was T)
| Code ID | Glyph | Human name | TIPA | Old |
|---------|-------|------------|------|-----|
| `Þ_6` | Þ+6 | nrleg | \textnrleg | `T_network` |
| `Þ_K` | Þ+K | invscr | \textinvscr | `T_in` |
| `Þ_ò` | Þ+ò | bullseye | \textbullseye | `T_bowtie` |
| `Þ_¨` | Þ+¨ | commatailz | \textcommatailz | `T_boxtimes` |
| `Þ_O` | Þ+O | openo | \textopeno | `T_odot` |

### Ř — Relational Mode (was R)
| Code ID | Glyph | Human name | TIPA | Old |
|---------|-------|------------|------|-----|
| `Ř_¯` | Ř+¯ | subrightarrow | \textsubrightarrow | `R_super` |
| `Ř_ý` | Ř+ý | ctz | \textctz | `R_cat` |
| `Ř_Ť` | Ř+Ť | downstep | \textdownstep | `R_dagger` |
| `Ř_=` | Ř+= | lyoghlig | \textlyoghlig | `R_lr` |

### Φ — Parity/Symmetry (was P)
| Code ID | Glyph | Human name | TIPA | Old |
|---------|-------|------------|------|-----|
| `Φ_ɐ` | Φ+ɐ | aolig | \textaolig | `P_asym` |
| `Φ_υ` | Φ+υ | upsilon | \textupsilon | `P_psi` |
| `Φ_F` | Φ+F | pipevar | \textpipevar | `P_pm` |
| `Φ_˙` | Φ+˙ | subdoublearrow | \textsubdoublearrow | `P_sym` |
| `Φ_}` | Φ+} | doublebarpipe | \textdoublebarpipe | `P_pm_sym` |

### ƒ — Fidelity (was F)
| Code ID | Glyph | Human name | TIPA | Old |
|---------|-------|------------|------|-----|
| `ƒ_ì` | ƒ+ì | beltl | \textbeltl | `F_ell` |
| `ƒ_ð` | ƒ+ð | dh | \dh | `F_eth` |
| `ƒ_ż` | ƒ+ż | hardsign | \texthardsign | `F_hbar` |

### Ç — Kinetics (was K)
| Code ID | Glyph | Human name | TIPA | Old |
|---------|-------|------------|------|-----|
| `Ç_-` | Ç+- | frtailgamma | \textfrtailgamma | `K_fast` |
| `Ç_W` | Ç+W | turnm | \textturnm | `K_mod` |
| `Ç_@` | Ç+@ | schwa | \textschwa | `K_slow` |
| `Ç_Ù` | Ç+Ù | teshlig | \textteshlig | `K_trap` |
| `Ç_λ` | Ç+λ | lambda | \textlambda | `K_MBL` |

### Γ — Scope (was G)
| Code ID | Glyph | Human name | TIPA | Old |
|---------|-------|------------|------|-----|
| `Γ_β` | Γ+β | beta | \textbeta | `G_beth` |
| `Γ_γ` | Γ+γ | gamma | \textgamma | `G_gimel` |
| `Γ_ʔ` | Γ+ʔ | revapostrophe | \textrevapostrophe | `G_aleph` |

### ɢ — Interaction Grammar (was Gamma)
| Code ID | Glyph | Human name | TIPA | Old |
|---------|-------|------------|------|-----|
| `ɢ_^` | ɢ+^ | corner | \textcorner | `G_and` |
| `ɢ_˝` | ɢ+˝ | spleftarrow | \textspleftarrow | `G_or` |
| `ɢ_ˌ` | ɢ+ˌ | secstress | \textsecstress | `G_seq` |
| `ɢ_Ş` | ɢ+Ş | doublevertline | \textdoublevertline | `G_broad` |

### ⊙ — Criticality (was Phi, formerly φ̂)
| Code ID | Glyph | Human name | TIPA | Old |
|---------|-------|------------|------|-----|
| `⊙_ž` | ⊙+ž | softsign | \textsoftsign | `Phi_sub` |
| `⊙_ÿ` | ⊙+ÿ | ctyogh | \textctyogh | `Phi_c` |
| `⊙_Æ` | ⊙+Æ | closerevepsilon | \textcloserevepsilon | `Phi_c_complex` |
| `⊙_3` | ⊙+3 | revepsilon | \textrevepsilon | `Phi_EP` |
| `⊙_Ţ` | ⊙+Ţ | upstep | \textupstep | `Phi_super` |

### Ħ — Chirality (was H)
| Code ID | Glyph | Human name | TIPA | Old |
|---------|-------|------------|------|-----|
| `Ħ_Ñ` | Ħ+Ñ | closeomega | \textcloseomega | `H0` |
| `Ħ_£` | Ħ+£ | toneletterstem | \texttoneletterstem | `H1` |
| `Ħ_A` | Ħ+A | turntwo | \textturntwo | `H2` |
| `Ħ_!` | Ħ+! | invscripta | \textinvscripta | `H_inf` |

### Σ — Stoichiometry (was S)
| Code ID | Glyph | Human name | TIPA | Old |
|---------|-------|------------|------|-----|
| `Σ_S` | Σ+S | doublebaresh | \textdoublebaresh | `one_one` |
| `Σ_ő` | Σ+ő | ctn | \textctn | `n_n` |
| `Σ_ï` | Σ+ï | ltailm | \textltailm | `n_m` |

### Ω — Topological Invariant (was Omega)
| Code ID | Glyph | Human name | TIPA | Old |
|---------|-------|------------|------|-----|
| `Ω_Å` | Ω+Å | closeepsilon | \textcloseepsilon | `Omega_0` |
| `Ω_2` | Ω+2 | crtwo | \textcrtwo | `Omega_Z2` |
| `Ω_z` | Ω+z | dzlig | \textdzlig | `Omega_Z` |
| `Ω_5` | Ω+5 | turna | \textturna | `Omega_NA` |

---

## `odot_operator` tuple — actual code IDs
`Ð_ω; Þ_¨; Ř_=; Φ_}; ƒ_ż; Ç_@; Γ_ʔ; ɢ_ˌ; ⊙_ÿ; Ħ_A; Σ_S; Ω_z`
