---
name: project-imscribing-grammar
description: imscribing_grammar Lean repo status — Shavian constructor migration complete 2026-06-20
metadata: 
  node_type: memory
  type: project
  originSessionId: 737e3c4c-c1ab-4e7a-8e7e-f180e7146a4e
---

Lean 4 formalization of the IG at `~/imsgct/imscribing_grammar/`.

## Shavian constructor migration — COMPLETE (2026-06-20)

All 49 inductive constructors in `ImscribingGrammar/Primitives/Core.lean` (and 15 dependent files) have been renamed from old phonetic-description identifiers to canonical Shavian letter names. Zero old names remain in any active file (verified by grep). The `.archive/` and `.stuff/` dirs were not touched.

**The old names are permanently dead.** If you see `K_lambda`, `F_beltl`, `G_beta`, `S_doublebaresh`, `D_wynn`, etc. in any active Lean file, it is a regression or an unmigrted file.

Full mapping (old → new):

| Primitive | Old → New |
|-----------|-----------|
| Dimensionality | `D_wynn`→dead, `D_turnthree`→ash, `D_invomega`→array, `D_omega`→if' |
| Relational (Ř) | `R_subrightarrow`→ado, `R_ctz`→tot, `R_downstep`→ear, `R_lyoghlig`→ian |
| Grammar (Γ) | `Gamma_and`→vow, `Gamma_or`→gag, `Gamma_seq`→measure, `Gamma_broad`→ooze |
| Chirality (Ħ) | `H_closeomega`→fee, `H_toneletterstem`→kick, `H_turntwo`→sure, `H_invscripta`→wool |
| Protection (Ω) | `Omega_closeepsilon`→awe, `Omega_crtwo`→oak, `Omega_dzlig`→ah, `Omega_turna`→zoo |
| Topology (Þ) | `T_nrleg`→judge, `T_invscr`→eat, `T_bullseye`→mime, `T_box`→oil, `T_openo`→are |
| Polarity (Φ) | `P_aolig`→church, `P_upsilon`→yew, `P_pipevar`→out, `P_subdoublearrow`→nun, `P_doublebarpipe`→or' |
| Criticality (⊙) | `Phi_softsign`→woe, `Phi_ctyogh`→monad, `Phi_closerevepsilon`→roar, `Phi_revepsilon`→err, `Phi_upstep`→haha |
| KineticChar (Ç) | `K_frtailgamma`→yea, `K_turnm`→loll, `K_schwa`→egg, `K_teshlig`→on, `K_lambda`→air |
| Fidelity (ƒ) | `F_beltl`→age, `F_dh`→they, `F_hardsign`→peep |
| Granularity (ɢ) | `G_beta`→bib, `G_gamma`→thigh, `G_revapostrophe`→ice |
| Stoichiometry (Σ) | `S_doublebaresh`→hung, `S_ctn`→so, `S_ltailm`→up |

Files updated: `Core.lean`, `Imscription.lean`, `CLUPrimitives.lean`, `TierCrossing.lean`, `PrimitiveMismatch.lean`, Millennium/{BSD,Hodge,NS,OPN,PvsNP,FrobeniusStructure,PrimitiveBridge,PrimordialOoze,`RH_Formal`,Barriers}.lean, `Manuscript_ZFCt.lean` (16 total).

**Why:** Old names were phonetic-description identifiers inherited from a pre-Shavian era. They conflicted with the canonical notation used everywhere else in the project (p4rakernel, ig-docs, etc.), creating a two-system confusion hazard.

**How to apply:** When editing any `imscribing_grammar` Lean file, use only the new short names (dead/ash/array/if', ado/tot/ear/ian, etc.). Never reintroduce the K_/F_/G_/S_/D_/R_/Gamma_/H_/Omega_/T_/P_/Phi_ prefix form.

Links: [[feedback-shavian-is-standard]] [[project-primitive-names]]
