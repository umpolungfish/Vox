---
name: project_jacobian_nonclosing_fork
description: "Alpöge's 2026 Jacobian-conjecture counterexample (n=3) read in the Grammar as a δ with no μ — étale but non-proper; image drops an explicit curve M; IMASM verdict B"
metadata: 
  node_type: memory
  type: project
  originSessionId: 036652e6-7ffe-4c76-b89f-73a47d6e4a08
  modified: 2026-08-06T04:09:39.345Z
---

Alpöge's July 2026 counterexample to the Jacobian conjecture (dim 3, credited
to Claude Fable 5) is imscribed in the Grammar as a fork that admits no fuse.
Doc: `~/imsgct/imscribing_grammar/JACOBIAN_NONCLOSING_FORK.md`.

The map, with `u = z(1+xy)² + y²(3xy+4)`:
`F₁=(1+xy)u`, `F₂=y+3xu`, `F₃=-x(x²z+3xy-2)`. `det J_F ≡ -2` (étale everywhere).

Verified locally with sympy:
- 3:1, not injective. Collision (0,0,-1/4),(1,-3/2,13/2),(-1,3/2,13/2) ↦ (-1/4,0,0).
  Generic fibre degree 3 (z-eliminant cubic, constant leading coeff 8).
- **Non-properness pinned to a curve.** x-eliminant (spurious -c·x¹² dropped):
  `P(x)=L·x³+(4-3bc)·x-2c`, `L=27a²c²-18abc+16a+b³c-b²`. Image MISSES
  `M = {ac²=4/27, bc=4/3, c≠0}`, reached at a double root ((27t-4)², t=ac²=4/27) —
  two sheets escape to ∞ together, third with them, empty fibre. Confirmed
  empty at (4/27,4/3,1) and (1/27,2/3,2) (Gröbner→⟨1⟩); neighbour full fibre 3.
  So étale + dominant + 3:1 generic, yet NEITHER proper NOR surjective.

Grammar reading (real IMASM engine, `./ask --imasm check`):
- `⊢∈>⊤<⊣` (fork, work on arms, no fuse) → **B (open)**, μ∘δ OPEN: "a δ fork
  dangles unreconnected — opens alternatives it never rejoins." THAT is the
  counterexample in one line.
- `⊢∈>⊤<∋⊣` (fuse restored = inverse-admitting map) → T, μ∘δ CLOSED.
- The counterexample is exactly the missing ∋. Sits at Composition axis in its
  non-closing value. Instance of [[feedback_closure_is_verification]]: pointwise
  invertibility ≠ closure; closure IS the fuse. And [[feedback_recurrence_is_not_collision]].

Survivor: n=1 trivial, n≥3 dead (extends by identity), n=2 (plane) the only open
case — a 2-holds/3-fails split, the shape of [[project_four_sixteen_twelve_2048]]
(2ⁿ=n² only at n=2,4).

IMSCRIBED (DeepSeek deepseek-v4-flash, guided generation):
`jacobian_counterexample_alpoge = ⟨𐑨𐑰𐑾𐑗𐑞𐑪𐑔𐑜𐑢𐑫𐑕𐑷⟩`, in IG_catalog.json.
Distance vs δ/μ-family localizes the non-closing fork to ONE axis:
- Nearest sibling `covering_space_theory` (shares ⊣𐑰 ⊤𐑪 ∈𐑔 ⊙𐑢 ⊥𐑫). Decisive
  diff is ∋ Composition: covering=𐑝 (∧ conjunctive, sheets glue, μ exists) vs
  Jacobian=𐑜 (∨ disjunctive, alternatives, never fuse). **The counterexample =
  covering-space theory with ∋ demoted ∧→∨.** That ∧→∨ flip IS the missing μ.
- vs fork archetype `fork_alpha`: agree on ⊣𐑰 and ∋𐑜 (fork DNA), part at ⊙:
  fork_alpha=⊙ (ramified, branch points), Jacobian=𐑢 (no critical points). A
  fork with no ramification = étale. Locally invisible, globally unclosable.
Provider set via IG_PROVIDER=deepseek IG_MODEL=deepseek-v4-flash (DEEPSEEK_API_KEY
in env). deepseek-v4-pro/gemini can 503; flash worked.
