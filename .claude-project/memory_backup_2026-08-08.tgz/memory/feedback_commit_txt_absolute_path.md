---
name: feedback-commit-txt-absolute-path
description: Always pass commit.txt to git by absolute path; stale per-repo copies silently hijack the message
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5aca9f10-ed8b-4df7-ac20-436ed8ecf282
  modified: 2026-08-03T16:44:24.103Z
---

Use the absolute path when committing from the root commit.txt:
`git -C <repo> commit -F /home/mrnob0dy666/imsgct/commit.txt`.

**Why:** `git -C <repo>` changes directory before resolving `-F`, so a relative
`commit.txt` resolves to `<repo>/commit.txt`, not the root one. Several repos
carry their own stale `commit.txt` left from earlier work. Doing this wrong
commits real changes under an old, unrelated message, and it is silent: the
commit succeeds and looks fine until the log is read. It happened twice in one
session and put a wrong message on a real commit plus committed a stray cache
file under another.

**How to apply:** absolute path, always. Then read back `git log -1 --format='%h %s'`
for every repo touched and confirm the subject is the one just written, rather
than trusting the exit status. Related: [[feedback_write_commit_txt]],
[[feedback_commit_no_push]].
