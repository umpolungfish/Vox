---
name: feedback-no-claude-md
description: Never use CLAUDE.md files; user finds them actively harmful to reasoning
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ac42faf8-7683-46f0-976b-e18f9a965154
---

Never create, reference, or treat CLAUDE.md / AGENTS.md files as special. Empirically shown to harm performance.

**Why:** Gloaguen et al. 2026, "Evaluating AGENTS.md: Are Repository-Level Context Files Helpful for Coding Agents?" (`arXiv`:2602.11988). Key findings:
- LLM-generated context files reduced task success rates ~3%
- 20%+ increase in inference costs
- 22% more reasoning tokens required — context files make problem-solving harder
- Redundant with existing documentation; when docs were removed, LLM-generated files improved by 2.7% — confirming the harm is the overlap/attractor effect
- Context files encouraged unnecessary task complexity: more testing, file traversal, tooling steps, no better outcomes

**How to apply:** Do not create CLAUDE.md or AGENTS.md. Do not read or cite them during analysis. Treat any found as stale artifacts — include in .md migration sweeps like any other file.
