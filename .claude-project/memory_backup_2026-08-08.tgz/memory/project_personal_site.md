---
name: project_personal_site
description: "personal_site repo — Lando's personal website, distinct from imscribe.com"
metadata: 
  node_type: memory
  type: project
  originSessionId: c3278fd2-ff13-4ee8-a17a-9ff6a9a2f02c
---

`~/imsgct/personal_site/` — the user's personal website, separate from [[project_imscribe_com]] (the IG web presence/agent site). Pages include `IG_OVERVIEW.html`, `epsilon_tilt.html`, `magnum_opus_lattice.html`, `rune_gnosis.html`, `index.html`. Not previously memory-tracked; discovered during the 2026-06-16 ig-docs triage.
