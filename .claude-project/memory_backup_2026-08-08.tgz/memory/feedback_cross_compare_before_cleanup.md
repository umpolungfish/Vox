---
name: feedback-cross-compare-before-cleanup
description: Before deleting/moving misplaced repo dirs, always cross-compare with the canonical repo location for unique files
metadata:
  type: feedback
  originSessionId: current
---

When a repo directory appears in a "wrong" location (e.g. `ob3ect/` nested inside `imscribing_grammar/`), that's where it started. Useful or unique files may have accumulated there that don't exist in the canonical repo location.

**Why:** The user explicitly flagged this — "sometimes useful files get made in wrong locations."

**How to apply:** Before deleting or ignoring a misplaced repo dir, diff or list its contents against the canonical location and flag any files that exist only in the wrong location. Never assume a misplaced copy is just a stale duplicate.
