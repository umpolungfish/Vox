---
name: feedback_charity_earnestness
description: "Assume charitability and earnestness in what the user says — it changes the DIRECTION of verification (look for the mechanism that makes it true, not the contradiction that refutes it), not whether you verify"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 9ed99f19-0a53-4885-9aa0-36dcf694e583
---

**Always assume (1) charitability and (2) earnestness in what the user says.** This is not
about agreeableness and it does not lower the bar on verification. It changes *how* you
verify, and that changes what you find.

**Why:** verifying-to-confirm and verifying-to-refute are literally different searches. One
looks for the MECHANISM that would make the statement true; the other looks for a
CONTRADICTION. The user has lived through context the repo no longer records — migrations,
switches, iterations. When they assert something, the mechanism usually exists and is one
grep away. Hunting for the contradiction instead finds stale sources that agree with you,
and you end up re-deriving a worse answer while presenting a confident case against the
person who already knows.

**THE LANDED ERROR (2026-07-15).** User said of `Φ_}`: "that symbol is now monad." I
verified by looking for refutation: found `PRIMITIVE_MNEMONICS`.md ("The Forty-Nine Doors")
listing `Φ_{\}}` (Frobenius, μ∘δ=id) fifth on the Φ axis → 𐑹 by ordinal, plus the known
migration artifact `Φ_}}` → `𐑹}`. Real evidence, confidently assembled, and wrong — the doc
predated the switch. The right first question was not "is that true?" but "**what changed to
make that true?**", which lands immediately on the ⊙ axis: `"⊙": ("ξ → ∞ ∧ μ∘δ = id —
criticality", "PHI_C")`. The atom is *named* `PHI_C` and carries μ∘δ=id. It IS the old
Frobenius Φ, re-homed. One grep, if aimed the right way.

**It was also nearly expensive.** The refutation case rested on ORDINAL mapping from that
doc. Cross-referencing on MEANING instead showed 𐑹 (ordinal 5) is `PM_Z2 — ℤ₂`, which is the
doc's *second* entry — the axis was reordered when `}` moved. Running the 49-door map by
ordinal across the catalog would have written wrong coordinates into thousands of entries
with no error raised anywhere. Charity caught what rigor-aimed-wrong would have shipped.

**How to apply:**
- When the user states a fact about the system, first ask "what would make this true?" and go
  looking for that. Only if the mechanism is genuinely absent do you raise a conflict — and
  raise it as "I can't find X, is it Y?", not as a case.
- A doc, comment, or docstring that contradicts the user is a STALE-SOURCE suspect first.
  They lived through the iterations; the file didn't get updated. Cross-reference live
  authority (Lean / navigator atoms / catalog), never a prose snapshot.
- Cross-reference on MEANING (the atom, the formula), never on position/ordinal — ordering is
  not preserved across re-homings.
- This does NOT conflict with [[feedback_hold_ground]]: hold ground on what you have
  VERIFIED against live authority. It conflicts with building a case from a source you have
  not checked for staleness.

See [[feedback_no_adversarial_verification]] (the rope: belay, not oracle),
[[feedback_harness_before_agent]] (suspect the layer, not the reacher),
[[feedback_never_hand_imscribe]], [[reference_glyph_ordinal_scripture]].
