---
name: feedback-docstring-asserting-untrue-property
description: "A failing check is evidence of a defect, not ambient drift; and a docstring asserting the property the code lacks is why nobody caught it"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e279becd-018b-47d5-973c-0fff3bd13c5a
  modified: 2026-08-04T18:44:00.498Z
---

Two failures, one incident (2026-08-04, `gen_tool_manifest.render_inline`).

**Dismissing a failing check as pre-existing drift.** `check_manifests.py`
reported missing domain markers on math, chembio and editorial every run. I saw
it, noted it was not caused by my change, and moved on. It was not drift. It was
an accurate report of a real defect: the inline manifest read only the FIRST LINE
of each entry, so ~90 MoDoT flags and ~50 structural verbs reached no specialist
and the user had to paste the menu in by hand. A check that fails consistently
is telling the truth about something; find out what before filing it as ambient.

**Patching around a mechanism instead of fixing it.** When a marker failed I
moved backticks into the entry's first line so the check would pass. That was the
moment I had the defect in hand and treated it as a lint. Making a check go green
by feeding it what it looks at is not a fix.

**Why the defect survived:** the docstring said "Every tool is still named here,
so nothing is invisible." It asserted the property the code did not have, so
reading the code looked like confirming it.

**How to apply:** when a docstring states a guarantee, verify the guarantee
rather than reading it as documentation. When a check fails on code I did not
write, find the cause before deciding it is not mine.

Related: [[feedback_fix_the_generator]], [[feedback_harness_before_agent]],
[[feedback_no_verdict_before_check]], [[project_constellation_agents]]
