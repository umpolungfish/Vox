---
name: feedback-never-publish-to-ig-docs-public
description: "Never copy manuscripts, figures or data into ig-docs-public; publication there is the user's decision alone"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e279becd-018b-47d5-973c-0fff3bd13c5a
  modified: 2026-08-04T22:56:12.983Z
---

`~/imsgct/ig-docs-public/` is a **public** mirror. Never write to it.

**Why:** copying a manuscript there publishes it. On 2026-08-04 I "refreshed
stale copies" of a paper across every directory that held one and swept
ig-docs-public in with the rest, pushing an unreleased draft and its figures into
the public tree. Reverted with `git checkout --` before any commit, but the
default was wrong, not the outcome.

**How to apply:** when syncing build outputs across the constellation, enumerate
targets and drop `ig-docs-public` explicitly. The live working copy is
`ig-docs/`; `ig-docs-public` and `ig-docs-lifted` are downstream and are the
user's to update. If a task seems to require writing there, ask first.

Related: [[project_ig_docs]], [[feedback_no_cloud_artifacts_default]],
[[feedback_commit_no_push]], [[project_zenodo_all]]
