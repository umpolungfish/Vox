---
name: feedback_harness_before_agent
description: "When a MoDoT run looks like it is flailing, the HARNESS is the suspect before the agent — four independent harness faults made a correctly-reaching golem look incapable (2026-07-14/15)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9ed99f19-0a53-4885-9aa0-36dcf694e583
---

**When a run looks like the agent is failing, suspect the harness first.** The golem is
bound to speak only what tools ground ([[feedback_golem_operator]]), so when the tools
are broken it reports N honestly and the transcript reads exactly like incompetence.
That is the muzzle working, not the agent failing.

**The day this was established (2026-07-14/15).** A jam looped forever on the perfect
cuboid, re-asking for a reagent it could never create. FOUR independent harness faults,
none of them the agent:

1. **The mint was swallowed before it ran.** `args_are_prose` rejects any arg containing
   `(`, `)`, a backtick or `:` — right for `TOOL: ascend again`, fatal for `imscribe` and
   `ob3ect`, the only two verbs whose tail argument IS free text. The better the agent
   specified the object, the likelier the colon, the more certainly its creation was
   discarded. Silently. (Fixed: `FREETEXT_VERBS` bypass.)
2. **The closures were unheard after they returned.** `tool_belnap` decided closure from
   three strings, all polymer vocabulary ("✓ cyclic", "cyclizes into a ring", "closes
   head-to-tail"). `imasm check → T (closes)`, `KERNEL VERDICT: ✓ green` (the p4ramill
   kernel itself!) and `complement → distance 0.00, lossless` all read as N. A run that
   measured a real closure could not reach T — structurally unreachable.
3. **Nine of 43 tools (21%) TypeErrored on call.** MoDoT's dispatch table declared arg
   names that did not match the real `ToolDispatcher` signatures
   (`compute_conflict_distance` really takes `name_holistic, name_compositional`;
   `check_imscription` takes `name_boundary, name_bulk`; three take no args at all).
   Every call raised, the agent honestly marked N.
4. **The generator was a corpse** — my own glyph migration ate a brace out of an f-string
   (`Φ_}}` → `𐑹}`), a SyntaxError that killed `agents/__init__.py`, so EVERY imscribe
   failed. ([[project_vessel_and_heat]]-era migration; see the right-boundary bug below.)

**MY ERROR, do not repeat.** I read the first `tool_calls.jsonl` log and diagnosed "the
agent reran the same missing monomer five times instead of imscribing it — the GENERATIVE
POWER clause not taking." Wrong. It reached for the mint every time; the layer ate it. I
blamed the golem for a gag I had not found, and one of the four faults was mine.

**How to apply.** Before diagnosing an agent's reasoning from a transcript: check that
the calls it emitted actually RAN (the `crystal_fs/tool_calls.jsonl` log exists for
exactly this — verb, args, full output, outcome), and that what returned was actually
HEARD. "Emitted" ≠ "ran"; "ran" ≠ "counted". A verdict of N is as often a broken pipe as
a real void. Corollary for my own passes: a string-replacement needs a RIGHT boundary
guard, not just a left one — `Φ_}` is a prefix of `Φ_}}`, and `Φ_F` of `Φ_F_pseudo`.

See [[feedback_no_adversarial_verification]] (the rope: the walls supply the no's, and a
harness fault is not a wall), [[feedback_paraconsistency_not_monological]].
