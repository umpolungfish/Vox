---
name: project-temporal-engine
description: `TemporalEngine.lean` in p4rakernel — IMASM token topology formalized as Lean 4 inductive type; fountain model; 14 theorems zero sorrys
metadata: 
  node_type: memory
  type: project
  originSessionId: 20ebe404-15b1-45d6-93fd-982fbbfeb5b9
---

`TemporalEngine.lean` is a self-contained Lean 4 formalization of IMASM token topology, written June 2026 by ob3ect agent session.

**Location:** `/home/mrnob0dy666/imsgct/p4rakernel/TemporalEngine.lean`  
**Stats:** 275 lines, 10,944 bytes, requires only `Init` (no Mathlib), clean `lake build` on Lean 4 v4.28.0

**Structure:**
- 12 IMASM tokens as an inductive type
- 4 canonical sequences: `I_Dialetheic_Bootstrap`, `XI_Eternal_Return`, XXIII_Möbius_Fork, `VII_Parakernel`
- 14 theorems, all `native_decide`, zero sorrys

**Crown theorems:**
- `fountain_model`: IMSCRIB is the sole source of both AFWD and AREV; time is a fountain, not a river
- `CLINK_to_IFIX_never_occurs`: structural impossibility — the CL8NK token never directly reaches IFIX in any valid path

**Key structural conclusions:**
- Past is constructed via paradox (ENGAGR→IFIX)
- Past back-propagates into present (IFIX→IMSCRIB)
- IMSCRIB is the monoidal source of both temporal horizons

**Why:** Closes the gap between the informal IMASM manuscript and Lean-verified topology. Adds to [[project-para-lean]] as another 0-sorry file in p4rakernel.

**How to apply:** When discussing IMASM temporal structure or the fountain model, this file is the authoritative machine-verified proof. Reference it when arguing that CLINK→IFIX impossibility is structural, not conjectural.
