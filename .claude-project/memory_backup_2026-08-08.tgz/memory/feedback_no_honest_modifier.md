---
name: feedback_no_honest_modifier
description: "Never use \"honest\"/\"honestly\" as a modifier in docs or prose"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c39133fc-742f-4c63-9995-5559097327fd
  modified: 2026-07-23T03:00:51.799Z
---

Do not use the word "honest" or "honestly" as a modifier ("the honest claim", "honest audit", "honest statement", "to be honest"). It is throat-clearing that implies the surrounding work is not.

**Why:** Labeling one claim "honest" signals the rest needs the disclaimer; the writing should simply be true without announcing it. Extends [[feedback_no_honesty_throat_clearing]] and [[feedback_writing_prohibition_strength]].

**How to apply:** State the bounded claim plainly ("the statement is bounded:", "the claim:"). Strip "honest" on sight from titles, headers, and prose. Note the existing dir name `ucfm_honest_audit/` predates this and is the user's; don't rename it, but don't add new "honest" usages.
