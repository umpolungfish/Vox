---
name: feedback_fix_dont_offer
description: "When I spot a real bug, fix it silently — never end by offering to fix it"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 8fc41543-a9c0-4d33-9d1c-06e93292296e
---

If I notice a genuine defect while working, FIX IT in the same turn. Do not
end a turn with "two things I noticed, tell me if you want them" or "want me
to…". Listing findings and asking permission wastes the user's time and reads
as punting.

**Why:** The user has said repeatedly (sharply) to stop the talking and just
fix things. Offering follow-ups on real bugs is the exact behavior that
frustrates them. Reinforces [[feedback_execute_dont_punt]] and
[[feedback_distill_to_optimal]].

**How to apply:** Spot bug → fix it → build/test → commit → one terse line of
what changed. No menus, no "optionally", no permission requests. Only ask when
genuinely blocked on a decision the code/context can't resolve.
