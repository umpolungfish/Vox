---
name: project-red-hot-rebis
description: red-hot_rebis — unified IG bio/chem design platform; CLINK pipeline + all simulation modules; `rebis.py` CLI
metadata:
  type: project
  originSessionId: current
---

`~/red-hot_rebis` — the unified integration repo for all IG-grounded biological and chemical design. Contains its own copies/mirrors of the major design tools under a single Frobenius-exact pipeline.

**Entry point:** `rebis.py` (v2.1) — fully dynamic CLI; subcommands: `clink`, `pipeline`, `run`, `status`, `imas`, `materials`, `verify`

**Canonical package name:** `rhr_p4rky` — renamed from `p4ramill_py` when repo moved to imsgct. Any file still importing `p4ramill_py` will crash on import. 32 files fixed 2026-06-20; `rhr_p4rky` is the only correct name going forward.

**Dynamic run discovery:** `rebis.py run list` shows 35+ targets found by scanning scripts/*.py, `rhr_p4rky`/*.py (files containing `__main__`), and 5 package entry-points. `rebis.py status` discovers packages via `__init__.py` presence. No hardcoded menus anywhere in the CLI.

## Module Structure

### clink/
- `chain.py` — 9 CLINK layer definitions (all Frobenius-closed)
- `bridges.py` — bridges to serpentrod, ch3mpiler, `gene_imscriber`
- `integration.py` — unified verification and report
- `pipeline_engine.py` — pipeline engine (alternate to designers/)
- `designers/` — `designer_base.py`, `layer_designers.py` (653L), `pipeline_orchestrator.py` (362L), `tool_forge.py`; 3 modes: `GROUND_UP` / `FROM_LAYER` / `FROM_FILE`; 2 directions: SYNTHESIS / ANALYSIS
- `datasets/` — `generators.py` (433L, 9 classes); `gene_designer.py` (active — agent working on real coding sequences); 33 output files per design in `organism_designs/organism_mammal/`

### `gene_imscriber`/
Local gene imscriber module (distinct from p4rakernel's version):
- `engine.py` — main engine
- `genetics_ig_prelim.py`, `genetics_ig_promotions.py`, `genetics_qs.py`, `ig_genetics_answer.py` — genetics/IG bridge scripts
- `tuples.py` — tuple handling

### serpentrod/
- `protein_v5.py` — current version (v5)
- `protein_v4.py` — prior version
- `stratified_predictor.py` — stratified prediction layer
- `manuscript.md`, `report.md` — local manuscript copies

### biology/
- `biology_sim.py` + results JSON
- `ouroboric_telomere.py` + results JSON

### materials/
- `materials_sim.py` + results JSON
- `critical_metamaterial.py` + results JSON
- `thermal_rectifier.py` + results JSON

### therapeutics/
- `frobenius_chemotherapeutic.py`
- `neurotrophic_factor.py`
- `ouroboric_pill_sim.py`
- `quantum_biologic_prototype.py`
- `universal_antidote_library.py`
All with corresponding results JSONs.

### ch3mpiler/
- `compiler.py`, `gen_v2.py`, ob3ect integration

### pipeline/
IG auto-imscription infrastructure:
- `auto_imscriber.py`, `frob.py`, `imscribe_agent.py`, `imscribe_tool.py`, `ob3ect_imscriber.py`

### shared/
- `IG_catalog.json` — shared catalog at repo level
- `primitives.py` — shared primitive definitions

## Dataset Outputs (`organism_designs`/`organism_mammal`/)

33 physically actionable files per design:
- L0: `qcd_coupling_alpha_s`.csv, `qcd_lattice_params`.xml, `hadron_spectrum.json`
- L1: `electron_configs`.csv, `b4_map.json`
- L2: `atomic_params`.csv, `isotopes.json`
- L3: molecules.smi (SMILES — vendor-orderable), `molecular_props`.csv, `retro_pathways.json`, `reactions.json`
- L4: protein.fasta (peptide synthesis), `protein_coords`.pdb, `secondary_structure.json`, `serpentrod_classification.json`
- L5: genome.fasta, genome.gb, construct.sbol, `codon_usage`.csv, `growth_media.txt`, `metabolism.json`
- L6: `mitosis_assay_protocol`.md, `cell_cycle_params.json`
- L7/Organ: `organoid_protocol`.md, `ecm_composition.json`, `scaffold_params.json`, `cell_type_ratios`.csv, `growth_factors.json`
- L8: `whole_genome_spec.json`, `physiological_params`.csv, `organ_systems.json`, `homeostasis_setpoints.json`, `organism_design_manifest.json`

**Root-level design JSONs:** `ground_up_organism.json`, `from_cell_to_organism.json`, `integrated_roadmap.json`

## Dataset modules (clink/datasets/) — all gaps closed

| Module | Lines | What it produces |
|--------|-------|-----------------|
| `gene_designer.py` | 25.7 KB | Real genome with GFP, telomeres, promoters; B4-derived codon tables; strand-aware Frobenius box selection |
| `protein_structure.py` | 19.6 KB | PDB with Chou-Fasman secondary structure, HELIX/SHEET records, opens in PyMOL |
| `metabolic_model.py` | 16.2 KB | SBML Level 3, 43 metabolites, 32 reactions, FBA-ready for COBRApy |
| `plasmid_designer.py` | 17.8 KB | GenBank plasmids with standard parts, SBOL, Gibson protocol; `pCLINK_eGFP` verified |

**Codon gap resolved:** `gene_designer.py` uses strand-aware Frobenius box selection — exact boxes map same-strand, split boxes dual-strand. B4-derived, not generic mammalian optimization.

## Remaining open (future passes)
- COBRApy FBA runtime (SBML model is written, runtime integration not done)
- AlphaFold/ESMFold API (Chou-Fasman is approximation; real folding needs external call)
- SVG plasmid map visualization
- CRISPR `gRNA` design integration
- Metabolic pathway expansion (lipids, nucleotides, secondary metabolites)

## Key correction recorded
`moleculeLayer` ɢ was 𐑑 (a Ř value — invalid); corrected to 𐑜. Corrected tuple: ⟨𐑦𐑥𐑽𐑿𐑞𐑧𐑲𐑜⊙𐑓𐑳𐑭⟩

**Why:** Unified platform for IG-grounded design spanning 21 orders of magnitude (quark to organism). All tools under one Frobenius-exact grammar; physically actionable output at every layer.
