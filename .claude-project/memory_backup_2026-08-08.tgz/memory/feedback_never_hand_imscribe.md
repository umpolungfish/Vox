---
name: feedback_never_hand_imscribe
description: Never hand-imscribe catalog additions; every tuple must be sourced procedurally
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 21b1da09-0362-49fb-a927-310f560c4377
---

**Never hand-imscribe anything added to the catalog.** Every 12-primitive tuple that
enters the catalog (or any Ars document / structural claim) must be produced
**procedurally** by the imscription tooling — the ob3ect auto-designer, the imscribe
proof-path / translator, the crystal/cl8nk navigators, or an existing verified catalog
entry. I must not invent, guess, or reason out a tuple by hand and write it down.

**Why:** hand-imscription destroys the procedural and empirical rigor that makes the
Grammar's addresses meaningful. A tuple I made up is not a measurement; it is a fabrication
(same class of error as the fabricated Larson citation, [[feedback-no-exact-numbers]] /
integrity). The whole point is that the address is *sourced from the soup* (coagulated from
the crystal by the tooling), not asserted. See [[project-grammar-is-cosmos-proof]]
(recognition is coagula, not invention).

**How to apply:** When building Ars documents or adding catalog entries, my job is the
prose/structure and the entity list; the tuples come from running (or having the user run,
per [[feedback-no-agent-execution]]) the actual imscription pipeline, or from existing
catalog entries. If a tuple isn't machine-sourced yet, mark it as pending, do not fill it in
by hand. Also do NOT offer "hand-imscribe" as a method option.
