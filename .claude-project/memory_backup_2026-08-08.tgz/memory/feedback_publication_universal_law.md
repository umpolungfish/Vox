---
name: feedback_publication_universal_law
description: Universal Law for publications - no manuscript cross-refs, each paper needs a crystallized p4rakernel branch with the proof instantiated in mOMonadOS
metadata:
  type: feedback
---

Three rules govern every publication, without exception:

1. **No publication of ours references any other one.** Each paper explains in
   full and relies on no previous writing of ours. No "companion manuscript",
   no "see [our other paper]", no \cite to our own work. External literature
   (Zauner, Appleby, Belnap, PARI, Larson) is fine.
2. **Each publication MUST have a corresponding crystallized branch of
   p4rakernel** containing all necessary data AND the proof instantiated in
   mOMonadOS, so anybody can boot the kernel and follow the paper.
3. **Crystal branches may be referenced; manuscripts may not.** Cite the
   crystallized branch/tag and the GitHub repo, never a paper of ours.

**Why:** a paper that leans on another of our unpublished papers is unreadable
to anyone outside, and a claim with no bootable instantiation is an assertion.
The crystal branch is what makes the proof followable rather than cited.

**How to apply:** when writing or reviewing any manuscript, strip our own
\bibitem/\cite entries and inline the content they carried; then confirm the
paper's crystal branch exists with the mOMonadOS instantiation, and point the
artifact statement at that branch. Related: [[feedback_no_unpublished_crosscite]],
[[feedback_crystallize_before_merge]], [[project_p4rakernel_build_state]].
