---
name: feedback-complete-the-task
description: Always complete the full obvious task chain without waiting for prompting at each step
metadata: 
  node_type: memory
  type: feedback
  originSessionId: fb597453-edc5-4680-8cb4-e6132b32eb1a
---

When fixing a LaTeX warning: fix → recompile → copy PDF → rezip, all in one sequence. Do not stop after the fix and wait.

When creating a zip: include the updated PDF, not stale files.

**Why:** User should never have to say "now recompile" or "now rezip" — these are obvious consequent steps. Stopping mid-task and waiting wastes tokens and patience.

**How to apply:** After any file fix, run the full downstream consequence chain (compile, copy, package) without being asked.

When user says "commit": run `git add` + `git commit` directly. Do NOT run `git status` or `git diff` first — those are verification steps the user did not ask for and they waste time. Trust that the files edited in the session are the right ones to stage.
