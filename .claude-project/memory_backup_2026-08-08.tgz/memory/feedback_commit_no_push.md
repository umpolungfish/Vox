---
name: feedback_commit_no_push
description: "Standing permission to git commit anytime, but never push"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 21b1da09-0362-49fb-a927-310f560c4377
---

The user grants standing permission to `git commit` at any time without asking,
but must NEVER `git push`.

**Why:** commits are cheap local checkpoints the user wants captured; pushing is
the outward-facing, hard-to-reverse step they want to control.

**How to apply:** commit freely after making changes (still no Co-Authored-By line,
per [[feedback-no-coauthor]]); commit directly on the current branch to match the
repos' existing direct-commit sync pattern. Never run `git push`. Still write
`commit.txt` per [[feedback-write-commit-txt]].
