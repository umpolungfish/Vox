---
name: Package management — use uv
description: Always use uv for Python package installation, not pip/pip3/python3.x directly
type: feedback
originSessionId: cf9cd0aa-e4b6-41e2-af16-a03772bffc03
---
Always use `uv pip install <package>` for installing Python packages. Never use bare `pip install` or `pip3 install`.

**Why:** The user explicitly corrected this. The environment uses uv for Python package management.

**How to apply:**
- To add a package and persist it: add to `pyproject.toml` dependencies, then run `uv pip install -e .` from the project root.
- When `uv pip install` resolves the wrong venv (e.g. picks up a parent workspace venv), use `uv pip install --python /path/to/project/.venv/bin/python <package>` to target the correct interpreter explicitly.
- `uv pip install <package>` alone may silently install into the wrong venv if there is a workspace-level `pyproject.toml` higher in the tree.
