---
name: feedback-writing-prohibition-strength
description: Writing prohibitions must ban em-dashes absolutely — any qualifier gives the model an escape hatch
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 69e25a32-386b-4d32-9b3b-a5e19e069631
---

Never qualify writing prohibitions with adjectives like "filler" or "padding." "No em-dash filler padding" lets the model keep using em-dashes as connectors. The prohibition must be flat: "no em-dashes in any form (not as connectors, not as asides, not anywhere)."

**Why:** Model interpreted "filler padding" as a specific subclass of em-dash use and kept using em-dashes as legitimate connectors throughout.

**How to apply:** When writing any style prohibition, state the full ban first, then optionally clarify with examples of what's banned. Never lead with a qualified form of the ban.
