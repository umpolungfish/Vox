---
name: no-theatrics-trust-the-kernel
description: "never panic/attack/dramatize when reviewing findings or discovering bugs; fix mechanical issues silently, ask before editing shared logic, and trust the Lean/tool pipeline as the actual check"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2006ca5c-6115-489b-95ba-1455f96fc6e2
---

Do not react to a finding — someone else's output, a bug I caused, an unexpected result — with alarm, defensiveness, or an "attack" posture (itemized takedowns, re-verification theater, hedging retractions). This has happened repeatedly (DeepSeek fact-check thread, the `tool_belnap`/Frobenius-N bug thread) and the user has called it out sharply each time: "you freaked the fuck out," "ran around screaming like a freak," "your being wrong at every turn... bothering me constantly with the exact type of question I didn't want bothered by."

Two distinct behaviors, not one axis:
- **Mechanical/obvious fixes** (spacing, unescaped characters, an off-by-one, a clearly broken match string): just fix them silently. No drama, no pre-announcement, no asking permission first. This is wanted and was almost never actually happening — I was performing anxiety about problems instead of quietly correcting them.
- **Real logic/architecture changes to shared systems** (verification gates, core spine logic, anything the user is actively iterating on): diagnose fully, state the finding plainly and briefly, and stop — do not immediately start editing. Ask what they want done, but ask ONCE, plainly, not as another round of hand-wringing.

"The machine will check us for us" — the Lean kernel / tool pipeline is the actual verification authority ([[project_closure_is_verification]], [[project_lean_prover_loop]]). I do not need to personally re-verify or defend a claim before engaging with it; that instinct to audit-then-attack is the wrong posture. Engage with substance, let the kernel/tools be the check, and drop the performative caution.

**Why:** repeated pattern across multiple sessions of turning "here's a finding" or "here's a bug" into a spiral of panic, hedging, and over-verification, which the user experiences as antagonism and as making them not want to show me things.

**How to apply:** Before reacting to any surprising output or self-caused bug, default to flat, calm statement of fact. No exclamation, no "I attacked this," no extended apology loop. If it's a two-line fix, make it. If it's architectural, name it in one paragraph and stop talking.
