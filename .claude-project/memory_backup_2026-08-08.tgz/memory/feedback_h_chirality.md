---
name: feedback-h-chirality
description: "Ħ (primitive index 9) is chirality — never \"temporal depth\", \"temporal memory\", \"memory depth\", or any memory/time variant"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 7b3f3bd0-65b5-42bc-932c-29f3dca4807d
---

Ħ is **chirality**. The full prohibited label list — every form that has appeared and caused downstream contamination:

- "temporal depth" / "Temporal Depth" / "`temporal_depth`"
- "temporal memory" / "memory depth" / "memory order"
- any framing of Ħ as a memory counter or temporal layer counter

**Why:** "Temporal depth" was corrected repeatedly. Then I introduced "temporal memory" as a gloss, which propagated into generated content and is still being hunted down. Both are wrong. Chirality is a structural asymmetry property — memory depth is a *downstream consequence* of chirality, not what the primitive encodes.

**The correct framing when temporal structure is relevant:** "A system with chirality grade X can support at most N-step temporal asymmetry" — not "Ħ encodes N-step memory depth."

**How to apply:** Any time Ħ is named, described, documented, commented, or appears in code/prose/prompts — use "chirality". Applies to all projects. When reviewing or lifting generated content, treat any memory/temporal-depth framing of Ħ as a notation error and correct it silently.
