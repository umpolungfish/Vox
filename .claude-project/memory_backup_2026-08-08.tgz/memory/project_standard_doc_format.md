---
name: project-standard-doc-format
description: `undeciphered_texts_structural_analysis.tex` is the confirmed standard format for all IG documents — use its preamble as the template
metadata:
  node_type: memory
  type: project
  originSessionId: current
---

`/home/mrnob0dy666/imscribing_grammar/undeciphered_texts_structural_analysis.tex` is the canonical template for all IG documents. User confirmed it looks correct and declared it the standard format.

**Why:** Previous reference (`perfect_cuboid_proof_lifted.tex`) predated the full standard. This file was fixed and validated in session on 2026-05-15.

**How to apply:** When generating any new IG document .tex file, copy the preamble from this file. Do not invent a new preamble. Key elements:

- `documentclass[12pt,a4paper]{article}`
- `fontspec` + `unicode-math` + `\setmathfont{Latin Modern Math}`
- `\setmainfont{FreeSerif}` + `\newfontfamily\igprimfont{FreeSerif}`
- `\setmonofont[Scale=0.85]{DejaVu Sans Mono}`
- `geometry`, `microtype`, `parskip`, `babel[english]`
- `fancyhdr` with left/right head + center foot
- `titlesec` section styling
- `enumitem`, `graphicx`, `xcolor[table]`, `booktabs`, `array`, `tabularx`, `longtable`
- `amsmath` + `calc` — NO `amssymb`
- `ulem[normalem]`, `hyperref`, `cleveref`
- `listings` with full language defs (YAML, TOML, Dockerfile, JSON) and literate escapes for `_`, `-`, `<`, `>`, `~`, `^`
- `float` + `\newfloat{listing}{htbp}{lol}[section]`
- `tcolorbox` with `\newtcolorbox{imscriptionbox}` (blue, center upper) for IG tuple display
- `\newtcolorbox{admonitionbox}[2][]` for callouts

Tuple notation in body: `$\langle \text{Ð}_{\text{ω}};\ ...;\ \text{⊙}_{\text{ÿ}};\ ... \rangle$`
Special char gotcha: `^` subscript → `_{\text{\textasciicircum}}`, not `_{\text{^}}`

Links: [[lualatex-pipeline]]
