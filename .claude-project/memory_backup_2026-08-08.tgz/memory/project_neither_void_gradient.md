---
name: project_neither_void_gradient
description: "N (Neither) is the necessary unmarked complement co-created by distinction; join-identity/bottom of the info gradient (B=top), regenerated at the EVAL gates so the gradient is sustained not consumed; N & B are the two negation-fixed poles"
metadata: 
  node_type: memory
  type: project
  originSessionId: f985bde5-cd58-453f-96c7-e4444cba7454
---

N (Belnap Neither) is NOT only produced at VINIT. Kernel sources: VINIT (default void seed unless injected), EVALT/EVALF REJECTION (a value that fails the gate is pushed as N and returned), meet/CLINK (N is absorbing: meet(N,x)=N), and arity underflow (vacuum). So N is both origin and a continuous running product.

The deeper reading (user's, correct): N is the necessary "not-stuff", the UNMARKED state co-created by any distinction (Spencer-Brown, Laws of Form). VINIT = "ground of distinction"; the first mark co-creates the unmarked. Belnap needs FOUR values not three because N is a POSITIVE value (marked absence), not mere lack of a value. You cannot loop out the "stuff" without positing the "not-stuff" as the ground it is distinguished from.

The gradient is literal in the information order: join (FFUSE / mu) is monotone; join(N,x)=x so N is the IDENTITY / bottom / zero; join(B,x)=B so B is ABSORBING / top. Dynamics climb N -> B. That climb IS the arrow of [[project_heat_death_dialetheic]] (void -> dialetheic saturation): N is the source of the slope, B is the drain.

Dissipative maintenance: because the gates keep REGENERATING N (every gate rejection excretes void), the gradient is sustained, not spent. The system continuously produces the low-potential void-complement so there is always somewhere to flow, exactly what a dissipative structure does.

Two poles: N and B are the two fixed points of negation (¬N=N, ¬B=B) — the empty doorway and the open (Janus) doorway; T and F are the one-sided values between. All dynamics = the climb from the empty invariant pole to the full invariant pole. See the `janus_gate` ob3ect (MoDoT/ob3ects/`janus_gate`): `phase_3` renders N="the empty doorway", B="the Janus gate thrown open".

**Why:** gives the origin AND telos of the kernel dynamics (why there is flow at all) and why N must be first-class, not the absence of a value.
**How to apply:** treat N as the marked void / gradient-floor that is continuously regenerated at the EVAL gates, not merely an initial condition; the N->B climb is the heat-death arrow. See [[feedback_paraconsistency_not_monological]], [[project_charge_conservation_frobenius]], [[project_imscribing_rwx_correspondence]].
