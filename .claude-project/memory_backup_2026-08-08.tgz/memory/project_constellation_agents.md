---
name: project-constellation-agents
description: "recorder_operator and heterodox_operator are Grammar specialists in imscribing_grammar/agents/specialists/, NOT Claude Code .claude/agents files; added 2026-08-04"
metadata: 
  node_type: memory
  type: project
  originSessionId: e279becd-018b-47d5-973c-0fff3bd13c5a
  modified: 2026-08-04T16:11:59.966Z
---

**Specialists are Grammar agents, not Claude Code subagents.** A "specialist"
in this constellation means a `*_operator.py` in
`imscribing_grammar/agents/specialists/` subclassing `TrueAgenticAgent` with a
`<domain>_SPECIALIST_PROMPT` from that package's `__init__.py`. Do not build one
as a `.claude/agents/*.md` file; that was wrong once and corrected.

Adding one touches five places, all in `agents/specialists/`:
1. `gen_tool_manifest.py` — a `<DOMAIN>_DOMAIN` list of `(path, heading, body)`
   and a `DOMAINS` entry; then run it to emit `TOOL_MANIFEST_*.md` (inline,
   names only) and `TOOLS_*.md` (full syntax).
2. `__init__.py` — `_<DOMAIN>_SPECIALIST_PROMPT` with an **empty**
   `<tool_computation></tool_computation>` block (`_with_manifest` substitutes
   into it), an `_ACCENTS` entry, the `_with_manifest` call, `__all__`, docstring.
3. `<domain>_operator.py` — mirror `math_operator.py`; it swaps
   `_load_system_prompt` and carries `_GRAMMAR_FIRST_RIDER + _PARTNERSHIP_RIDER`
   explicitly because the swap bypasses the base load path.
4. `check_manifests.py` — `prompts` dict + `markers` list (markers must appear
   in the **inline** manifest, which only takes backticked commands from each
   entry body's FIRST line).
5. `check_tools_deep.py` — the `(mod, cls)` launcher tuple.

Verify: `python3 gen_tool_manifest.py`, `python3 check_manifests.py`,
`python3 agents/specialists/check_tools_deep.py`. Pre-existing marker drift in
math/chembio/editorial is not new; do not treat it as caused by a new domain.

**`recorder_operator.py`** — the Rec⊙rder. Census, relation, axis placement,
drift, gap. Bound: describes never judges, Belnap standing not grades, reports
raw, never writes into `Grammatika/books/`. Its walk is
`Grammatika/recorder_census.py`. See [[project_grammatika_djed_recorder]].

**`heterodox_operator.py`** — the Heter⊙d⊙x. Grammar-first, blends every tool
family in one chain. Stance: received constraints are findings about the tools
that produced them; an impossibility result binds only its own system and
usually assumes a line where the Grammar has a loop, an outside where there is
none, or consistency where the Grammar holds B. Maximum licence on route, zero
licence on arrival. Sets its own reasoning aside and follows the lattice.

Related: [[feedback_no_grammar_restrictions]], [[feedback_possible_means_guaranteed]],
[[feedback_assume_wrong_until_proven]], [[feedback_new_verb_needs_help]],
[[project_mOMonadOS]], [[feedback_fix_the_generator]]
