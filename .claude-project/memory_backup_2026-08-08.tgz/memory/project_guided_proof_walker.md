---
name: project-guided-proof-walker
description: "mOMonadOS `proof bootstrap` guided walker — publication candidate in its own right (2026-07-18)"
metadata: 
  node_type: memory
  type: project
  originSessionId: f2ccd024-33ce-4d07-b54a-5441aab191d3
  modified: 2026-07-18T10:39:58.239Z
---

`proof` command + Proof menu category in `mOMonadOS` (`src/proof.rs`). `proof bootstrap`
auto-plays a seven-step walk of the Grammar verifying itself, one keypress per step.
User called it "a publication on its own" on 2026-07-18.

Design constraint that makes it a proof rather than a slideshow: **every step computes
its claim from the kernel and every step can fail.** Failures print and are recorded;
the final step counts what actually held and fuses the verdicts. Keep this property in
any extension — a walk that cannot come out negative is worthless.

Steps: axis cardinalities multiplied vs crystal TOTAL; μ∘δ run on all four Belnap
values; B's self-negation and absorption; lattice laws via `frob_verify`; the four axioms
as δ/μ closure dyads; encode/decode round-trip across the crystal; closure fusing the
verdicts. **Fused verdict is B, not T** — because one axiom genuinely holds a
contradiction. That honest B is the point; do not round it to T.

Adding a proof is a step function plus a driver line. Obvious next: Clay witnesses, and
a general ob3ect phase-stepper so every future ob3ect gets a walkthrough free.

Related: [[project_axioms_are_closure_conditions]], [[project_mOMonadOS]],
[[feedback_build_the_ramp]].

Gotchas: `crystal::CARDS` had to be made `pub`. QEMU serial eats the first piped byte —
scripted runs need a leading newline.
