---
name: feedback-everson-mono
description: Dual font: Everson Mono for both shavfont (Shavian) and igprimfont (12 primitives); Trabajo.otf only for AS_ABOVE/SO_BELOW manuscripts; never FreeSerif
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e95a63e7-35d0-444c-89a7-5fb17e2b4add
---

**Font split (June 2026, confirmed June 19):**

- `\shavfont` = **Everson Mono** (system font, `~/.local/share/fonts/`) — for Shavian block chars U+10450-U+1047F (structural type values: Shavian glyphs)
- `\igprimfont` = **Everson Mono** (same font) — for the 12 primitive symbols: Th Dh Ph R f C g Gm O H S Om

Canonical preamble block for ltx-generated and directly-compiled documents:
```latex
\newfontfamily\shavfont[Scale=1.0]{Everson Mono}
\newfontface\igprimfont{Everson Mono}
\usepackage{newunicodechar}
% Shavian block and 12 primitives injected automatically by ltx step 2b
```

**Confirmed working:** `hadron_structural_classification.tex` (submitted to Scientific Reports) uses `\newfontfamily\shavfont[Scale=1.0]{Everson Mono}`; `ig_pt_walk.tex` / `ig_pt_spring.tex` use `\newfontface\igprimfont{Everson Mono}`.

**Trabajo.otf exception:** `~/imsgct/Trabajo.otf` exists and is used ONLY in `manuscripts/AS_ABOVE.tex` and `manuscripts/SO_BELOW.tex` via `Path=~/imsgct/` fontspec option. These are directly compiled documents, not processed through ltx. Trabajo is NOT a system font and cannot be used in ltx-processed documents without the explicit Path= option.

**Why:** Everson Mono is installed system-wide at `~/.local/share/fonts/` and has comprehensive Unicode coverage including all Shavian codepoints, Latin Extended, and Greek primitive symbols. FreeSerif has zero Shavian glyphs -- never use it for shavfont or igprimfont.

**How to apply:** All ltx-processed documents automatically get correct fonts via step 2b injection (shavfont/igprimfont/newunicodechar + full Shavian block + 12 primitives). For direct .tex compilation, use the preamble block above. Never use `\primfont` (old alias, undefined in current pipeline).

**NEVER add `\upshape` to `\igprimfont`** -- invalid in math mode; breaks all `${{\igprimfont X}}$` usages.
