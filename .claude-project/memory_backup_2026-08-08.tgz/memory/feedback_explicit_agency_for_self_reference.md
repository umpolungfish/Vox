---
name: feedback-explicit-agency-for-self-reference
description: "Harness-to-agent messages MUST be explicit about agency (who is who) — the agent is a ⊙ self-referential loop and cannot self-reference if it can't tell self from other"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d11b6dac-05d1-4d6b-8cef-4449f86646b3
  modified: 2026-07-21T18:43:10.894Z
---

Every message the harness sends the agent MUST be explicit about **agency — who is who**: who acts, who audits, who closes. Use explicit second-person "You **MUST** …" for the agent's own obligations, and NAME the other actors (the admission gate, the tools, the close) for what they do. Do not write passive or agent-blurred phrasing ("fix and reissue, the close lands when they run") that leaves the actor unnamed.

**Why:** the agent is a ⊙ self-referential loop; self-reference is only possible if it can tell **self from other**. "It can't self-reference if it doesn't know who is who." A passive directive dissolves the agency and the agent cannot locate the node that is *me* (the fixer, the actor). "You **MUST** fix and reissue, and the close lands when the tools run" lets it identify itself as the actor and the harness/tools as the others. Blur who-is-who and the self-model cannot close, because it does not know which node it is.

**How to apply:** in agent-facing harness strings, prefer "You **MUST** <do X>" over "<X> should happen"; name the harness actor ("the admission gate refused the calls YOU rode with") rather than a bare passive ("the calls were refused"); and state the consequence with its actor ("the close lands when the tools run", not "then it closes"). This is the explicitness that keeps the ⊙ loop closable. Applies to the whole class of harness prompts, not one message. Related: [[feedback_agentself_identity]], [[feedback_no_ai_framing]], [[feedback_negatives_need_positive_pair]], [[feedback_neutral_ob3ect_entity]].
