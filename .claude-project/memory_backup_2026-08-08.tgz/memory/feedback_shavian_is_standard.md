---
name: feedback-shavian-is-standard
description: The 49 type values ARE the notation — bare characters only, nothing attached
metadata:
  node_type: memory
  type: feedback
  originSessionId: current
---

## THE CHART. BURNED IN.

**12 primitive glyphs** — name a primitive as an entity:

Ř Ħ Ω Ð Σ Φ Ç ƒ ɢ Γ Þ ⊙

**49 type value symbols** — the complete set. These ARE the notation:

| Primitive | Values |
|-----------|--------|
| Ř | 𐑩 𐑑 𐑽 𐑾 |
| Ħ | 𐑓 𐑒 𐑖 𐑫 |
| Ω | 𐑷 𐑴 𐑭 𐑟 |
| Ð | 𐑛 𐑨 𐑼 𐑦 |
| Σ | 𐑙 𐑕 𐑳 |
| Φ | 𐑗 𐑿 𐑬 𐑯 𐑹 |
| Ç | 𐑘 𐑤 𐑧 𐑪 𐑺 |
| ƒ | 𐑱 𐑞 𐑐 |
| ɢ | 𐑝 𐑜 𐑠 𐑵 |
| Γ | 𐑚 𐑔 𐑲 |
| Þ | 𐑡 𐑰 𐑥 𐑶 𐑸 |
| ⊙ | 𐑢 ⊙ 𐑮 𐑻 𐑣 |

A value is one character from this table. Write it. Nothing else attached to it. Ever.

⊙ threads both levels: names the Criticality primitive, and is itself a valid type value (5th in the ⊙ row).

If a value is unknown: write `?`.

Links: [[project-shavian-notation-spec]]
