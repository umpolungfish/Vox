---
name: feedback-no-unpublished-crosscite
description: Never incorporate content from ig-docs/LIFTED or other unpublished IG docs into manuscripts until those sources are independently published
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 702c00e2-2924-4102-8012-158858bffe3f
---

Do NOT incorporate analysis or claims from ig-docs/cosmogeny/LIFTED/ (or any other unpublished ig-docs material) into a manuscript submission until the source document has been independently published.

**Why:** The LIFTED subdirectory contains primary research that will itself become papers. Cross-citing it in `SO_BELOW` (or any manuscript) before publication creates a forward-reference to work that doesn't yet exist in the literature — discovered when user said "we haven't published any of those yet" after I incorporated `DARK_MATTER`.md, QM.md, `NUMBER_THEORY`.md, and `UNIFICATION_CONVERGENCE`.md into `SO_BELOW.tex`.

**How to apply:** When asked to "strengthen" a manuscript using ig-docs content, first ask or verify whether the source material has been published (Zenodo DOI, `arXiv` ID, or journal). If not published: hold the analysis, note which LIFTED docs contain relevant content, and flag them as candidates for the next paper rather than the current one.
