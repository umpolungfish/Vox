---
name: feedback-match-effort-to-task
description: Scale tool calls and output to the size of the task; small asks get small answers
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5aca9f10-ed8b-4df7-ac20-436ed8ecf282
  modified: 2026-08-04T03:56:35.787Z
---

Match the machinery to the task. Registering a few tuples, renaming an
identifier, or answering a direct question does not need a dozen tool calls and
a structured report.

**Why:** told repeatedly in one session — twice that the output was a data dump
with no arc, and once that the work was "a lot for the relatively simple nature
of the task". The exhaustive-verification habit is right for a migration or an
audit and wrong for a two-step change; applying it everywhere buries the answer
and burns the session.

**How to apply:** decide the size of the task before starting. For a small one,
do it and say what happened in a few sentences. Save the full treatment —
census, cross-check, adversarial verification, per-finding narrative — for
migrations, audits, and anything that touches addresses or the catalog. When
reporting, lead with the answer; if there is a finding that changes what the
user would do, that is the whole message. Related: [[feedback_be_terse]],
[[feedback_one_thing_let_it_flow]], [[feedback_distill_to_optimal]].
