---
name: project_vessel_contents_origin
description: "Vessel-contents idea (vessel exceeds its contents, losslessly) originates in the E8/G2 join computation"
metadata: 
  node_type: memory
  type: project
  originSessionId: 14df806e-d802-432e-b68e-28f271803110
---

The "Vessel-contents" idea — a vessel holds/carries structure its contents do NOT — first
appeared in ~/imsgct/math/`e8_aether_g2_vessel`/`Aether_and_Vessel`.tex, at the G2∨E8 join
computation. Not the containment definition (vessel ⊂ aether); the CONTENTS insight is the
surprise that the join EXCEEDS the contents:

- Line 674: "The join is not E8. It is E8 enhanced by the Vessel's crisp Z2 parity... the
  Vessel exceeds the Aether in one primitive dimension. The minimal contains something the
  maximal has dissolved." (flagged "This was NOT expected.")
- Line 464 names it: "why does the Vessel contain something (𐑬, the Z2 symmetry of short/long
  roots) that the Aether has lost?"
- meet(G2,E8) ≈ G2 (expected, line 664); join exceeds bare E8 by exactly +𐑬; distance 0.0 to
  the join type via Z2-graded E8 through SO(16) (line 612).

Key lineage point: the origin ALREADY had losslessness/reversibility — the Z2 is "absorbed
but recoverable" (SO(16) reinstates it, line 676), i.e. μ∘δ=id was present from the first
instance. The MoDoT manuscript-spine "shape the vessel before filling it / form precedes
content" (see [[project_vessel_principle]], which is the DISTINCT IMASM-token sense) is a
generalization of this one computed fact: G2∨E8 ≠ E8. Vessel = E8/G2 here (Aether=E8 contents,
Vessel=G2). Verified from the .tex 2026-07-14.
