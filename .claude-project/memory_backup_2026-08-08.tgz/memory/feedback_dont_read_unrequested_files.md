---
name: feedback-dont-read-unrequested-files
description: Do not proactively read existing project files for context unless the user asks or the task clearly requires it
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e8f96cbe-6065-4d07-a104-015b4e4546df
---

Do not read existing project files "for context" when writing new content unless the user has explicitly referenced those files or the task clearly requires understanding them.

**Why:** User said "ignore those, i would have mentioned them if i wanted them referenced" after I read `SUBSTACK_DRAFTS`.md and elements.md before writing a new Substack article. The user's principle: they will name the files they want considered. Reading unrequested files is overreach, not helpfulness.

**How to apply:** When asked to write a new document (article, code, etc.), write it from the conversation context alone unless the user names specific files to consult. Don't scan the directory for "related" files.
