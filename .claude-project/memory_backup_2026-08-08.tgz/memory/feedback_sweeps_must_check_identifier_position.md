---
name: feedback-sweeps-must-check-identifier-position
description: "A rename sweep must ask whether the target position can hold the new spelling, and must never delete"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5aca9f10-ed8b-4df7-ac20-436ed8ecf282
  modified: 2026-08-03T19:15:48.288Z
---

Before a notation or alphabet sweep rewrites a token, ask what position the
token sits in. Shavian (U+10450+) is a Letter category and IS a legal Python
identifier. `⊙`, `∞`, subscripts `₀₁₂`, and the other axis marks are symbols and
are NOT. A sweep that does not check turns working code into a SyntaxError.

**Why:** four distinct breakages in this tree, all from the same omission.
`⊙ = 1` as an enum member made all of synfin unimportable for weeks. A fold of
`Φ_}` left an orphan brace inside an f-string. `OuroboricityTier.O_∞` and `.O₀`
were written into attribute position. And worst, commit `d971846` in p4rakernel,
"Retire the gen-2 glyph-pair notation for bare Shavian", deleted 375 files and
192k lines including the whole `p4ramill_py` Belnap foundation, adding nothing;
priests-engine could not load from then until 2026-08-03.

**How to apply:** when a value's canonical glyph cannot be an identifier, use the
Core.lean constructor name for the member and keep the glyph as the value, which
is what the Grammar's own models.py does. Where notation is needed for display,
put it on a `display` property rather than in the name. And a rename sweep must
never delete: a commit whose message says "retire a notation" and whose diff is
all deletions and no additions is a bug, so check `--diff-filter=D` before
committing one.

**Finish at the ARTIFACT, not the source.** A source census proves nothing about
what runs. The mOMonadOS REPL printed `G1 (Φ≥𐑹)` for hours after the source said
`G1 (<≥𐑹)`, because the booting binary was built during the second axis and
never rebuilt; `strings -e S <binary>` on the built artifact is the check that
would have caught it. Rebuild and re-run after any notation change, then read the
real output. Related: [[feedback_complete_the_task]],
[[feedback_harness_before_agent]] (emitted ≠ ran ≠ heard),
[[feedback_use_command_grep_for_census]], [[project_symbol_migration_state]],
[[feedback_cross_compare_before_cleanup]].

**Watch for parallel SHORT schemes.** Some tables carry a second alphabet for
compact display, e.g. mOMonadOS `primitive_short`/`primitive_family` used
D T R P F K G C Φ H S Ω, where Φ and Ω mean Criticality and Protection because P
and C are taken. A sweep reading those as glyph-alphabet letters corrupts them.
They should move onto the marks entirely rather than be restored; the collision
that forced the parallel scheme does not exist on the canonical alphabet.
