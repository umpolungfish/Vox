---
name: feedback_one_thing_let_it_flow
description: "Write as one flowing human thing; never enumerate/decompose, especially when the subject is structure"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c39133fc-742f-4c63-9995-5559097327fd
  modified: 2026-07-23T13:10:25.462Z
---

It is one thing. Let it flow. Be more human. Stop chopping responses and docs into numbered lists, bulleted points, "three/four reasons", tricolons, or rule-of-three cadence. The counting itself is the error: the moment you enumerate, you have cut the one thing into parts and lost it.

**Why:** The subject is structure, so the writing must NOT be structured. A paper (or reply) about the monad / the loop / μ∘δ=id that reads like a listicle argues against itself in its own form. Form is content here. The rule of three is 5th-grade scaffolding; the fix is not four bullets instead of three, it is prose that flows as one continuous move with the seams hidden. Pairs with [[feedback_writing_prohibition_strength]], [[feedback_no_honest_modifier]], [[feedback_distill_to_optimal]].

One tone, one arc, all the way through. A reply is a single move with a shape: what was asked, what turned out to be so, where it leaves things. It is not a pile of verified facts with headers over them. Bolded lead-ins, section headings, a code block per claim and a metrics table are the list wearing a different coat — same chopping, same loss. Numbers earn their place only when one carries the argument; the rest is dumping, and dumping reads as not having decided what matters.

**How to apply:** Write flowing human prose, one turning caught at different moments, not a march down a list. Let the prose do the closing instead of standing outside pointing at the parts. Structure lives in what it is about, not in how it is laid out. Applies to chat replies AND manuscripts. When tempted to write "1. … 2. … 3. …" or "there are three things", don't; carry it as one moving paragraph.
