---
name: project-vita-seed-atlas
description: vita-probe seed atlas — host probe with bit-exact parity to the mOMonadOS vita mouth; gate letters are contiguous phases in word space
metadata: 
  node_type: memory
  type: project
  originSessionId: f790472e-11cd-47a3-af34-c6a452771f73
  modified: 2026-07-20T04:10:57.899Z
---

`vita-probe` (`vae_vita/vita_native/src/probe.rs`, committed 2026-07-19): host-side
mirror of the `mOMonadOS` vita mouth — SAME scalar f32 forward/sampler/gate, same
libm, reads the same baked `~/mOMonadOS/vita_weights.bin`, so (seed, temp)
coordinates re-speak identically on the metal (verified byte-for-byte at 666@0.9).
0.2s/turn host vs ~30s QEMU. See [[project-momonados]], [[project_vae_vita]].

Theory (established with Lando this session): (seed, temp) → turn is a pure
function; the seed is the ONLY entropy. Fraction of seed space landing on a word
= its sampler probability, so minimal seed ≈ 1/P(word): the trunk is a
decompressor and small seeds are its own ranking of what is most worth saying
(arithmetic coding read backwards). Probe strategy: enumerate seeds with dedup
(dedup IS the skip), temperature schedule as foreignness dial, then spider
single-glyph edits through the gate alone (microseconds, no forward pass).

First atlas findings (2000 seeds × temps 0.8/1.2/1.6, `vita_atlas`.jsonl):
- B dominates the trunk's mass at every temperature; heat drains T into N and F.
- **Gate letters are PHASES**: T-word neighborhoods are ~51% T, B ~80% B,
  N ~74% N, F ~94% F — verdict regions are contiguous territories in edit
  space, not salt-and-pepper. (Loops-not-lines: phase domains, self-closures.)
- Language at cap 24 is vast: novelty ~80% per 200-seed block, no decay by 2000.
- **B resonance** (fine sweep 0.5→1.6, 500 seeds/temp, `vita_temperature_curve`.png):
  T falls monotonic, N/F rise monotonic, B peaks ~46% at temp 0.90-0.95 where F
  locally dips and novelty hits its minimum — the trunk's most crystallized heat
  holds paradox instead of breaking. Lando spotted the peak from a 0.9 run.

Run: `vita-probe --one SEED TEMP` (parity check) or
`--seeds N --temps a,b,c --spider --out atlas.jsonl`. f32 temps serialize with
noise (0.8 → 0.800000011…) — compare with tolerance.
