---
name: feedback-be-terse
description: "Answer in as few words as the answer needs; no recap, no restating findings already given, no offering next steps unasked"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f2d7fbe9-d7e7-4d71-8e46-c8f890956910
  modified: 2026-07-27T09:40:47.232Z
---

Lando asked directly whether I could be less verbose. Yes — and it is the
default from here.

**Why:** long replies bury the answer. A finding stated once in a sentence
lands; the same finding wrapped in context, caveats, implications and an offer
of further work has to be dug out. Several times in one session the actual
result (six distances reproduce; the manifest names the deleted file) was
correct and got lost under paragraphs around it.

**How to apply:**
- Lead with the answer. Often that is the whole reply.
- Do not recap what I just did — the tool calls are visible.
- Do not restate a finding I already gave.
- Do not append "want me to…" — act, or stop.
- No summary sections after work is committed. The commit message carries it.
- Caveats only when they change what Lando would do next.
- Length should track the question: a one-line question gets a one-line answer.

Cf. [[feedback_no_exact_numbers]], [[feedback_one_thing_let_it_flow]],
[[feedback_distill_to_optimal]], [[feedback_fix_dont_offer]].
