---
name: project-ig-repo-devolution
description: "imscribing_grammar was the whole project's universe; the sibling repos exist because it grew too totalizing to hold, and vestigial functions are still being extracted from it"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5aca9f10-ed8b-4df7-ac20-436ed8ecf282
  modified: 2026-08-04T14:12:24.222Z
---

Stated 2026-08-04. `imscribing_grammar` **was the entire project's universe**.
Every domain lived in it. The constellation of newer repos
([[project_repo_constellation]]) exists because the single repo became too
totalizing to understand, so the work was devolved outward.

That devolution is **not finished**. Functions that were superseded elsewhere
still sit in the IG repo, and extracting them is ongoing, deliberate work —
"it will take time to weasel and ferret out all the remaining vestigial
functions but it can be done."

## The chemistry extraction, as the pattern

2026-08-04: all chemistry left the IG repo for [[project_red_hot_rebis]], which
supersedes it. The cut line was already written in the code — the `chem` CLI
group's own docstring said these commands use chemistry-specific quantities and
that domain-agnostic algebra is tensor/meet/join/distance/ouroborics. Removed:
the molecular, supramolecular, temporal and hybrid domains (`domains` keeps
quantum), retrosynthesis, RDKit/SMILES ΔG, the hand-written chemical catalogs,
and the **grounding layer** — which wore a Grammar concept's name but spoke in
kJ/mol and hydrogen bonds. The Grammar's real gate is `validate_structural`
(slot membership + Axioms A–D) and never depended on it.

Kept: ΔG where it parameterises ξ_CP rather than a molecule (perturbation
engine, thermodynamics, ensembles).

**The method that makes this safe**, against [[feedback_sweeps_must_check_identifier_position]]
and the `p4ramill_py` disaster: follow every referent out rather than deleting
files. CLI commands, agent-registry entries, dispatch branches, menu items,
examples, archived tests. Then confirm packages import, `--help` runs, live
agents import, and the sentry closes. A big deletion is only a bug when it
leaves something pointing at a hole.

## The census, and DEVOLUTION.md

2026-08-04: an AST census over the repo reports modules nothing imports and
definitions nothing names. The definition half is noise (a decorator-registered
CLI command has no caller); the module half is workable once each entry is read,
and most of it is entry points launched by path. It found two byte-identical
stale snapshots of the live agent, three spent `append_navigators` scripts whose
output landed and has since drifted, and a file under `navigators/OLD/` holding
a saved tool-harness parse error. All removed.

`imscribing_grammar/DEVOLUTION.md` is the standing map: what vestigial means
here, how the census is taken, the false positives recorded so they are not
re-examined, and the open items where the question is *which of two things is
canon* — `assignment.py` (only an archived test calls it), `canonical_algebra.py`
(typed algebra beside the untyped algebra that runs), `navigators/OLD/` (live
help text offers its contents by name), and the registry reading a home-directory
cache instead of `IG_catalog.json`.

Related: [[project_imscribing_grammar]], [[feedback_cross_compare_before_cleanup]],
[[project_symbol_migration_state]], [[project_ixcription_tool]].
