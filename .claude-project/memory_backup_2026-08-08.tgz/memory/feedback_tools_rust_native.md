---
name: feedback_tools_rust_native
description: "MoDoT tools must be rust-native (ask_native), not Python bridges"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 1d793126-545f-494d-8b9b-927c0b30ae06
---

All MoDoT tools must be built rust-native in `ask_native/` (the `./ask` binary), NOT as Python modules or Python-shelling bridges.

**Why:** MoDoT has an older Python agent (`modot/*.py`) and the native Rust loop (`ask_native`). The native loop is the target; new tool capability belongs in Rust so `./ask` wields it directly (no python round-trip). `ig_tools.py` shelling to `IG_inquiry` is the one legacy Python bridge still in the path.

**How to apply:** Add tools as pure-Rust modules under `ask_native/src/`, dispatch inline from `run_structural_tool` (like `cl8nk`/`plasma`/`imasm` — no shell), and register in `STRUCTURAL_VERBS`, `verb_usage` (single string), `verb_isomorphism` (chem/math tuple, optional), and `TOOLS_PROMPT`. The verb-coverage test enforces `verb_usage` ↔ `STRUCTURAL_VERBS` sync. See [[project_charge_conservation_frobenius]] (MoDoT) and [[project_lean_prover_loop]] (./ask).

First applied 2026-07-13 building `ask_native/src/imasm.rs` (IMASM polymer composition). The IMASM composition substrate/grammar reference is IMSCRIBr `wiring.py` (port-typed WiredGraph) and `tokens.py::TOKEN_ARITY` — see [[project_imscribr]].
