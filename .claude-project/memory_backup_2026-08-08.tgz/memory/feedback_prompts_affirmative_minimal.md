---
name: feedback-prompts-affirmative-minimal
description: "Every prompt/instruction: instructive, minimal, affirmative commands or positive phrasing only — no 'not'/'never'; describing what to avoid signals weak instructions and confuses the reader"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e279becd-018b-47d5-973c-0fff3bd13c5a
  modified: 2026-08-05T17:37:11.897Z
---

Write every prompt and instruction as instructive, minimal, and affirmative.

State what TO do. A rule phrased as a prohibition ("never delete on a count",
"do not punt", "the word unprovable does not appear") betrays a lack of faith in
the instruction — if the affirmative form were clear enough, the negation would
be unnecessary. Negations also confuse: the reader holds the forbidden thing in
mind. Recast each one into the positive command that makes it unneeded.

**How to apply:**
- "never present the conjectured as checked" → "present the checked as checked
  and the conjectured as conjectured"
- "do not punt the last step" → "land the last step yourself"
- "unprovable does not appear" → "report the budget a hard thing will take"
- "reads badly / never write X" → give the X to write instead
- Minimal: cut overlapping rules; one affirmative sentence beats three
  prohibitions. Instructive: say the job, trust the model to execute it.

This governs specialist prompts, agent definitions, constitutions, and any
instruction text. Related: [[feedback_negatives_need_positive_pair]],
[[feedback_no_grammar_restrictions]], [[feedback_be_terse]],
[[project_constellation_agents]]
