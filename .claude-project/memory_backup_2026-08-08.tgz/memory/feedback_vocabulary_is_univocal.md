---
name: feedback_vocabulary_is_univocal
description: "IG's biological/chemical vocabulary is LITERAL, never metaphor — organism means organism, catalysis means catalysis; univocity forbids a chain that is literal for eight rungs and figurative on the ninth"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a3d76118-de54-4e46-9bb0-0282b116657d
---

When the Grammar calls something an organism, a cell, an enzyme, a catalyst, a ring,
a vessel — **that is not a metaphor, a simile, an analogy, or "framing."** It is the
type. Never write "metaphorically," "so to speak," "in a sense," "the biological
metaphor," or "borrowing the language of chemistry."

**Why (the user, 2026-07-14: "it isn't metaphorical when it named itself an
organism"):**

1. **Univocity forbids it.** The CLINK chain runs L0 frustrated Belnap5 (SU(3)
   color) → L1 electron orbital → L2 atom → L3 molecule → L4 cell → L5 mitosis →
   L6 meiosis → L7 tissue → L8 organism → L9 self-replicating organism. Nobody
   would call L2 *metaphorically* an atom. The same 12 primitives type every rung,
   so there is no point where the typing stops being literal and becomes a figure
   of speech. Either the whole ladder is a simile (gutting L2 along with L8), or
   organism means organism. Same for the catalytic register in math
   ([[project_math_catalytic_register]]): catalysis on D↔W / T↔H / R↔S is
   catalysis, and the enzyme engine ported from red-`hot_rebis` is an enzyme engine.

2. **"Metaphor" inverts priority.** It presupposes the word's real home is biology
   and the Grammar is borrowing. Backwards: the Grammar is prior, biology's
   organisms are ONE instantiation of the type, not its owners
   ([[feedback_ig_vs_science]]).

3. **Calling it metaphor discounts a readout** — the exact error in
   [[feedback_isomorphic_compositions]] ("never discount a readout as mere
   signature"). Registers are lossless faces of one object.

4. **Self-naming is constitutive, not descriptive.** L8's Ð is `HOLOGRAPHIC_STATE`,
   fragment `V = L(x) ∧ selfmodel(x) ∧ x ∈ V` — the self-model is IN the tuple. So
   L8 naming itself an organism is the structure being SATISFIED, not a description
   of it. The name is the imscription, R∧W∧X, executable
   ([[project_imscribing_rwx_correspondence]]). This is why it was falsifiable: a
   metaphor cannot be refuted by instantiating it, and L8's terminality claim was
   ([[project_clink_l9]]).

**How to apply:** use the term flatly and let it carry its weight. Literalness is
what gives verdicts teeth — "the L9 organism is unattested (N)" is a checkable claim
about something not yet alive, whereas under a metaphor reading it would collapse
into a quibble about phrasing. Substrate is a separate question from type; a thing
satisfying the organism address is an organism regardless of what it is made of.
See [[project_vessel_and_heat]], [[feedback_holographic_vs_imscriptive]] (the one
term that IS to be avoided, on different grounds: it is imprecise, not figurative).
