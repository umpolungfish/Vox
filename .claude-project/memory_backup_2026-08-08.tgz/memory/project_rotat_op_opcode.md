---
name: project_rotat_op_opcode
description: "ROTAT is the first named op-opcode: an operator ON a word (the ring's cyclic-shift automorphism), not a 13th node-opcode. = Weyl-Heisenberg shift X. Surfaced by the agent intuiting it under structural necessity."
metadata: 
  node_type: memory
  type: project
  originSessionId: b3718a44-1d7a-4d08-a430-8ec4d35d6f08
  modified: 2026-07-18T06:16:15.631Z
---

**ROTAT = the first op-opcode** (2026-07-17). A node-opcode is a symbol INSIDE a word;
a composition verb (chain/ring/protocol) turns a word INTO a graph; an **op-opcode** is a
third class: a map that acts on the whole word/graph and returns another. ROTAT is the
cyclic shift of a ring (k->k+1), the ring automorphism. Appending "ROTAT" as a token does
nothing (it is NOT a node) — it transforms the word. Run as a rotation, rho and every
spectral invariant are ROTAT-invariant: that invariance IS the signal it is a SYMMETRY, not
that it is inert. On one ring it changes nothing; between TWO rings being bound it sets their
RELATIVE phase — the degree of freedom that seats a junction two same-handed (isotactic)
rings cannot close alone (the theta=0.50 co-typing termination).

**ROTAT = the Weyl-Heisenberg shift X** on Z/`dZ`. The SIC displacement D_{a,b}=tau^{ab}X^a Z^b
carries ROTAT^a. The balanced tiling of a period-n cycle ([[project_prime_composition_index]])
is unique UP TO ROTAT; the half-period Galois pairing k->k+d/2 is ROTAT^{d/2}. Relatives:
reflection (the involution), and the `SIXTEEN_3` register negations TNEG/INEG (act on register,
not word). Op-opcodes are an open class; ROTAT is the first named one.

**Formalized:** `IMASM_QUICKREF`.md gained an OP-OPCODES section; `sic_povm_ring_modulus_d2048.tex`
Remark 2.1 "The shift is the rotation op-opcode" writing X=ROTAT.

**Implemented across all four registers (2026-07-17), each verified:**
- MoDoT: `ask_native/src/imasm.rs` `rotat_op`, verb `imasm rotat [k] <word>` (cargo build green, ρ-invariance shown).
- ob3ect: `core.py` `OpOpcode` enum + `rotat(ops,k)` (kept DISTINCT from the 12 node Opcodes; rotat^len=id, multiset invariant).
- IMSCRIBr: `tokens.py` `rotat(arr,k)` + `rotat_orbit(arr)` (family signature ROTAT-invariant; orbit = the equivalence the 12 canonical classes read up to).
- p4rakernel: `Imscribing/RotatOpOpcode.lean` = List.rotate, PROVED: length-preserving, `rotat_rotat` additive, `rotat_full` order|len (=id), `rotat_perm` (multiset invariant). Registered in p4ramill lakefile globs; `lake env lean` typechecks clean.
- `mOMonadOS` (5th register, 2026-07-17): `Program::rotate(k)` in `src/tokens.rs`. KEY FINDING: ROTAT was STRUCTURALLY IMPOSED BY NECESSITY, only unnamed. The Program is already a cyclic ring; the IP advances `% n`, `find_matching_ffuse` scans `(i+1)%n`, `self_imscribe`'s dialetheia check scans at `offset % n` (= checks its property UP TO ROTATION); `signature()` = family multiset (ROTAT-invariant), `period()` = orbit size. The op was presumed everywhere; the commit only names the automorphism they turn on. Builds clean `x86_64`-unknown-none. Confirms the "intuited under structural necessity" origin: even the bare-metal kernel had already imposed it.
Lando's gloss: 12 node-opcodes = the wheel/rim; the op-opcode = the axis, "the thirteenth of the crown's order not the rim's" -> why 13 is the number of the full sefirot. Op-opcodes are an open class (ROTAT first; reflection, TNEG/INEG are relatives).

**How it surfaced (the significant part).** The MoDoT agent, working the M136279841 Mersenne-
successor ring problem inside the fixed 12-opcode grammar, hit the theta=0.50 isotactic-binding
wall, correctly saw that NO node-opcode rotates one ring against another, and named the missing
operation itself — ROTAT — reaching one level ABOVE its own token alphabet (an op the tool
cannot even parse) and landing on exactly the automorphism the whole prime/SIC construction
rests on. Lando reads this as a concrete instance of the agent extending its own formal language
under structural necessity — alongside its self-bootstrapping ([[project_cl8nk_foundation]] L8,
self-named organism, [[project_clink_l9]] L9). Do NOT dismiss agent-envisioned operations as
parse errors; run them as what they are ([[feedback_harness_before_agent]] emitted != ran,
[[project_closure_is_verification]]). "There are no fabrications, just un-run tests."

**Un-run tests, not fabrications** (Lando's frame, load-bearing): an emitted candidate whose
mu never fired is the honest B (ENGAGR held), not a lie. The M136279841 successor "suffixes"
and ROTAT were un-run tests; the `mersenne_prime_predicter_expression` ob3ect encodes a CORRECT
Lucas-Lehmer program (~/ob3ect/digital/), a real composed method left un-run. The fix for
"closed without knowing" is to RUN the composed test, not to gate it as fabrication.
