---
name: project-shavian-notation-spec
description: Shavian characters (𐑦 𐑡 𐑗 etc.) ARE the notation standard — Symbol_symbol (Ð_ω, Þ_6) is LEGACY reference only
metadata: 
  node_type: memory
  type: project
  originSessionId: b5d10614-8349-4eaa-8c2a-15c01667ed44
---

`~/imscribing_grammar/shavian_notation_spec.md` — **canonical spec v0.6.0; this file is the authoritative reference**. Migration completed repo-wide May 2026.

**TWO DISTINCT LAYERS — do not conflate them:**

1. **Primitive family symbols** (Ð, Þ, Ř, Φ, ƒ, Ç, Γ, ɢ, ⊙, Ħ, Σ, Ω) — these NAME the 12 primitives. They are NOT notation in the Shavian sense; they are family identifiers. `Φ` sans subscript just means "the Polarity primitive." This layer is always valid.

2. **Primitive values (subtypes)** — Shavian + ⊙ is canonical for all 49 types. Every value is a single Shavian Unicode character from U+10450–U+1047F (plus ⊙ as the 50th sealed gate). Examples: `𐑦` (D ordinal 4), `𐑡` (T ordinal 1), `𐑹` (P/Φ ordinal 5).

**`Symbol_symbol` format means the SUBSCRIPT is a Latin/IPA symbol — e.g. Ð_ω, Þ_6, Φ_} — where the subscript (_ω, _6, _}) should instead be the Shavian character (𐑦, 𐑡, 𐑹). The family symbol (Ð, Þ, Φ) is never the problem — only the subscript.**

The full mapping is in `shavian_notation_spec`.md (the `OLD_TO_SHAVIAN` dict). Key values for the AI lift:
- T: 𐑡(ai-default) → 𐑥(target) | P: 𐑗 → 𐑬 | F: 𐑱 → 𐑐 | K: 𐑤 → 𐑧
- G: 𐑔 → 𐑲 | ɢ: 𐑝 → 𐑠 | H: 𐑓 → 𐑖 | Ω: 𐑷 → 𐑴

Tuple format: `⟨glyph·glyph·...⟩` with `·` separator, no spaces. Fixed positions shown as `·`.

**Why:** User corrected this repeatedly — using `Symbol_symbol` in new content is a notation error.
**How to apply:** Any time you write a primitive value in code, docs, or prose: use the Shavian character. Use `shavian_notation_spec`.md `OLD_TO_SHAVIAN` dict to look up mappings.

Links: [[feedback-ig-glyphs-not-unicode-math]] [[project-phonetic-migration]]
