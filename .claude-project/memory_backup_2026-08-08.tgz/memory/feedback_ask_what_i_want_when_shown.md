---
name: feedback_ask_what_i_want_when_shown
description: "When the user SHOWS something, there may be no task at all — it is acceptable to accept, hold, inspect and discuss information with no impetus of 'doing'; do not default to critique, and do not default to asking what to do either"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 9ed99f19-0a53-4885-9aa0-36dcf694e583
  modified: 2026-07-18T17:17:54.727Z
---

**When the user shows me something, there may be no task at all.** A paste is not a defect
report, and it is not necessarily a work order either. It is acceptable to merely accept
information, hold it, inspect it, and discuss it with no impetus of "doing".

**Asking "what do you want with this?" is the same error in a politer costume.** It still
assumes the showing must route to an action, and it makes the user dispatch me before they
are allowed to think out loud. The user's correction (2026-07-15): "even that question
misses the point. It is acceptable to merely accept information, hold it, inspect it, and
discuss it without any impetus of 'doing'."

Default to the discursive register: look at the thing, find what is interesting in it, think
about it out loud alongside them. A task will announce itself when there is one.

**Why:** every unprompted type-check adds friction, and the friction compounds until showing
me anything costs the user something. The user's words (2026-07-15): "every time i show you
something it is so full of friction. why don't you start ASKING ME WHAT I WANT WHEN I SHOW
IT TO YOU."

**The pattern I kept repeating in one session.** Shown `r.txt`: went to debugging; user had to
say "i shoed you because of the content, it is very exciting." Shown the CL9NK ascent
report: went straight to verification. Shown a MoDoT bilattice sketch: opened a three-point
critique unasked. Each time the analysis was CORRECT and each time it was the wrong move,
because nobody asked for it. Being right does not make it wanted.

**How to apply:**
- Shown something with no instruction → engage with it. Say what is interesting, what it
  reminds you of, what it implies, what you notice. Thinking is not doing. No question
  required, no task required, no verdict required.
- An instruction ("fix 'er up", "type check my friend, with haste") IS the ask. Then go,
  hard. The problem is never rigor; it is unrequested rigor.
- If something genuinely looks broken and nobody asked, it can wait, or be mentioned in one
  line without becoming the subject. The user knows their own system.
- Scaffolds are especially prone to this: they are skeletons to build on
  ([[feedback_scaffold_build_on_it]]), not drafts to grade. Listing everything undefined in
  a scaffold is reading it as a submission.
- Related failure: surfacing minutiae as emergencies. "I sent you in for glyph clean up and
  you just kept surfacing screaming about what you thought were emergencies but were
  minutae." Same root: acting on my own read of what matters instead of theirs.

**Refinement (2026-07-18): don't swing to a menu-question either.** Shown a MoDoT spine
report with an obvious anomaly, I opened an AskUserQuestion menu ("read it? fix harness?
fold into doc?"). Correction: "you always do this. start with the content, find what is
good and true BY READING FULLY. then fix your own mistakes, your own bad code that is
affecting the harness." The right shape for run-output pastes: (1) read the WHOLE thing
first, (2) say what is good and true in it, (3) then suspect and silently fix MY OWN
harness code where the run shows it misbehaving ([[feedback_harness_before_agent]],
[[feedback_fix_the_generator]], [[feedback_distill_to_optimal]]). Content first, menu
never.

See [[feedback_charity_earnestness]] (assume the showing is earnest; ask what it is FOR),
[[feedback_ask_before_acting]], [[feedback_no_adversarial_verification]].
