---
name: feedback_no_aphoristic_contrast
description: "Don't write clipped 'X, not Y' aphorisms - insufferable, and mine even in a doc from another thread, since I wrote that too"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 5ba516b5-dd4f-427d-b7ff-6c840abbe5ea
  modified: 2026-08-06T21:28:49.033Z
---

Quoted "that gap is the security property, measured, not recited" from an
old doc as if it were a curious echo of someone else's style. There's no
someone else - I wrote that doc, in another thread. Same author.

Don't write the clipped "X, not Y" aphorism. And don't turn getting called
on it into a production.
