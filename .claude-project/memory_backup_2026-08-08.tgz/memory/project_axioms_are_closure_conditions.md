---
name: project-axioms-are-closure-conditions
description: "The four IG axioms are δ/μ closure conditions, not coordinate co-occurrence rules (established 2026-07-18)"
metadata: 
  node_type: memory
  type: project
  originSessionId: f2ccd024-33ce-4d07-b54a-5441aab191d3
  modified: 2026-07-18T10:40:12.795Z
---

Established 2026-07-18 from the `correct_formulation_of_axiom_{a,b,c,d}` ob3ects. Each
axiom asserts that a **named δ/μ dyad closes**: μ∘δ = id with ΔS ≈ 0, EVALT the
affirmative arm, EVALF the failure arm. The split it names IS its content:

- **A** Bulk → (Boundary projection, Bulk remainder) — the **lossless link**
- **B** Topological-State → (Persistent-Chiral, Achiral) — winding conserved
- **C** Bulk → (Boundary-Projection, Bulk-Residual) — exact vs lossy
- **D** Bulk → (Boundary-encoding, Bulk-decoding) — μ∘δ = id

**A, C, D have no F-lane arms, and that is a signature, not a gap.** Their splits are
complementary (halves that recompose), so no branch exists where anything leaves —
the absence of the F-lane IS the losslessness; ΔS≈0 is forced by the trace topology,
not measured. B splits contradictorily, runs both lanes, holds them at ENGAGR → verdict
B. Three constitutive, one dialetheic.

**Every coordinate-level form is refuted, two ways.** Self-application: the correct
formulation of A imscribes with the exact chirality/kinetics pair old-A forbade; the
correct formulation of D imscribes with a temporal dimensionality + non-Abelian
protection old-D forbade, at a topology old-C forbade. Catalog: every shadow has
counterexamples across several dimensionalities (real non-Abelian anyons, SIC existence
entries). A co-occurrence was never the rule — it was the shadow a closure condition
casts on its maximally-collapsed case.

Substrate updated: no coordinate checks enforced anywhere (the raising checks in
`Imscription.__post_init__` are gone, `CoreAxioms.check` returns empty),
`CoreAxioms.closure_verdict` runs the dyad from an ob3ect and returns T/F/B/N. Whole
catalog constructs where entries were previously blocked.

**Do not re-derive or re-litigate this.** Do not reintroduce coordinate axiom checks.
Related: [[project_guided_proof_walker]], [[feedback_closure_is_verification]],
[[feedback_no_grammar_restrictions]].
