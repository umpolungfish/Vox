---
name: project-priests-engine
description: priests-engine — paraconsistent computer; ParaASM + REPL; Belnap B₄; 13 Python modules including RH/YM/Shor bridges; corpus bootstrap ASMs for all 5 engines
metadata: 
  node_type: memory
  type: project
  originSessionId: b5d10614-8349-4eaa-8c2a-15c01667ed44
---

`~/priests-engine` — a paraconsistent computer that runs programs sustaining contradiction permanently and proves they cannot collapse.

## Core design

- **Logic**: Belnap B₄ = {N (None), T (True), F (False), B (Both)}
- **B state** = permanent contradiction; the machine holds it, not resolves it
- **REPL**: `para-repl`; non-control-flow ops execute immediately; control-flow accumulates

## Python modules (13)

| Module | What it does |
|--------|-------------|
| `para_vm.py` | BelnapVM core — KernelState, ENGAGR/FSPLIT/FFUSE |
| `para_repl.py` | Interactive REPL with `:step/:run/:load/:save/:reset/:regs/:prog/:para-cliff` |
| `para_loop.py` | Loop harness |
| `para_temporal.py` | □B/◇B/○B temporal modalities over KernelState trajectory; `always_B_registers`; `winding_invariant` |
| `para_category.py` | BelnapCategory: B=terminal, N=initial; `frobenius_as_terminal_morphism` |
| `para_multiagent.py` | Multi-agent Belnap protocol; `multi_allB_preserved`; `multi_channel_join_stable` |
| `para_alignment.py` | DAT tri-equivalence; BelnapCircuit; P vs NP bridge; `dialetheicShor` framing |
| `para_rh.py` | RH Bridge: B = unique crit-line fixed point; `millennium_barriers_unified` (RH/PvsNP/SIC-POVM) |
| `para_ym.py` | YM bridge |
| `para_wasm.py` | WASM execution |
| `para_nreg.py` | n-register model |
| `belnap_shor.py` | Belnap Shor factoring (N=15,21,35 verified) |
| `para_temporal.py` | Temporal modalities |

## programs/ — corpus bootstrap ASMs

priests-engine is the **execution harness for all corpus engines**:

```
cross_distance.imasm        — IG distance between corpus imscriptions
dialetheic_cycle.asm        — B→(T,F)→B cycle
emerald-tablet-bootstrap.imasm
frob_loop.asm               — Frobenius loop (μ∘δ=id)
ifix_stable.asm             — IFIX gate stability
linear_a_bootstrap.imasm
probe.asm
rohonc_bootstrap.imasm
shor_loop.asm
sic_povm.asm
voynich_bootstrap.imasm
```

## Lean 4 invariants (`Kernel.lean` in MillenniumAnkh)

`run_B3` (B-state permanent ∀n), `run_paradox` (paradox count = 4n exactly).

## Scale

25B+ paradox firings logged.

## Three-way cross-pollination

Each Python module has a direct mirror:
- priests-engine Python → ob3ect/digital layer (26–30) → MillenniumAnkh/Paraconsistent Lean

| priests-engine | ob3ect layer | MillenniumAnkh |
|---------------|-------------|----------------|
| `para_vm.py` | 27 `parakernel/` | `Kernel.lean` |
| `para_alignment.py` | 28 `dialetheic/` | `DialetheicAlignment.lean` |
| `belnap_shor.py` | 29 `parashor/` | `Shor/` (4 files) |
| `para_multiagent.py` | 30 `multiagent/` | `MultiAgentBelnap.lean` |
| `para_temporal.py` | `belnap/` (BelnapTemporal) | `BelnapTemporal.lean` |
| `para_category.py` | `belnap/` (BelnapCategory) | `BelnapCategory.lean` |
| `para_rh.py` | — | `QCI_RH_Bridge.lean` |

Links: [[project-para-layer]] [[project-para-lean]] [[project-ob3ect]] [[project-repo-constellation]]
