---
name: dialect-navigator-core-map
description: Reconciliation of the cl8nk_navigator glyph axis labels with `Core.lean` named axes (two dialects of the same 12 primitives)
metadata: 
  node_type: memory
  type: reference
  originSessionId: 1fc76595-fa57-41c3-928a-d87e0792d85d
---

The `cl8nk_navigator` (`CL8NK_FORMULAE`) labels the 12 axes with one glyph
alphabet; `Smaragdine_Synthetica/lean/Core.lean` labels them with another. Same
12 axes, same tuple positions. Mapping fixed by fragment content AND confirmed
by matching family cardinality (𝓕₃/𝓕₄/𝓕₅ value counts agree position-for-position):

| Pos | Navigator | Core axis | Family |
|----:|:---------:|:----------|:------:|
| 1 | Ð | D Dimensionality        | 𝓕₄ |
| 2 | Þ | T Topology              | 𝓕₅ |
| 3 | Ř | R Relational Mode       | 𝓕₄ |
| 4 | Φ | P Parity/Symmetry       | 𝓕₅ |
| 5 | ƒ | F Fidelity              | 𝓕₃ |
| 6 | Ç | K Kinetic Character     | 𝓕₅ |
| 7 | Γ | G Scope/Granularity     | 𝓕₃ |
| 8 | ɢ | Γ Interaction Grammar   | 𝓕₄ |
| 9 | ⊙ | Φ Criticality           | 𝓕₅ |
| 10 | Ħ | H Chirality             | 𝓕₄ |
| 11 | Σ | S Stoichiometry         | 𝓕₃ |
| 12 | Ω | Ω Topological Protection | 𝓕₄ |

WATCH OUT: the glyphs Γ, Φ, Ω appear in BOTH dialects but at DIFFERENT axes.
Navigator-Γ = Core-G (granularity), Core-Γ = navigator-ɢ (grammar). Navigator-Φ
= Core-P (parity), Core-Φ = navigator-⊙ (criticality). Never assume same glyph =
same axis across dialects. `Core.lean` is authoritative for axis meaning/ordinals
([[reference_glyph_ordinal_scripture]], [[feedback_dialects_not_universes]]).
