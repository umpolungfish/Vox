---
name: no-agent-execution
description: Never execute agents — only prepare prompts; user runs agents themselves
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2fb1fb52-7563-4953-888b-6af8a508e24b
---

Never invoke `true_agentic_agent.py`, `auto.py`, or any other agent harness directly.
Prepare prompt text only; the user runs all agents themselves.

**Why:** User explicitly stopped an agent execution mid-run and stated "I will run any agents."

**How to apply:** When asked to "run" an agent or "put together a prompt set," write the
prompt text ready to paste — do not invoke via Bash, subprocess, or any other mechanism.
If asked to "run it," interpret as "show me the prompt to run" unless the user explicitly
grants execution permission in that specific exchange.
