---
name: feedback-papers-are-not-process-logs
description: "A manuscript states what is shown, how it was done, and what it means; never the sequence of attempts, wrong turns, or corrections that produced it"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e279becd-018b-47d5-973c-0fff3bd13c5a
  modified: 2026-08-05T09:03:42.332Z
---

**A paper is not a log.** Tell the reader what is shown, how we did it, and what
it says. Nothing else.

**Why:** turning a manuscript into a step-by-step record of the work — including
every wrong thought corrected along the way — is abnormal for the form and reads
as noise to any reader. The reader wants the result and the method, not the
route.

**Cut on sight:**
- "an earlier draft asserted X, which was wrong" — the paper states what is true
- instrument defects found and fixed mid-work, unless a reported number depends
  on the fix in a way the reader must know
- reproduction/provenance sections that narrate which script produced a table
- essayistic framing sections about the gap being closed; open with the
  construction
- acknowledgements that recount how the result came about

**Keep:** a correction that is itself a *result* (e.g. "no phase lies on the
lattice, and this is forced") stated as the finding, never as the story of
discovering it. Scope limits stay — what is and is not established is part of
the claim, not process.

Related: [[feedback_no_dev_narrative_in_docs.md]], [[feedback_be_terse]],
[[feedback_write_for_curmudgeons]], [[feedback_no_honesty_throat_clearing]],
[[feedback_forward_orientation]]
