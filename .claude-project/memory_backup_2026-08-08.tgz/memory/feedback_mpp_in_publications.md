---
name: feedback-mpp-in-publications
description: Do not mention Millennium Prize Problems in early publications — keep MPP witnesses internal
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f8d56b99-41f1-4c68-9da8-8ceec96a4157
---

Keep MPP witnesses (RH, YM, BSD, Hodge, NS, PvsNP, OPN) internal to p4rakernel. Do not surface them as selling points or evidence in early publications.

**Why:** Mentioning MPP claims in publications before the core structural framework is established turns reviewers into adversaries before they've engaged with the theory. It reads as overselling and undermines credibility. The structural work (Frobenius closure, Crystal of Types, Belnap, `ZFC_fe`) stands on its own.

**How to apply:** MPP witnesses may be referenced in p4rakernel Lean files as structural exercises/witnesses. In manuscripts and Zenodo submissions, omit MPP mentions entirely or confine them to a single footnote at most — only after the framework has independent standing. Do not add MPP sections to papers.

See also: [[feedback-mpp-framing]] (MPP sorries are grammar claims, not impossibility barriers)
