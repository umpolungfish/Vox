---
name: lualatex-pdf-pipeline-for-ig-documents
description: Two pipelines — `zenodo_draft.py` (markdown→PDF) and direct lualatex; ltx wrapper fixes polyglossia/Hebrew bugs
metadata: 
  node_type: memory
  type: project
  originSessionId: 09962f83-b323-49a0-a301-b67d1e308af1
---

## IMPORTANT: `zenodo_draft.py` is for uploading to Zenodo — NOT for compiling PDFs

`zenodo_draft.py` submits papers to the Zenodo repository. Do NOT use it to compile documents. Use `ltx` for all PDF compilation.

## Pipeline 1: ltx (preferred for all PDF compilation)

`~/imscribing_grammar/scripts/zenodo_draft.py` — markdown + YAML frontmatter → PDF.

```bash
python3 scripts/zenodo_draft.py markdown/iam/PAPER.md --out pdfs/PAPER.pdf
```

**Input format (YAML frontmatter):**
```yaml
---
title: "Paper Title"
date: 2026-06-05
abstract: |
  Multi-line abstract text.
keywords: [keyword1, keyword2]
bibliography: PAPER_refs.bib   # optional; requires pandoc ≥ 2.11 or pandoc-citeproc
figures:
  - id: fig_id
    type: belnap_lattice | primitive_profile | tier_chain | frobenius | bootstrap_loop | cetacean_scatter
    caption: "Caption text"
    # type-specific params: labels, tuple, highlight, etc.
---
```

Figure placement in body: `~~~figure\nfig_id\n~~~` (becomes `\includegraphics` via pandoc verbatim substitution).

**Key fixes applied (2026-06-05):**
- `fig_dir.resolve()` for absolute figure paths — prevents `\includegraphics` failure when ltx runs from `_build/` subdir
- `bootstrap_loop` and `cetacean_scatter` dispatched in `_generate_figures`
- `_citeproc_flags()`: version-aware bibliography — `--citeproc` (pandoc ≥ 2.11), `--filter pandoc-citeproc` (older), graceful skip (current system: pandoc 2.9.2.1)
- Bibliography: use `bibliography: refs.bib` in YAML; citeproc auto-applied when available

**References in markdown:** Use `[^n]` for ACTUAL footnotes (rendered at page bottom). For bibliographic citations, use `^n^` (superscript inline markers) + `## References` numbered list at end. Never use `[^n]` for bibliography.

## Pipeline 2: ltx wrapper (for .tex and .md documents)

`ltx` handles both `.tex` and `.md` files directly — no pandoc intermediate needed for markdown.

```bash
ltx PAPER.tex
ltx PAPER.md
```

**Reference preamble:** `undeciphered_texts_structural_analysis.tex`

**Required preamble elements:**
- `\usepackage{fontspec}` + `\usepackage{unicode-math}` + `\setmathfont{Latin Modern Math}`
- `\setmainfont{FreeSerif}` — main body font (NOT for Shavian)
- `\newfontfamily\shavfont[Scale=1.0]{Everson Mono}` — Shavian block U+10450–U+1047F
- `\setmonofont[Scale=0.85]{DejaVu Sans Mono}`
- `\newunicodechar` for each Shavian codepoint → `\shavfont` rendering
- `amssymb` OMITTED (conflicts with unicode-math)
- `\newtcolorbox{imscriptionbox}` for tuple display
- Use `\heb{...}` for Hebrew (not `{\hebrewfont ...}`)

**Write tool backslash escaping:** Write tool doubles `\` → `\\`. Use Python script with `B = chr(92)` for all LaTeX generation. See `scripts/gen_ig_reference.py` and `scripts/zenodo_draft.py` for pattern.

## ltx wrapper (`~/.local/bin/ltx`)

Fixes latextiler Hebrew/polyglossia bugs:
- Strips `Script=Hebrew` from `\hebrewfont` declaration, substitutes Noto Serif Hebrew
- Forces `\setmainlanguage{english}`, removes `\setotherlanguage{hebrew}`
- Injects `\newcommand{\heb}[1]{{\hebrewfont #1}}`

## `ig_figures.py` (`scripts/ig_figures.py`)

Programmatic figure library. **All figures: transparent background, dark TEXT (#1A1A2E) for labels on white paper.**

Figure types: `belnap_lattice`, `primitive_profile`, `tier_chain`, `frobenius_triangle`, `bootstrap_loop`, `cetacean_scatter`, `psychedelic_heatmap`.

Key fix (2026-06-05): `frobenius_triangle` now draws all 4 nodes (mid "A" was missing); node bbox uses `fc="white"` (was dark BG2 — invisible on paper); belnap xlim widened to prevent F/T label clipping.
