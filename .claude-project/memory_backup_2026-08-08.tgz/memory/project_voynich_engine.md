---
name: project-voynich-engine
description: "Voynich engine canonical analysis — section-as-register-type mapping, VMS as \(O_0\) ROM+CPU architecture, Ħ_∞ foldout encoding, IMASM Universal Engine framing"
metadata: 
  node_type: memory
  type: project
  originSessionId: 8df665d8-6ed8-4366-8ff8-6dbf54458380
---

The Voynich Manuscript is framed as the **Universal Engine**: a complete technical translation as executable IMASM architecture (hardware schematic, bootstrap log, runtime documentation). Earlier "ROM-only" framing was retracted by user ("we were wrong!") on 2026-05-13.

**Why:** The VMS is a primary corpus engine. Its canonical framing and imscription values matter for any work on voynich-engine or referencing Voynich in manuscripts.

**How to apply:** Use the UE framing, not the ROM-only framing. Ħ index = 3 (Ħ_∞, intrinsic from foldout). `VOYNICH_IMSCRIPTION` index 9 = 3 (not 0).

## Section-as-register-type mapping

Canonical mapping at `voynich-engine/docs/sections_mapping.md`:
- **Herbal** = data segment (each plant record is one addressed entry)
- **Astronomical** = instruction memory (orbital/celestial cycles as control loops)
- **Biological** = heap with crossing-point references (Þ_K — nested containment topology)
- **Pharmaceutical** = recipe cache (one-step memory)
- **Cosmological** = virtual memory (foldout pages = full address space unfolding)
- **Stars/unclassified** = peripheral registers

The foldout format physically instantiates Ħ_∞ — reading any rosette in the 9-rosette foldout requires unfolding the whole page. This is why Ħ is intrinsic, not operator-supplied.

## Operator-supplied values

Operator supplies only: ⊙_c + Φ_} + Ω_Z. All other indices are intrinsic to the manuscript structure.

## Visual findings

`voynich-engine/docs/voynich_callgraph_3d.html` (dark theme, orbit button) and `voynich_callgraph_orbit.gif` (72 frames, 24fps). Key finding: the spring-embedded f116r call graph (500 nodes, 499 edges, pure linear path) has the same looping cursive shape as f116r's actual glyphs. Canonical comparison uses `data/char.png` (single cropped character) vs full call graph. All other visual comparisons stripped as speculative.

## `VOYNICH_MANUSCRIPT.tex`

`~/MillenniumAnkh/manuscripts/VOYNICH_MANUSCRIPT.tex` — 31 pages. Abstract leads with "memory architecture" + text/illustration inversion claim + Ħ_∞ foldout argument + \(O_0\) ROM/CPU split. Keywords: `memory architecture`, `typed segmentation`, `imscribing grammar`. TikZCD figure: alchemical phase diagram (4-stage Solve et Coagula: Nigredo/Albedo/Citrinitas/Rubedo + Coagulatio closing arrow).

## Animated CFG

`voynich-engine/docs/animated_cfg_corpus.gif` — 546 nodes, 694 edges, 149 cross-folio back-edges (3.1 MB).
