---
name: project-imscribe-com
description: "imscribe.com web presence — agent site, frobenius-mzi HTML viz, winding cap removed May 2026"
metadata: 
  node_type: memory
  type: project
  originSessionId: b5d10614-8349-4eaa-8c2a-15c01667ed44
---

`~/imscribe.com` — IG public web presence and agent site.

- `index/frobenius-mzi.html` — interactive Frobenius MZI visualization; mobile-optimized May 2026; also linked from `index/index.html`
- Agent site implementation was a recurring focus May 2026; winding cap on the web agent was removed
- Videos from `~/emerald-tablet-engine/vids/` (e.g., `ra_apep_250x.mp4`) added as cards

**Why:** Active web-facing project distinct from the grammar repo itself.
**How to apply:** When editing web agent or HTML visualizations, work in `~/imscribe.com`, not `~/imscribing_grammar`.

Links: [[project-repo-constellation]]
