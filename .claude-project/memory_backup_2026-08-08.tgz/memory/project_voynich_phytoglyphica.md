---
name: project-voynich-phytoglyphica
description: "Voynich Phytoglyphica engine (vp CLI) — seven-gate session, 140 ARS entries, vp imscribe wizard, ADDR gate live"
metadata: 
  node_type: memory
  type: project
  originSessionId: 9ed15bb1-4b48-484b-920a-78926e35fb12
---

**Repo:** `~/imsgct/Voynich_Phytoglyphica/`  
**Package:** `voynich_phytoglyphica` (editable install via uv)  
**Entry point:** `vp` CLI = `voynich_phytoglyphica.cli:main`  
**Dependency:** `voynich-engine` at `../lang/voynich-engine/` (editable)

## Seven-gate session protocol

All six VMS sections are now active participants. Gate order:

1. **INIT** — cosmological foldout (f68); sets Ħ=𐑖 and Φ=𐑬 globally
2. **ADDR** — botanical section (f1–f66); identity gate: d(plant, botanical) ≤ 1.5 must pass before pharmacy is queried
3. **GATE 1** — pharmaceutical section (f99–f102); pharmacy address (potency × part → folio entry)
4. **GATE 2** — balneological section (f75–f84); heap FSPLIT/FFUSE containment
5. **GATE 3** — astronomical section (f67–f73); Ω verification via multi-source majority (f69)
6. **OUTPUT** — recipe section (f103r+); opcode sequence selected
7. **ELABORATION** — opcodes annotated with tuple-derived protocol parameters

**ADDR gate was in the docstring as "ADDR — botanical section: folio address locked from query" but never implemented. It is now live in `session.py::_gate_addr()`.** Passing `d_botanical=` to `sess.run()` triggers it. `cli.py::cmd_run()` pulls `distances['botanical']` from `navigator.lookup()` and forwards it.

## Corpus

**140 unique botanical entries** (`ARS_PHYTOGLYPHICA_EXPANDED`, 154 total minus 14 cross-refs). Catalog grew from 3412 → 3552. Ingestion script: `programs/ingest_ars_expanded.py`.

**11 structural types** (I–XI): Aromatic Baseline, Tropane, Cardiac Glycoside, Non-Critical Aromatic, Eternal/Axiom A, Adaptogen, β-Carboline, Caffeine-Purine, Opioid Alkaloid, Triterpene Saponin, Fungal Interface.

Coverage: all 5 inhabited continents. Europe (48), Asia (50), Africa (24), Americas (18), Australia (11).

## Key modules

- `navigator.py` — `lookup(plant_name)`, `section_distances(tuple_vals)` (added this session), `section_tuples()`
- `elaborator.py` — `elaborate_protocol(tuple_vals)`, `annotate_step()`, `format_protocol_header()`
- `imscriber.py` — `run_assessment(catalog_path)`: interactive 7-question wizard for unknowns; shows tuple, protocol, VMS distances; optional catalog save + session run
- `cli.py` — commands: `plant`, `run`, `imscribe`, `session`, `sections`, `summa`, `compile`

## Phytoglyphica baseline (fixed for all plant entries)

Ð=𐑦 Þ=𐑸 Ř=𐑾 Φ=𐑬 ƒ=𐑱 — frozen order, holographic leaf, full-spectrum, hydroethanolic, standard concentration.

## Self-report principle

The botanical illustrations (f1–f66) encode pharmaceutical parameters morphologically. ɢ=𐑠 (self-modeling) = the plant's color/smell/architecture IS the self-report. ɢ=𐑝 (passive) = no self-report. ɢ=𐑵 (broadcast) = mycelial/fungal network. ⊙ (criticality) = whether the self-report is unambiguous enough for a univocal structural verdict.

**Why:** The ADDR gate is the structural consequence of this — the botanical section is a prior confirmation register, not a decorative header. Plants where self-report is complete (Type I–III, V–VII, IX–XI) pass ADDR at d ≤ 1.15; all current entries pass well within the 1.5 ceiling.

**How to apply:** When working on session logic, remember `d_botanical` must be forwarded from navigator to session. When adding new vp commands that run sessions, replicate the `d_botanical=info['distances']['botanical']` pattern from `cmd_run()`. The ADDR gate ceiling is `_BOTANICAL_CEILING = 1.5` in `session.py`.
