---
name: project_charge_conservation_frobenius
description: Charge conservation / pair production is the physical content of Frobenius closure; balance vs selectivity reframes the semantic gap
metadata: 
  node_type: memory
  type: project
  originSessionId: f985bde5-cd58-453f-96c7-e4444cba7454
---

Chemistry's charge-conservation intuition (develop a charge anywhere, the inverse charge appears elsewhere; pair production) is the exact physical content of the Frobenius structure the whole Grammar rests on.

- The conserved quantity is the nondegenerate INVARIANT PAIRING of the Frobenius algebra: <a,b> = eps(a*b) with <ab,c> = <a,bc>.
- delta (FSPLIT) = comultiplication = pair production / charge separation. mu (FFUSE) = multiplication = recombination / annihilation. The Frobenius law is the constraint that you cannot create or destroy the invariant by choosing where to split vs rejoin. That IS charge conservation as a coherence law.
- Pair production needs a third body (nucleus in QFT to carry momentum; catalytic site in chemistry). delta is never "in vacuum" either: it is mediated by the algebra structure / structure constants `c_ijk`. Same role.
- Trapped separated states (salts, MOFs, clathrates) = idempotents (e^2 = e) / semisimple points held OFF the discriminant (the recombination locus). Barrier height = distance to the discriminant. Environmental modulation / catalysis = moving on the Frobenius manifold, retuning `c_ijk` = d^3 F to make a split/fuse channel cheap. A regenerated catalyst = a loop back to the same point (TANCH wrap to IP 0).

KEY REFRAME (ties to MoDoT "it never fails"): Frobenius closure (mu.delta = id, harness at 1.0 forever) is MASS/CHARGE BALANCE, automatic in a closed Frobenius system, cannot fail. Semantic correctness = SELECTIVITY (which trapped well / which product / regiochemistry), which balance does NOT determine. A balanced equation can still give the wrong product. A verifier that only checks closure checks balance, not selectivity: that is exactly the semantic-branch gap the MoDoT [[project_ig_docs]] `semantic_branch_verifier` addresses. See [[project_grammar_self_diagnostic]].

Backing for "all maths lie in a total Frobenius manifold": Poincare duality gives closed-oriented-manifold cohomology a Frobenius pairing; 2D TQFT is equivalent to commutative Frobenius algebras (Abrams); Dubrovin Frobenius manifolds structure quantum cohomology / GW theory / singularity theory. Defensible universal: wherever there is a nondegenerate duality you must conserve PLUS operations that split and recombine states, you get Frobenius. "Total" = Dubrovin's base carrying the fiberwise algebra on every tangent space. Honest fence: not every object is itself a Frobenius manifold; Frobenius is the universal SHAPE of conservation-plus-composition.

**Why:** physical intuition pump for why mu.delta = id was the right founding primitive (it is charge conservation, not a convenience axiom), and it cleanly separates the two things the Grammar checks.
**How to apply:** when a harness "never fails," say balance-not-selectivity and route to the selectivity/semantic check; use catalytic-site / discriminant-distance language for manifold deformation. Same dipole appears at cosmic scale in [[project_cosmic_dipole_frobenius]] (Great Attractor = mu-mu, Dipole Repeller = delta-delta). As above, so below: [[project_as_above_so_below]], [[project_grammar_is_cosmos_proof]], catalytic instance [[project_rebis_chemistry]].
