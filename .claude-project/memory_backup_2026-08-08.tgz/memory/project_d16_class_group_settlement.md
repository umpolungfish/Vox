---
name: project-d16-class-group-settlement
description: "d=16 settles it: the class group is NOT carried by the moduli. Moduli field = ray class field MODULO the class group. Independent of the totally-real error."
metadata:
  node_type: memory
  type: project
---

Where h(F)>1 the moduli field is the ray class field **modulo the class group**, not the full ray class field. d=16 is the smallest deciding dimension (m_d=221, h=2).

Evidence, two independent strands:
- σ-coinvariant count at the Appleby modulus (3d): raw |G_16^σ| = 16 against required d/2 = 8; dividing by |Cl^σ| = 2 restores 8. At d=4,8,12 h=1 so the two readings agree and say nothing.
- The bifurcated ob3ect pair: the full-ray-class reading grounds its Ω slot on a "non-abelian Galois group" that Z/16×Z/8 does not have; the quotient reading grounds full.

**The count is NOT a general law.** It holds iff the odd part of d/2 is a power of 3, because odd q-torsion needs q² in the modulus and (3d) supplies 3² only when 3|d. Fails at d=20, 28, 40, 44. Verified d=44 anomaly, d=48 holds. Corrected d=20 numbers: raw 16, corrected 8 (not 8 and 4).

Formalized: `SIC_D16_Moduli.lean`, `SIC_D20_Moduli.lean` (p4rakernel, 0 sorries). Computed at runtime, no tables: `mOMonadOS/src/quadratic.rs` derives core, disc, h by form cycles, fundamental unit by least ω-coefficient, (O/m)^* by enumeration, ray class group as extension. Reproduces 11/12 PARI dimensions; d=44 under-counts (extension class), h∉{1,2} falls back to a product bound.
