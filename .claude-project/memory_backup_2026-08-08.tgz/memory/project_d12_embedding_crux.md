---
name: project_d12_embedding_crux
description: d=12 SIC embedding capstone — COMPLETE (p4rakernel 488e22b, 2026-07-04): crystal_forces_d12_sic IS A THEOREM, axiom retired from SIC_POVM_Functor, zero sorries, full lib green, axiom audit clean (standard trio + native_decide pair only). Bridge block's 4 transcription defects fixed (2 rfl closures, lambda→placeholder in sum_univ_eq_sum_range, hjk exponent rewrite)
metadata: 
  node_type: memory
  type: project
  originSessionId: a633b95b-7e17-4841-a6bc-24bbd1e2753b
---

State of `SIC_D12_Embedding.lean` (the capstone that discharges `crystal_forces_d12_sic`; see [[project_d12_sic_build]]):

GREEN + committed (p4rakernel): **Phase A** — `evalK16 g0C` is a ℚ-algebra map on K16 (`evalK16_kadd`, `evalK16_kmul` + all Horner/`reduceGo`/`subHead` lemmas). **Phase B additive** — `phi_radd` via `phi_insertAdd`/`phi_foldl_insertAdd`. Fixed a real bug: `evalKey` cover factors must be `sVal 0,1,2,3` (bit-indexed to match `covCorr`'s `covK 0,1,2,3 = M0,M1,M3,M9`), was `sVal 0,1,3,9`.

OPEN sorries: `phi_rmul`, `phi_rconj`, `norm_sq_eq_one`, `equiangular`.

**WRONG-ROOT BUG (found + FIXED 2026-07-04):** `k16Poly` is even → 8 real roots
`±2.008573, ±1.530596, ±1.187351, ±0.904799`. The Lean pinned `g0` in `(0,1)` (the
`≈0.9048` root) — WRONG. The SIC fiducial embeds at `g0 = -2.00857305` (the negative
branch; odd powers make sign matter). Repointed `exists_root`/`g0` to the IVT bracket
`k16Poly(-2009/1000)>0`, `k16Poly(-2008/1000)<0`, so `g0 ∈ (-2.009,-2.008)`. Phase A is
root-agnostic (uses only `g0_root`), stayed green. Data source: `~/imsgct/d12_sic_build`
(FINDINGS.md; `g0=-2.008573054090`). At that g0 the four cover moduli are positive:
`evalK16(g0,M0)=0.03118, M1=0.01950, M3=0.23405, M9=0.04330`; `N0 = 1/12 - √2/24 +
√13/156 - √26/312` exactly (Q(√2,√13)).

**REMAINING CRUX — cover-modulus positivity feeds `phi_rmul` only.**
- Real-by-construction generators: define `sVal b := ((Real.sqrt (evalK16R g0 (covK b)):ℝ):ℂ)`.
  Then `star(sVal b)=sVal b` HOLDS BY CONSTRUCTION (real coercion) → `phi_rconj`, `norm`,
  `equiangular` star-structure need NO positivity. And `norm` lands on `(1:ℂ).re=1`
  regardless of individual moduli signs (sum is exactly 1 via `norm_sum`).
- Positivity `evalK16R g0 (M_b) ≥ 0` is needed ONLY for `sVal b^2 = evalK16 g0C(covK b)`
  (Real.`sq_sqrt`), used in `phi_rmul`. Plus the analogous `u1Val^2=E2Val`, `c5Val^2=-oa·c5-ob`.
- Positivity is HARD numerically: the moduli (~0.03) arise by cancellation of ~10^4-size
  terms in the degree-15 power-basis poly, so a `[-2.009,-2.008]`-wide interval is far too
  loose for naive interval arithmetic, and a tight-enough interval blows up `norm_num`.
  The clean route is the EXACT field form (e.g. N0 ∈ Q(√2,√13), bound the surds) — but that
  needs the K16-power-basis-at-g0 ↔ Q(√2,√13) embedding relation. Best attacked with the
  `d12_sic_build` gp/field machinery, not raw Lean interval bounds.

ob3ect batch `~/ob3ect/d12_embedding_capstone.yaml` ran, validated the decomposition
(`is_valid_ob3ect: True`, tier \(O_2\), Frobenius-closed) but emits IGProtocol typing not tactic
proofs. Next: build real-`Real.sqrt` generators + `phi_rmul` (`contrib_sound` red1/red2/red3 +
`covCorr_sound`), isolating the 4 positivity facts + u1/c5 square identities as the only
remaining sorries; then transfer via frozen `coord_moduli`/`norm_sum`/`existence_identities_all`.

**CONT 2026-07-04 — STRUCTURAL PLANKS ALL GREEN; 4 sorries left; ROUTE RESOLVED.**
`phi_rmul` (canonical-key domain, keys<128 — wild-key statement FALSE), `phi_rconj`
(`star_u1Val` DERIVED, no Complex.abs), `norm_sq_eq_one` all PROVEN (p4rakernel b154261).
`X_d` bug fixed: `(k+d-1)%d` not `(k-1)%d` (Nat truncated sub broke the WH displacement;
only sorried equiangular consumed it). Remaining sorries: `cover_modulus_nonneg`,
`c5_discr_nonneg`, `u1Val_sq`, `equiangular`. **ig-agent TAOU bracket run (user-run)
banked:** g0 = -2.00857305408968940053241838213116417223197483299531417088 (80 digits
available); 9-digit IVT bracket [-401714611/2e8, -1004286527/5e8] sign-change confirmed;
M0≈0.031177, M1≈0.019498 (tightest), M3≈0.234048, M9≈0.043302, discr=OA5²-4·OB5≈8.058944
(exact deg-15 K16 vector banked in the run), C2H≈0.341398, S2H≈0.939921. Naive interval
Horner BLOWS UP ([-55,+71] on discr — dependency problem); endpoint-float checks are NOT
certificates. **Resolved route (batch `~/imsgct/ob3ect/d12_boundary_discharge.yaml`,
ob3ect commit 4758b60, ctx refreshed):** (1) retighten g0 bracket to 1e-12 rationals
(lo=-2008573054090/1e12, hi=-2008573054089/1e12), exact signs `native_decide`; (2)
divided-difference certificate — q(x)=(p(x)-p(mid))/(x-mid) EXACT in ℚ[x], so
`evalR` ≥ p(mid)-(w/2)·Σ|qᵢ|Bⁱ, B=2009/1000, pure ℚ, no intervals/MVT/floats; covers both
positivity sorries + S2H>0; (3) u1 half-angle reconstruction u1=√((1+x)/2)+i·√((1-x)/2),
x²+y²=1 via frozen `u1_unit` through phi ⇒ `u1Val_sq` DERIVED, Complex.sqrt eliminated;
(4) equiangular transfer via `existence_identities_all` (norm-proof shape). Navigator
anchor: `stark_unit_sic_v2` \(O_2\) d=0.5634; `conventional_sic_povm_hilbert` \(O_0\) d=1.0959.
User runs: `cd ~/imsgct/ob3ect && python3 auto.py -f d12_boundary_discharge.yaml`.

**CONT 2026-07-04 later — 3 BOUNDARY SORRIES DISCHARGED; ONE LEFT (equiangular).**
Batch ran 5/5 Frobenius PASS; cont.22 (`d12_sic_build` 2d31a94) banked exact-Fraction
certificates via `gen_lean_boundary.py` → `boundary_cert_data.txt` +
`boundary_cert_lean.txt` (`native_decide` fragment). Integrated into
`SIC_D12_Embedding.lean` (p4rakernel 8e369f1; +339 lines; NOTE commit message is a
stale reuse of b154261's — says "3 O0 boundary sorries" but the blob has them proven):
1e-12 bracket repoint (`certLo`/`certHi`, ℚ `native_decide` signs lifted via `push_cast` bridge,
NOT `norm_num` on ℝ); `cert_id_*`/`cert_margin_*` divided-difference planks for
M0,M1,M3,M9,D5V,S2H (worst hw·L=3.2e-5 vs margin 8.06 on D5V; tightest M1 margin
1.95e-2); `e2_unit_k16` exact; u1 half-angle redefinition. `cover_modulus_nonneg`,
`c5_discr_nonneg`, `u1Val_sq` now PROVEN lemmas. Sole remaining sorry: `equiangular`
(line ~1181). Full route banked in `~/imsgct/d12_sic_build/d12_boundary_ctx.md` §4:
Z=phi(zeta) ∈ {ω, ω⁵} either-branch trick — zR²=3/4 exactly from Φ₁₂ transfer, both
branches self-inverse mod 12, b:=(m·c)%12 bijects the 143 pairs, NO `zR`>0 certificate
needed; finish via Oab/Ocab + `rT13` (S·star S = phi(`rT13`) = 1/13). CAUTION: as of
session start the post-integration state had NOT been rebuilt (.olean 04:40 < source
06:58) — verify green before claiming.

**CONT 2026-07-04 — COMMIT ARCHAEOLOGY: HEAD 8e369f1 NEVER COMPILED.** `lake build`
of the module fails (exit 1). The exit-0 I first saw was `tail`'s code through a pipe,
not lake's. Two MECHANICAL defects, both in the boundary block 8e369f1 pasted in (not
math): (1) line 492 `abs_add` — Unknown identifier in Mathlib v4.28.0 (renamed; the
goal is |c+x·e| ≤ |c|+|x·e|, needs the current triangle-ineq name); (2) line 601
`evalK16_one16` used inside `xE2_sq_add` but DEFINED at line 954 → forward reference,
Unknown identifier (in parent b154261 the def was at 687 and no use existed at 601; the
inserted boundary block reaches backward). Fix = rename `abs_add` + move/inline the
one16-eval fact (or hoist `evalK16_one16` above line 601). 8e369f1 ALSO: reused
b154261's commit message verbatim (says "`norm_sq`... Remaining: equiangular + 3 O0
boundary sorries" — describes the PARENT, not the boundary integration it actually
made), and swept in ~30 unrelated lean/mathlib test README files (+430/-117). Last
coherent/plausibly-green commit = **b154261** (4 sorries, 0 `cert_id`, no `abs_add`, no
forward ref). The boundary certificate ARITHMETIC is real and banked (exact ℚ divided-
difference certs, `native_decide` list identities `cert_id_M0`..S2H) — only the Lean glue
is broken. Systemic across repos: consecutive same-message commits (ob3ect 5 pairs,
p4rakernel 4 pairs incl. 189e1d7~b154261~8e369f1 all sharing the norm message).
CORRECTED CAUSE (user told me 2026-07-04): these are the user's `pushed` BACKGROUND
BACKUP DAEMON snapshotting the working tree periodically and reusing the previous commit
message + pushing — NOT an agent re-committing. So: (a) commit MESSAGES here are
unreliable as state descriptions (read the blob/diff, not the log); (b) my working-tree
changes get auto-committed+backed up even if I don't `git commit` (so "nothing to commit"
after edits is normal — the daemon already banked them); (c) I still make explicit commits
when an accurate message matters, and I NEVER push (that's the user's daemon, not me).

**CONT 2026-07-04 — HEALED + GREEN (commit 469f787).** Applied the two-line heal:
(1) `abs_add` → `abs_add_le` in `abs_evalQR_le` (Mathlib v4.28.0 renamed the triangle
inequality |a+b|≤|a|+|b|); (2) inlined the `evalK16_one16` forward-ref in `xE2_sq_add` as
`rw [show evalK16 g0C one16 = (1:ℂ) by simp [one16, evalK16], Complex.one_re]` (no hoist
needed; def stays at 954). `lake build` of the module AND the full library both GREEN
(8342 jobs, matches known full-compile size; only a weak `native_decide` style-lint in the
unrelated `Clay_UnclosedResistance`). No mathematics changed — pure transcription heal; the
divided-difference certificate arithmetic was already sound. `.olean` verified fresh
(newer than source), sole remaining sorry = `equiangular` (line ~1182). LESSON re-learned:
exit-0 through a `| tail`/`| grep` pipe is the PIPE's exit code, not lake's — verify via
the .olean mtime or the "Build completed successfully (N jobs)" line, never the shell exit
of a piped lake build.

**CONT 2026-07-04 — equiangular REDUCED to ONE analytic bridge lemma; ring-side PROVEN
(p4rakernel 666bafc, full lib green 8342 jobs).** Replaced the opaque `equiangular` sorry.
NOW PROVEN green: `overlap_normSq {a b}(a,b<12)(¬(a=0∧b=0)) : Complex.normSq (phi (Oab a b))
= 1/13` — the ENTIRE ring-side equiangular content, from `Oab_unit_all` (`native_decide`,
O·Ō=`rT13`) through `phi_rmul` + `phi_Ocab` + `phi_rT13`, then z·conj z=`normSq`. Plus planks:
`Ocab_canon_all` (`native_decide`), extractors `unit_at`/`conj_at`/`Oab_canon`/`Ocab_canon`
(decode the double-nested `.all`), `phi_rT13`, `phi_Ocab`. `equiangular` itself now 4 lines:
`obtain ⟨b',hb',hne,hbr⟩ := equiangular_bridge a b h; rw [hbr, norm_star, Complex.sq_norm,
overlap_normSq a.isLt hb' hne]; norm_num`. Lemma names in THIS Mathlib (v4.28.0):
`Complex.sq_norm : ‖z‖^2 = normSq z`; `norm_star`; `Complex.mul_conj : z*conj z = ↑normSq`;
`Complex.ofReal_inj`. (Complex.abs / Complex.`norm_eq_abs` / Complex.`sq_abs` are GONE.)

SOLE remaining sorry = `equiangular_bridge (a b : Fin 12) (h) : ∃ b', b'<12 ∧ ¬(a.val=0∧
b'=0) ∧ wh_inner 12 psi (D_ah 12 a b 0 psi) = star (phi (Oab a.val b'))`. Everything else
of the capstone is green. The pin is now SHORT: `evalKey` (key%16=covers, key/16%2=`iVal`=i,
key/32%2=c5Val real, key/64=u1Val) shows phi(zeta) = (real from key 0) + (½)i (key 16,
since `evalK16` g0C(½·one16)=½ and `iVal`=Complex.I) + (real from key 32) ⇒ Im Z = 1/2 EXACTLY;
|Z|=1 from phi(`zeta_pow12`): Z^12=1. So Z=±√3/2+i/2 ∈ {ω,ω⁵}. REMAINING HARD CORE = the
`D_ah`/`X_d`/`Z_d` iterate term-matching against Oab's foldl (needs `phi_zpow` : phi(zpow n)=Z^n by
induction; the b'=(m·b)%12 branch; Z^12=1 exponent collapse). Route: `d12_boundary_ctx`.md §4.
Defs: `D_ah`/`X_d`/`Z_d`/`omega_d`/`wh_inner` in `SIC_POVM_Stark.lean`; zeta/zpow/`rT13`/Oab in
ExistenceRing + Embedding. NEXT: prove `phi_zpow` + Z-pin as green sub-lemmas, then the core.

**CONT 2026-07-04 — CAMPAIGN COMPLETE (p4rakernel 488e22b): `crystal_forces_d12_sic` IS A
THEOREM.** The bridge block (written after 666bafc, banked only by daemon snapshots, never
compiled) implemented the §4 route (`phi_zpow`, `phi_zeta_pin` via Im Z=1/2, X/`Z_iterate`,
`D_ah_closed`, `cw_congr`, `phi_OabTerm`) but had 4 transcription defects; I fixed all 4:
(1)+(2) two rw chains (hrzb in `phi_OabTerm` + its main goal) ended on definitional goals —
psi k := phi (`rZ` k.val), and rw's auto-rfl fails at reducible transparency; explicit
`exact rfl` closes both. (3) The ← Fin.`sum_univ_eq_sum_range` rewrite carried a
parenthesis-broken explicit lambda (parser swallowed the `12` into the body); replaced the
lambda with `_` — rw unifies the Miller pattern fine. (4) hpsi rewrote the psi-INDEX
(k+a*11)%12 → (k+12-a)%12 but left the ω-EXPONENT behind, so the later rw [hphase] could
never match; inserted hjk into the chain AFTER hpsi (safe there: the only remaining
occurrence is in the non-dependent exponent; before hpsi it sits under Fin.mk where rw
dies on motive errors — that is WHY hpsi exists). Module green, then FULL LIB green (lake
exit 0 captured via PIPESTATUS, oleans strictly newer than sources). AXIOM AUDIT (#print
axioms): `crystal_forces_d12_sic` + `d12_sic_exists` depend on exactly [propext,
Classical.choice, Quot.sound, Lean.`ofReduceBool`, Lean.`trustCompiler`] — no project axioms,
no Stark shadow, no circularity. AXIOM RETIRED: `SIC_POVM_Functor.lean` now imports
`SIC_D12_Embedding` (acyclic: Embedding imports only ExistenceRing + Stark) and restates
`crystal_forces_d12_sic` as a theorem delegating to SIC.D12.Embedding.`crystal_forces_d12_sic`.
Nothing remains of the d=12 SIC existence campaign — see [[project_d12_sic_build]].
