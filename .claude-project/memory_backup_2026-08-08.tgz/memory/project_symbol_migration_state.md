---
name: project-symbol-migration-state
description: "The one canonical alphabet: the twelve axis marks, their values, and what is deliberately still open"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5aca9f10-ed8b-4df7-ac20-436ed8ecf282
  modified: 2026-08-03T16:26:06.895Z
---

IMASM and the twelve primitives are on ONE alphabet. All twelve axes migrated
2026-08-03; residue across the four repos is a stored shell-permission string
and one stale egg-info file whose source is clean. Frozen branches from before
the purge: `frozen/pre-compat-purge-2026-08-03` in all four repos.

## The alphabet

    ⊢ VINIT/Dimensionality   ⊣ TANCH/Topology     > AFWD/Relational
    < AREV/Polarity          ⋈ CLINK/Fidelity     ⊤ EVALT/Kinetics
    ∈ FSPLIT/Granularity     ∋ FFUSE/Grammar      ⊙ IMSCRIB/Criticality
    ⊥ EVALF/Chirality        ⊞ EVALI/Stoichiometry  ◻ IFIX/Protection

Opcode↔mark authority is `imasm_core/src/imasm16_3.rs` `Token16_3::glyph()`.
Value order per axis is the `Core.lean` ctor order. Retired IMASM marks
(= + × ¬ ◇ ●) parse as aliases and nothing prints them.

## Three letters lettered two axes each

This is the thing that makes a blanket sweep wrong, and it will bite again on
any future rename.

- **Φ** was Polarity in the glyph alphabet (slot 4, beside ƒ and Ç) and
  Criticality in the Lean/LaTeX alphabet (slot 9, where Parity is P). ~11k
  Polarity against 184 Criticality.
- **Γ** was Granularity and also Grammar (Γ_seq, Γ_AND, Γ_∧, Γ_BROAD), *and*
  the gamma function.
- **Σ** and **Ω** are summation and the loop space before they are ours.

Discriminate per occurrence, never per file: the value bound to the mark, the
slot between known neighbours, a gloss in words, or a bare quoted single
character. ⊙ is a weak discriminator because ⊙ is also its own value.

## Deliberately open, not missed

- `∋_SELECTIVE` / `∋_SPECIFIC` — coupling tiers, not operators. Only BROAD is
  both. What they should become is a domain call.
- `⊙_c_intermediate` — appears once in a path; no value means "intermediate".
- `Φ_complexity`, `<_join_NP` and siblings — entry NAMES, not value spellings.
- `Stoichiometry.dead` (𐑛) and `Criticality.egg` (𐑧) still stand; deleting them
  would depopulate addresses. Violations baseline 29. Two entries hold 𐑯 in ◻
  and refuse to load.
- 13 entries were renamed (names that began with a retired mark). Addresses did
  not move; no stale references remain.

## Verification battery

1. `python3 mOMonadOS/tools/gen_catalog_subset.py` — ≥8,017
2. `imscribing_grammar/sync_catalog.sh --check` — all 8 consumers match
3. `imscribe join loki_laufeyjarson odinn_allfather` — joins 𐑻, meets 𐑮
4. `cd mOMonadOS && make ordinals` — boots on the host, gates on
   `ALL 44 VALUES MATCH Lean canonical`. Verified load-bearing: perturb one
   ordinal and the kernel refuses to boot and the target exits non-zero.
   The hosted build was never rotted. `.cargo/config.toml` pins the bare target
   globally, so `--features hosted` alone still compiles no_std and throws
   thousands of missing-prelude errors. Name the host target: `make hosted`.
5. `2m3iosis/ask --imasm cycle tuple=⟨…⟩` — 12 of 12 recovered
6. Address safety: `tools/numerical_encode.encode_crystal_address`, diff HEAD's
   catalog against the working tree by entry name. Zero moved, every pass.

Script for the battery: see [[feedback_use_command_grep_for_census]].

## Census with `command grep`

Bare `grep` here is a wrapper injecting `--ignore-files`, so it honours
.gitignore and silently hid a live catalog copy from every earlier worklist.
Use `command grep -rI` with `--exclude-dir=.venv --exclude-dir=target`, and keep
`sync_catalog.sh --check` as the backstop.

## What the migration exposed and fixed

Mahalanobis distance had been dead for the entire catalog: the dict was keyed by
short ASCII names against an ORDINALS that had moved to the marks, so nothing
resolved and it returned None without raising. `_PRIMITIVES_FALLBACK` and
`imscrbgrmr/migration.py` are deleted. `_PROT_ORD` held `ah` twice so one
protection gap read as two steps. `OPENROUTEŘ_API_KEY` and the chemistry `K_d`,
`K_a` had been eaten by earlier sweeps. Six pieces of ordinary mathematics eaten
by these passes were restored after checking each against the pre-migration
text: Ω_DM, Ω_E, Γ_L, Γ_g, Ω_r, Φ_B.
