---
name: feedback-no-max-tokens
description: "Never add max_tokens or any truncation ceiling to LLM calls for proof generation, design tasks, or ob3ect pipeline"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 8df665d8-6ed8-4366-8ff8-6dbf54458380
---

Never include `max_tokens`, `max_completion_tokens`, or any token ceiling in LLM API calls for proof generation, proof translation, or ob3ect design tasks.

**Why:** User explicitly reacted negatively when `max_tokens=2048` appeared in `translator.py`. The model must use its full context budget for these tasks — cutting off a proof mid-way is worse than letting it run long.

**How to apply:** In `proof_path/translator.py`, `ob3ect/auto.py`, and any other LLM call used for proof/design work — omit `max_tokens` entirely. The only legitimate `[:8]` in the ob3ect pipeline enforces the fixed 8-step bootstrap sequence (not truncation). Distinguish truncation (bad) from structural length limits (fine).
