---
name: reference_bashrc_tools
description: "Complete .bashrc alias/function map for all projects — navigation, tool invocations, env vars, fzf menus"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 624e9212-31cd-4476-b603-3300f27907c5
  modified: 2026-08-04T16:29:29.749Z
---

## Environment variables
- `IG_PROVIDER=openrouter`, `IG_MODEL=deepseek/deepseek-v4-pro` — default LLM backend
- `SZ_SYNFIN=~/synfin`, `SZ_SYNFIN_VENV=~/synfin/.venv`

## Navigation shortcuts
| alias | destination |
|-------|-------------|
| `ig`  | ~/`imscribing_grammar` |
| `mA`  | ~/MillenniumAnkh |
| `ex`  | ~/`exOS` |
| `ob`  | ~/ob3ect |
| `pr`  | ~/priests-engine |
| `cet` | ~/cetaceanspeak |
| `gn`  | ~/`gene_imscriber` |
| `sf`  | ~/synfin |
| `para`| ~/priests-engine |
| `rb`  | ~/red-`hot_rebis` |

## red-`hot_rebis` (rb-*)
| alias | script |
|-------|--------|
| `rb-rebis` | `rebis.py` |
| `rb-clink` | `rebis.py` clink |
| `rb-clink-report` | `rebis.py` clink report |
| `rb-clink-list` | `rebis.py` clink list |
| `rb-clink-bridges` | `rebis.py` clink bridges |
| `rb-pipeline` | `rebis.py` pipeline |
| `rb-ground-up` | `rebis.py` pipeline ground-up |
| `rb-actionable` | `rebis.py` pipeline actionable --organism mammal |
| `rb-bridges` | `rebis.py` pipeline bridges |
| `rb-bio` | `biology/biology_sim.py` |
| `rb-telomere` | `biology/ouroboric_telomere.py` |
| `rb-mat` | `materials/materials_sim.py` |
| `rb-metamat` | `materials/critical_metamaterial.py` |
| `rb-rectifier` | `materials/thermal_rectifier.py` |
| `rb-pill` | `therapeutics/ouroboric_pill_sim.py` |
| `rb-qbio` | `therapeutics/quantum_biologic_prototype.py` |
| `rb-antidote` | `therapeutics/universal_antidote_library.py` |
| `rb-chemo` | `therapeutics/frobenius_chemotherapeutic.py` |
| `rb-neuro` | `therapeutics/neurotrophic_factor.py` |
| `rb-serpent` | `serpentrod/protein_v5.py` |
| `rb-serpent-predict` | `serpentrod/stratified_predictor.py` |
| `rb-gene` | `gene_imscriber/engine.py` |
| `rb-gene-design` | `clink/datasets/gene_designer.py` |
| `rb-auto` | `pipeline/auto_imscriber.py` |
| `rb-imscribe-agent` | `pipeline/imscribe_agent.py` |

## Git workflow
- `gitty` = `git add . && git commit -F commit.txt && git push`

## Shell functions
- `igpdf <file.md>` — pandoc→pdf via xelatex + `hebrew_inject`.lua + `IG_primitives`.lua
- `vmenu` (`venva_menu`) — fzf over ~/.`directory_history`, cd + activate venv
- `amenu` (`alias_menu`) — fzf over all defined aliases, execute selected
- `rmzone [-n]` — delete (or dry-run) Windows Zone.Identifier files recursively
- `cd` — overridden to append cwd to ~/.`directory_history` (max 50 entries)

## `imscribing_grammar` (ig-*)
| alias | script |
|-------|--------|
| `imscribe` | console script from `pyproject.toml` |
| `ig-inquiry` | `IG_inquiry.py` |
| `ig-crystal` | `crystal_enumeration.py` |
| `ig-crystal-viz` | `crystal_viz.py` |
| `ig-esoteric` | `esoteric_librarian.py` |
| `ig-latex` | `IG_latex.py` |
| `ig-frob` | `frobenius_mzi_sim.py` |
| `ig-lambda` | `lambda_engine.py` |
| `ig-zfct` | `zfct_navigator.py` |
| `ig-zfct-manip` | `zfct_manipulator.py` |
| `ig-pct` | `zfct_para.py` |
| `ig-manuscript` | `manuscript_eval.py` |
| `ig-seq` | `seqcom.py` |
| `ig-audio` | `imscribeaudio.py` |
| `ig-video` | `imscribevideo.py` |
| `ig-sounds` | `sounds.py` |
| `ig-vocal` | `generate_vocal_expressions.py` |
| `ig-lean4` | `lean4_descent_object.py` |
| `ig-transport` | `theorem_transport/auto_theorem_transport.py` |
| `ig-agent` | `agents/true_agentic_agent.py` |
| `ig-agents` | `agents/agents_cli.py` |
| `ig-generator` | `agents/imscribe_generator_agent.py` |
| `ig-paraconsistent` | `agents/paraconsistent.py` |
| `ig-retro` | `agents/retrodesign_agent.py` |

## Navigators (ig-*-nav)
`ig-crystal-nav`, `ig-domain`, `ig-zfc-nav`, `ig-riemann`, `ig-thurston`, `ig-langlands`, `ig-qft`, `ig-hott`, `ig-quiver`

## Genetics
`ig-genetics` → `genetic_engine/genetic_engine.py`; `ig-gen-box` → `genetics_ag_box.py`

## Space/astro search
`ig-space` (`pipeline.py`), `ig-epn`, `ig-frb`, `ig-gaia`

## Whale/cetacean
`ig-whale`, `ig-whale-audio` (in `imscribing_grammar`); also `whale`, `whale-audio` (cetaceanspeak repo)

## Manuscript engines (undeciphered texts)
- Voynich: `voynich-compile/run/graph/sections` (~/voynich-engine/)
- Rohonc: `rohonc-compile/run/graph/sections` (~/rohonc-engine/)
- Linear A: `la-compile/run/graph/sections` (~/`linear_a_engine`/)
- Unified REPL: `ms-eval` (`manuscript_eval.py`); `zfct-nav`, `ms-zfct`

## MillenniumAnkh (ankh-*)
`ankh-build`, `ankh-build-core/agent/cons/rh/opn`, `ankh-check`, `ankh-clean`
`ankh-sorry` — count sorries; `ankh-sorry-list` — list them
`ankh-pipeline`, `ankh-pdf`

## `exOS` (exos-*)
`exos-build` (`build_bootimage.sh`), `exos-run`, `exos-serial`, `exos-clean`, `exos-check`

## ob3ect (ob3ect-*)
`ob3ect-gen` (`auto.py`), `ob3ect-smoke`, `ob3ect-demo`
Bootstrap: `ob3ect-crystal`, `ob3ect-paradox`, `ob3ect-tetractys`
`ob3ect-lean` → lake build

## priests-engine (para-*)
`para-repl`, `para-loop`, `para-vm`, `para-shor`, `para-rh`, `para-ym`
`para-align`, `para-category`, `para-temporal`, `para-multiagent`, `para-nreg`, `para-wasm`

## p4rakernel (p4rk-*)
Nav: `p4rk` → ~/p4rakernel
Python (PYTHONPATH=~/p4rakernel): `p4rk-genetics` (`genetic_code.py` demo), `p4rk-verify` (kernel verifications), `p4rk-belnap` (B₄ self-test), `p4rk-promotions` (`compute_promotions.py`)
Lean (p4ramill/): `p4rk-build`, `p4rk-build-core/kernel/genetics/shor/rh/ym`, `p4rk-check`, `p4rk-clean`
`p4rk-sorry` — count sorries; `p4rk-sorry-list` — list them

## `gene_imscriber` (gene-*)
`gene-cli`, `gene-demo`, `gene-analyze/compile/guide/verify/chimera/stratum/test`

## synfin (sf-*)
`sf-cli`, `sf-asset-list/show/cons/ouro`
`sf-dist/meet/join/tensor` (algebra comparisons)
`sf-compose/decompose/path` (portfolio)
`sf-anomaly`, `sf-regime`, `sf-infer`
`sf-fetch`, `sf-download`, `sf-backtest`, `sf-micro`, `sf-micro-coupled`
`sf-domain`, `sf-domain-corr/div`, `sf-coupled-real`
`sf-taguchi`, `sf-taguchi-corr/effects/pp`
`sf-trade` (LIVE bot), `sf-paper` (paper trader)
`sf-arb`, `sf-compare-tf`, `sf-rank`
`sf-test`, `sf-test-algebra/backtester/cons/domains/inference/primitives/taguchi`
`sf-lean`, `sf-lean-build`, `sf-lean-check`

## Zenodo (zenodo-*)
`zenodo` (sandbox default), `zenodo-live`, `zenodo-draft`, `zenodo-live-draft`
`zenodo-list`, `zenodo-list-live`
All route to `scripts/zenodo_upload.py` via `uv run`

## ⊙perator specialists (`agents/specialists/*_operator.py`)
One-shot: `mathop`, `editop`, `chemop`, `quantumop`, `recop` (Rec⊙rder),
`hetop` (Heter⊙d⊙x). Interactive: same names + `i`.
Single letters cd + activate venv + launch interactive:
`m` math, `c` chembio, `e` editorial, `q` quantum, `r` rec⊙rder, `h` heter⊙d⊙x;
`1` is the cd + venv step alone.
See [[project_constellation_agents]].

## Cross-project
`build-all` = `ankh-build && ob3ect-lean`
`popdoc` = latextiler compile $`CURRENT_DOC` (xelatex)
`droxx` = latextiler compile $DROXX (xelatex)
`ur` = `uv run`; `uvpee` = `uv pip install -e .`
`denva` = `source .venv/bin/activate`; `venva` = `source venv/bin/activate`
`vita-probe` = the seed-atlas binary (`vae_vita`/`vita_native`); `vita-atlas` = full 2000-seed 3-temp spidered run
