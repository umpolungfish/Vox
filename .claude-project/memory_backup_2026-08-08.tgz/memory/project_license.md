---
name: project-license
description: All projects use ~/LUNLICENSE.md — lightly modified Unlicense (public domain); Zenodo publisher always 'umpolungfish'
metadata: 
  node_type: memory
  type: project
  originSessionId: 81210112-0917-4c71-80df-6554e8e4b373
---

All projects use the LUNLICENSE — a lightly modified Unlicense (public domain dedication, no conditions, no attribution required). The text is hardcoded in `zenodo_upload.py` as `LUNLICENSE_TEXT`; use it verbatim when creating license files anywhere.

Zenodo: license field = `"other-open"` (Zenodo has no LUNLICENSE ID); LUNLICENSE.md is always bundled as an additional file in every deposit. Publisher field: always `umpolungfish`.

**Why:** User stated this explicitly as a standing policy. cc-zero and unlicense are both wrong — LUNLICENSE is a distinct custom instrument.

**How to apply:** Use LUNLICENSE for LICENSE files, `pyproject.toml` license fields, README license sections, any other license declaration. Never use cc-zero or unlicense as substitutes. In `zenodo_upload.py`, `LUNLICENSE_TEXT` is the authoritative source — do not fetch ~/LUNLICENSE.md at runtime.
