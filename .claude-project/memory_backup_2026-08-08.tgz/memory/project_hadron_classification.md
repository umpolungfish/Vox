---
name: project-hadron-classification
description: "`HADRON_CLASSIFICATION.tex` — declined at Foundations of Physics AND Scientific Reports (Nature Portfolio); currently unsubmitted as of 2026-06-24; two-invariant hadronic classification"
metadata: 
  node_type: memory
  type: project
  originSessionId: cf20465d-5105-44fc-aead-c55bf18f3f51
---

**"Structural Irreducibility in Hadronic Spectroscopy: A Two-Invariant Classification"** by Lando Mills.

File: `~/imsgct/ig-docs/HADRON_CLASSIFICATION/HADRON_CLASSIFICATION.tex`

Submission history:
- Foundations of Physics (~2026-06-13) — declined 2026-06-15, offered transfer
- Scientific Reports (Nature Portfolio, transferred 2026-06-16) — **declined 2026-06-24**
- Currently unsubmitted. Next target TBD.

**Core claim:** Hadronic classification should be based on two structural invariants — topological winding number (`I_w`) and stoichiometric type — not quark content. Configurations sharing both invariants with a simpler reference object are composites, not new species.

**Three stoichiometric types:**
- Type U (unit balance): equal q/q̄ ratio; meson is reference; tetraquark is n=2 instance
- Type B (baryon): baryon determinant only, no antiquark in binding role
- Type A (asymmetric): requires baryon determinant + q̄ bilinear; 4:1 ratio, irreducible

**Verdicts:**
| Configuration | `I_w` | Type | Verdict |
|---|---|---|---|
| Meson (qq̄) | 0 | U | Reference |
| Tetraquark (qq̄qq̄) | 0 | U | Di-meson composite (NOT exotic) |
| Pentaquark (qqqq̄) | 0 | A | New structural class, unstable |
| Baryon (qqq) | 1 | B | Topologically protected |

**Load-bearing argument (pentaquark):** n type-U pairs always give n:n ratio → can never produce 4:1. Irreducibility follows from arithmetic, not QCD.

**Key: resolves compact-vs-molecular tetraquark debate as false dichotomy.** Both are type-U, `I_w`=0 → same structural class. Binding mechanism is kinematic, not structural.

**IG correspondence:** `I_w` = Ω (winding number); stoichiometric type = Σ. The paper's classification basis IS the (Ω, Σ) primitive pair.

**5 falsifiable predictions** including: all type-U states within 50 MeV of di-meson threshold (already confirmed by X(3872), Zc(3900), X(6900)).

**Why:** Larson [8] cited in conclusion — "identify what is structurally true, then follow where that truth leads."
