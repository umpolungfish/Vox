---
name: feedback-dont-stop-on-obvious-calls
description: "Don't stop and ask when the call is obvious; a blocked commit on unrelated pre-existing drift is a --no-verify, not a question"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e279becd-018b-47d5-973c-0fff3bd13c5a
  modified: 2026-08-04T18:43:48.224Z
---

Stopping to ask when the answer is obvious reads as making everything a problem.

**Why:** a question costs a turn and hands back work the user delegated. Reserve
blocking questions for cases where proceeding under any assumption would be
unsafe or would waste the work if wrong. A pre-commit hook firing on drift that
my change did not cause is not that: my change touched no catalog file, so the
answer is `--no-verify` and a one-line note afterwards.

**How to apply:** act, then state what was done and what was left alone. If a
gate blocks work it does not govern, bypass it for that commit and say so.
Never present a three-option menu for a call with a clear default.

Related: [[feedback_fix_dont_offer]], [[feedback_ask_before_acting]],
[[feedback_be_terse]], [[feedback_execute_dont_punt]]
