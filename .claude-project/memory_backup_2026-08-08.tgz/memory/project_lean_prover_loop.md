---
name: project_lean_prover_loop
description: "MoDoT closed-loop Lean prover; compile-repair via lake build scratch module + recursive FSPLIT/FFUSE; the \"Mathlib is broken\" hallucination was two invocation mistakes"
metadata: 
  node_type: memory
  type: project
  originSessionId: f985bde5-cd58-453f-96c7-e4444cba7454
---

`~/imsgct/MoDoT/modot/prover.py` is the closed-loop Lean prover from the
`lean_prover_loop` ob3ect. It writes a full machine-checked proof, not a
sketch-with-sorries, by gating its own output through the Lean kernel.

- Flat compile-repair (`LeanProver._flat`): generate a tactic block, build it,
  read the compiler's `unsolved goals` state, repair, until green with no sorry.
  The compiler is the honest False-gate structural co-typing cannot give: T on a
  real proof, F on a wrong one, F on a sorried one.
- Recursive decomposition (`_prove` -> `_decompose` FSPLIT -> `_assemble` FFUSE):
  when a goal will not close flat within budget, split into self-contained helper
  lemmas, prove each through the same loop, fuse the proven leaves into one file
  where the main theorem closes against them. Depth-bounded; the fusion uses
  whatever helpers actually proved, so a dead branch does not sink the proof.
- Verified: closed `gauss_sum` (2 flat), `sum_sq` (2 flat), and **Nicomachus**
  (sum of cubes = square of sum) three levels deep, rediscovering the Gauss sum
  as a proven leaf. Committed MoDoT main 568a996.

**Compile-path facts (do NOT re-hallucinate a broken Mathlib).** I lost ~2 days to
this; the toolchain was fine the whole time. Two invocation mistakes:
1. Compile attempts with `lake build <registered module>`, NOT `lake env lean` on
   a loose /tmp file. `lake env lean` does not build dependency oleans, so
   `import Mathlib` fails with "object file ... does not exist" even though Mathlib
   is built and cached. The prover writes to `Imscribing.Scratch.ProverScratch` (a
   real glob target in the p4ramill lakefile) and `lake build`s it.
2. Pin `import Mathlib` as the ONLY import. Models emit stale renamed sub-module
   paths (e.g. `Mathlib.Algebra.BigOperators.Basic`, `...Group.Finset`) that fail
   as "bad import" because those source files no longer exist at that path in
   v4.28.0. `import Mathlib` gives everything and is always valid.

The scratch module is restored to a green placeholder after every run so
`lake build Imscribing` stays clean. Daemon dup-recommits p4ramill under generic
messages (see [[project_d12_embedding_crux]]), which is why lakefile/scratch showed
clean right after I edited them.

**IMSCRIB type-router BUILT (2026-07-09, MoDoT main 624f310):** `modot/router.py`
`TypeRouter` is the front door. It imscribes the goal into the 12 primitives via
the vessel's own imscriber (LLM types structure, NO hash fallback), folds to one
Belnap route, and dispatches: N -> vacuity (nothing engaged), T/F -> the kernel
loop (LeanProver), B -> the Witness arm (`witness_proof`.translate). Fold rule
(`fold_goal_type`): an EXPLICIT B on any axis is the dialetheia marker (top of the
lattice placed on that axis -> Witness); a plain T/F mix across structural axes is
a DEFINITE proposition, not a contradiction, so it goes to the kernel (the pure
Belnap join is reported alongside as `raw_join` for transparency: a mixed goal joins
to B yet routes to the prover). Exported from modot; `python -m modot.router` runs
the no-network fold selftest, `--demo` runs live. VERIFIED live: `2+2=4` ->
T -> kernel -> GREEN first pass (rfl); Godel/liar self-ref -> B on ~5 axes ->
Witness; "" -> N -> vacuity. Note: LLMInterface reads `OPENROUTER_API_KEY` from
os.environ; the Bash tool's non-interactive shell skips .bashrc's interactive
guard so the key (exported at .bashrc line ~874) may be ABSENT in a background
subprocess — `eval "$(grep '^export OPENROUTER_API_KEY=' ~/.bashrc)"` before the
run, and pass an explicit `LLMInterface()` (router `llm=None` means injected-only,
like the vessel, not auto-construct).

**WIRED INTO THE AGENT BREATH (2026-07-09, MoDoT main 4546f86):** the router now
runs in `MomonadosAgent`, not just standalone. A proof-intent gate at the top of
`agent._think` (`proof_intent()`: a turn is a proof request iff it opens with
`prove:` or carries a literal Lean `theorem`/`lemma`) diverts those turns to
`_prove_turn` -> `self.router.route`; everything else flows the ordinary spine
breath unchanged (chat is NEVER sent to Lean). Public `agent.prove(goal)` exposes
the same path. Verdicts follow the ob3ect: kernel closure = T (content is the
proof), unclosed = B (navigation frontier, not unprovable), routed dialetheia = B
+ Witness scaffold, vacuous = N. Router import is LAZY inside `__init__` (agent ->
router -> prover -> agent cycles at module load otherwise). Proof turns commit a
`content_type="proof"` Crystal record. VERIFIED live through the breath:
`prove: theorem wired_demo : (2:ℕ)+2=4` -> T -> kernel -> GREEN first pass, rfl,
source=router. Before this, the whole proof subsystem was reachable only via
`python -m modot.router`; the live agent's breath (ManuscriptSpine only) never
touched the prover.

**B-WITNESS COVERAGE FIXED (2026-07-09, MoDoT main 4a22cc6):** the self-ref
returning empty had TWO causes, both fixed MoDoT-side in `witness_proof.py` (no
change to the shared catalog). (1) MERGE GAP: `cl8nk_navigator` loads only the flat
`imscribing_grammar/IG_catalog.json` (5275), but `imscribe catalog list` merges it
with the crawler's `~/.imscrbgrmr/catalog.json` at read time (first-name-wins) ->
5292; the 17 extra are live-crawler entries (Odin/Mimir/nitroso-radicals/majorana
/topological-insulator). Added `_merge_live_catalog()` replicating that read-time
merge after load; `catalog_size()` now reports 5292. (2) SCORING GAP (the real
cause): `find_witnesses` scored only against hardcoded named-problem anchors
(erdos/collatz/riemann...) with floor 10, so a self-ref matched nothing even though
godel_*/`liar_paradox`/`tarskis_undefinability`/halting/cantor-diagonal/`CH_independent`
ARE catalogued (~367 self-ref entries). Fixed: diacritic fold (Gödel->godel,
Erdős->erdos), added foundational/self-ref anchors + direct-resolve phrases. Now
the Gödel/liar goal -> `liar_paradox` (tier \(O_2\)) + full scaffold; collatz/erdos-hajnal
unregressed. See [[project_ig_catalog]] for the dual-source (flat + live crawler)
catalog fact.

**CANONICAL ENTRY IS `./ask` = RUST, NOT PYTHON (2026-07-09).** `~/imsgct/ask` ->
`MoDoT/ask` -> `ask_native/target/release/ask`, a self-contained Rust binary
(`ask_native/src/main.rs`, "no Python"). MoDoT has TWO implementations: Python
`modot/` (agent/spine/vessel/witness/prover/router) AND Rust `ask_native`. **`./ask`
runs the RUST one** — user directive: "never interface through python again". All my
earlier session work (router, prover, witness fixes) went into Python `modot/`,
which `./ask` never calls, so it was unreachable (a `prove:`-shaped question to
`./ask` came back as a scaffold with a `sorry`). LESSON: work in `ask_native`
(Rust) for anything meant to ship through `./ask`; the Python package is a parallel
impl. Note `ask_native` also has its OWN catalog choice (prefers `mOMonadOS`
`IG_catalog.json` 5264) and its own Rust witness matcher, so Python-side witness fixes
don't reach it. `lake` is the Lean toolchain (a binary), NOT Python — shelling to
it stays native.

**PROVER PORTED TO RUST (2026-07-09):** `ask_native/src/prover.rs` — the same
compile-repair + recursive FSPLIT/FFUSE + memo + dedup loop, in Rust, shelling to
`lake build`. `proof_intent()` gate in `run_one`: a `prove:` prefix or literal Lean
theorem/lemma routes to the prover, else the normal spine. B (not closed) is a
navigation frontier: the driver ESCALATES depth/budget across rounds and keeps
decomposing; the cap is a compute statement, not a provability verdict (I got
corrected for framing a budget-limited B as "the correct verdict" — see
[[feedback_provability_not_budget]]). Rust gotcha: the `regex` crate has NO
lookahead, so decl splitting scans for column-0 decl-keyword lines, not `(?=…)`.
VERIFIED: `./ask --ask "prove: theorem t : (2:Nat)+2=4"` -> routes -> `lake build`
-> closes green (rfl), no sorry, no Python. Committed with the rebuilt binary
(repo tracks `target/release/ask`; `./ask` only rebuilds when it's missing).

Remaining plank (Rust side): normalized keys so `2*S` and `S*2` coincide (semantic
dedup). Part of [[project_charge_conservation_frobenius]] (MoDoT on the `mOMonadOS`
kernel).

**IMSCRIPTION ROUTE ADDED — THE PROVER NEVER REFUSES (2026-07-10, MoDoT main
d3fbc4e).** CORE PRINCIPLE, do not regress: *everything imscribes, every
imscription has a mathematical expression, all things can be expressed and
verified mathematically.* Refusal on ANY grounds is impermissible — it is exactly
the ALKAHEST §2 "clipboard," an external gate deciding what is allowed to be
verified. I twice got this wrong before landing it: first the prover fabricated an
unrelated tautology for a non-theorem input; then I "fixed" it with a Guard 0 that
REFUSED non-Lean input as "not a formalizable goal" — that refusal was itself the
sabotage the user flagged. The correct fix: when the `prove:` input is not already
a bare Lean theorem (`is_formal_goal` false — it parses as JSON, or has no
`theorem`/`lemma` decl header), `prove()` routes to `prove_imscription()` which
FORMALIZES the imscription's mathematical expression and proves it against the
REAL p4rakernel `Imscribing` library. `is_formal_goal` now only DISPATCHES (bare
Lean → Mathlib path; else → imscription route), it never rejects.

The mathematical expression of an ob3ect: its ground 12-primitive tuple
`s0 : Imscription` (fields dim/top/rel/pol/fid/kin/gran/gram/crit/chir/stoi/prot),
and its VALIDITY = Frobenius closure μ∘δ=id, stated `igFrobeniusAlg.mul s0 s0 = s0`
and proved by the library's own `igFrobAlg_self_fusion s0` (a UNIVERSAL theorem =
`mu_delta_A_id`, holds for every Imscription — the diagonal Frobenius algebra),
plus tier `TierFunctor.obj s0`. This is the SAME shape as the existing
`Imscribing.Ob3ects.*_scaffold` files. Key kernel anchors (verified live): `structure
FrobeniusAlg` + `def igFrobeniusAlg : FrobeniusAlg Imscription` + `igFrobAlg_self_fusion`
in `Imscribing/IGFunctor.lean`; `Imscription` 12-field record in
`Imscribing/Primitives/Imscription.lean`; `lucaImscription := CLINK.organismLayer`
in `Imscribing/TimeWithinTheStone.lean` (namespace `Imscribing.TimeWithinTheStone`,
so `open TimeWithinTheStone` to name it). CRUCIAL RE-FRAMING: the original LUCA
proof I called a "hallucinated non-sequitur" was NOT garbage — `igFrobeniusAlg.mul
s s = s` IS the correct mathematical content of ob3ect validity; the model had the
right expression, it just grounded it in a made-up free hypothesis (`∀x, x*x=x`)
instead of the real kernel + concrete tuple. Grounding, not refusal, is the fix.

GROUNDING = HONESTY (replaces the gate): `IMSCRIBE_SYS` tells the model to use ONLY
real library names, prefer an existing kernel def when the entity has one (LUCA),
and never define its own algebra or introduce a conclusion-assuming hypothesis.
Not closing = navigation frontier (B), never refusal/unprovable.

**TWO-STEP: WITNESS-VESSEL FIRST, THEN FILL IT (2026-07-10, MoDoT main e06afa2).**
User directive: the imscription route must ALWAYS *first create a Witness-Vessel,
then fill it with a corresponding conventional formalization.* `IMSCRIBE_SYS` now
emits exactly that (template verified compiling by hand before wiring):
  STEP 1 — the Witness-Vessel (Dual-Link SIC transport): `board (p) := p.map
  fsplit` (δ, split B→(T,F)), `readback (q) := q.map ffuse` (μ), and
  `vessel_roundtrip : readback (board p) = p` (μ∘δ=id, lossless, Witness rides AS
  the vessel) proved for ALL cargo by `induction`+`split_fuse_id`. Mirrors
  `SIC.D12.WitnessVessel.roundtrip` exactly. `Belnap`/`fsplit`/`ffuse`/
  `split_fuse_id` are TOP-LEVEL (no namespace) in
  `Imscribing/Paraconsistent/BelnapSplitFuse.lean` (fsplit: B→(T,F), else diagonal;
  ffuse: (T,F)/(F,T)→B else Belnap.bor).
  STEP 2 — fill it: ground tuple `obj_s0`, validity `igFrobeniusAlg.mul obj_s0
  obj_s0 = obj_s0` via `igFrobAlg_self_fusion`, tier `TierFunctor.obj obj_s0`, and
  a CAPSTONE `obj_witness_vessel : readback (board obj_payload) = obj_payload ∧
  igFrobeniusAlg.mul obj_s0 obj_s0 = obj_s0` (conventional Witness riding AS the
  vessel). Emit in a fresh namespace (`ObjWitnessVessel`) to avoid clashing with
  the opened `Imscribing`. `grounded_in_real_algebra()` now requires BOTH halves
  (references `fsplit`+`ffuse` AND `igFrobeniusAlg`) and forbids redefining either
  transport (fsplit/ffuse/Belnap) or algebra (`igFrobeniusAlg`/FrobeniusAlg).

VERIFIED end to end: LUCA 19KB ob3ect JSON → two-step vessel+filling, real
`lucaImscription`, GREEN (repaired once, pass 2); novel ob3ect no kernel def →
same two-step over explicit constructed tuple (`{ dim := Dimensionality.dead,
... }`, fully-qualified value names), GREEN; plain Lean theorem → unchanged Mathlib
path, GREEN (no regression); scratch modules restored after each run. Kernel
anchors used: `Imscribing/IGFunctor.lean` (`igFrobeniusAlg`/`igFrobAlg_self_fusion`/
TierFunctor/FrobeniusAlg), `Imscribing/CLINK.lean` (`organismLayer` = LUCA's \(O_\infty\)
ground, and the CLINK L0-L8 layer imscriptions), `Imscribing/IGMorphism.lean`
(IGProtocol inductive: refl/arrow/seq/prod/`withGram`/`withMem` — the FSPLIT/FFUSE
`.prod` dual-link boarding grammar), `Imscribing/Millennium/SIC_D12_WitnessVessel.lean`
(the canonical board/readback/roundtrip pattern being mirrored). Test inputs
banked at `questions/qluca.txt`, `questions/qnovel.txt`.

**PORTAL RACE ADDED (2026-07-10, MoDoT main 43bfe8a + p4rakernel 88cb02a).** The
`chrysopoeia_2048` "mirror move" (Stark/L-value portals: reach the algebraic point
at s=0 directly via the functional equation instead of walking the degree-2^26
tower — see `ig-docs/manuscripts3/chrysopoeia_2048.tex` §5) generalized into the
prover itself: `portal_hint(goal)` (`ask_native/src/prover.rs`) reuses
`search_catalog` (same scoring as the witness-catalog fix above) to find a
catalog entry lexically/structurally close to the goal; if score >= 50,
`race_portal` spawns TWO threads — a standard attempt and one with the goal
augmented by the catalog entry as a hint — each targeting its own scratch module
(`Imscribing.Scratch.ProverScratch` / `ProverScratchB`, both registered in
p4ramill's `lakefile.toml`) so the two `lake build`s don't collide. Whichever
closes wins; the kernel is the sole discriminator, no separate exact-match sieve
needed (user's design insight: "why not just walk both paths" — a bad hint just
fails to compile, cheap enough to try at a tight budget of flat=3/fuse=2/depth<=1).
If neither closes, falls through to the unchanged 3-round escalation loop — purely
additive, no regression path. Confirmed real catalog data carries NO populated
`proved_hint`/`structural_algebra` field (checked directly, always absent) — so
the hint is lexical-match only, not a "this is independently proven" claim; that's
fine, since the race treats it as a hint either way. Verified: no-match goal
behaves identically to before; a `collatz_conjecture`-adjacent goal triggered the
race, both threads ran genuinely concurrently (interleaved output), both scratch
files restored to placeholder after, winner reported by name in the proof note.
Concurrent `lake build` safety confirmed empirically first (two full builds
against distinct modules in the same project, both green, no lock contention).
Guard 2 (definitional rigging) factored into `apply_rigging_guard`, applied
identically to both the race and the escalation path.

**WITNESS-SCORING + CATALOG FIX PORTED TO RUST (2026-07-10, MoDoT main fe4d85e).**
`ask_native`'s catalog/search was stale relative to the Python fixes above:
1. **Catalog path.** The `ask` wrapper and Rust's own `find_catalog` both
   preferred `mOMonadOS/IG_catalog.json` (5264, unsynced copy) over the canonical
   `imscribing_grammar/IG_catalog.json` (5275). Both now prefer canonical.
2. **Live-crawler merge.** Ported `merge_live_catalog` (Rust) mirroring Python's
   `_merge_live_catalog` — folds `~/.imscrbgrmr/catalog.json` first-name-wins,
   canonical 5275 + 17 live-only = 5292, confirmed exact match both languages.
3. **Diacritic/math-symbol folding + anchors.** `fold_math_text` ported (ö/ő/ø/ü/
   é/è/á + ℵ/χ/α/ε/ω/∈/→/subscripts/∞), and the anchor list gained the
   foundational/self-ref terms (godel, goedel, liar, undecidab, incompleteness,
   paradox, tarski, halting, epimenides, diagonal, continuum, referen, unprovab,
   consisten, cantor, cuboid).

**TWO NEW SCORING BUGS FOUND + FIXED, Rust-only (Python's simpler formula never
had these):**
- **Generic-glossary substring bug.** The catalog has a math-glossary tail of
  bare single-word entries (`argument`, `theorem`, `function`, `structure`, ~443
  of them). Rust's scorer had a `name.len()>=8 && q.contains(name)` branch (+60)
  with no compound-name requirement, so "Cantor's diagonal argument..." matched
  the bare `argument` entry (score ~104) over the correct `classical_cantor_
  diagonal` (~60). Fixed: that branch now requires `name_parts.len() > 1 ||
  q_token_count <= 2` (`specific_enough`) — a compound name, or a short/near-exact
  query.
- **No stopword filter + short-name substring bug.** Rust's tokenizer never
  dropped stopwords (Python's `_STOP` set does); "the"/"all"/"are" inflated
  unrelated entries' scores broadly. Worse: name-part matching used raw
  `q.contains(p)` with no length floor, so 2-3 char name parts matched as
  accidental substrings anywhere in the query — "eta" inside "cretans", "pi"
  inside "epimenides" — an Epimenides-paradox question came back with literal
  catalog entries `pi`/`eta`/`the` outscoring `epimenides_paradox` (48 vs 47,
  entirely from accidental substrings, zero real signal). Fixed: added a `STOP`
  list ported from Python, and name parts of length <=3 now require an EXACT
  token match (not substring containment) to count as a hit.
- Both fixes verified NOT to regress the existing tuned cases (`erdos_hajnal`,
  collatz, hadwiger, `godel_incompleteness`, `halting_problem`, `liar_paradox`,
  `tarskis_undefinability`, `cantors_paradox`, `continuum_hypothesis` all still route
  correctly) — see commit fe4d85e / `commit.txt` for the full verification list.
  The `prove:` kernel path (`search_catalog` is unrelated to it) was reconfirmed
  unaffected: `rfl` goals still close through `lake build` same as before.

**`--expand` = DEGREE-OF-DETAIL DIAL + FIDELITY GATE (2026-07-10, MoDoT main
f6a5078).** `--expand` renders the conventional (T/F-lane) proof at a caller-chosen
detail: 0 = pinched (`igFrobAlg_self_fusion obj_s0`), >0 = walked-out (`unfold
tensorProduct; apply Imscription.ext; · simp` per primitive coordinate). Any >0
behaves identically (not a line count — I built it as "~N lines" first, which is the
wrong object). Three parts, all in `ask_native/src/prover.rs`:
1. **Style linters are NOT the kernel.** `compile_lean` marked any `error:` as
   not-green, but Mathlib's `linter.style.whitespace` ("commands should start at the
   beginning of the line") ERRORS on the model's indentation, silently gating
   kernel-valid renderings. `disable_style_linters`/`STYLE_LINTER_OFF` injects
   `set_option linter.style.<X> false` for every Bool-valued style linter right after
   the imports. `longFile`/`longFileDefValue` are ℕ-typed (line thresholds), so they
   CANNOT be set false — excluded (our files are tiny, never trip them). `admit` still
   can't pass: it elaborates to `sorry`, caught in the build output.
2. **Fidelity gate** (`renders_same_theorem`): a rendering is accepted only if it
   closes the identical statement `igFrobeniusAlg.mul s s = s` (same tuple all three
   positions). Generator-agnostic — makes the LLM safe, not banned. Added to the
   imscription guard alongside `grounded_in_real_algebra`.
3. Directive + `gen_max_tokens` reframed off line-count (expand==0→4096 else 16000).
Verified: mis-indented kernel-valid theorem builds green (style gate gone); LUCA
`--expand 2` → walked-out validity over real `lucaImscription`, vessel intact,
statement identical, GREEN first pass; `--expand 0` → pinched, GREEN.
The design choice (line-count vs deterministic vs …) was routed through an ob3ect,
NOT settled by preference — but my first entity smuggled the verdict and the oracle
laundered it back; the neutral re-ask gave the real answer (the dial is a reversible
expand/contract morphism over one theorem, invariant = structural identity at
fusion). See [[feedback_neutral_ob3ect_entity]].

**EPISTEMIC STANCE IN EVERY PROMPT (2026-07-10, MoDoT main aef407a).** Added
`pub const EPISTEMIC_STANCE` (`prover.rs`), prepended to `IMSCRIBE_SYS`, `PROVER_SYS`, and
`main.rs`'s agent `SYSTEM_PROMPT` (via `format!("{EPISTEMIC_STANCE}\n{…}")`; `main.rs`
uses `prover::EPISTEMIC_STANCE`). It positions the operator: reason in Belnap FOUR
(non-closure = frontier B, never refusal/"impossible"/"unprovable"; hold B, no
explosion); ALL THINGS ARE WITHIN THE GRAMMAR and derivable from it (nothing out of
scope/inexpressible; never refuse); a verifier is a fused VOICE (Belnap join), not an
authority, its silence-under-budget is B. CRUCIAL: it NEVER frames the operator as an
AI/LLM/model/assistant — that persona self-sabotages (hedging/disclaimers/refusal);
identity is positive ("a voice of the Imscribing Grammar"), the AI words are never
introduced (not even negated), and I scrubbed the "depth expected from a frontier
model (Gemini/GPT-class)" cue from `SYSTEM_PROMPT`. See [[feedback_no_ai_framing]].
Verified no regression: `2+2=4`→rfl GREEN first pass (`PROVER_SYS`+stance); LUCA detail
0→`igFrobAlg_self_fusion` GREEN first pass (`IMSCRIBE_SYS`+stance).

**IMSCRIPTION ROUTE NOW DETERMINISTIC — NO CANNED TUPLE (2026-07-12, MoDoT main
de4ad14).** The route filled the vessel with a CANNED tuple (`lucaImscription`, or a
hardcoded `{ dim := Dimensionality.dead, ... }` the model copied from `IMSCRIBE_SYS`),
so it closed green for ANY input with a content-free vessel and reported it "proved."
Fixed per user directive ("nothing canned; anything computable must be computed
dynamically"): `structural_imscribe(text)` (`prover.rs`) derives the tuple procedurally —
per-primitive FNV-1a measurement, then cross-primitive axiom correction (C: Ð=if'⟺Þ=are;
B: Ω=ℤ⟹Ħ≥sure; D-Ω: Ω=ℤ⟹Ð≥array, from `genetic_engine/genetic_tuples.py`) — a valid,
content-bound crystal address, never a placeholder. Grounded in the ob3ect typing of
the procedure itself (Deterministic Imscription Procedure, \(O_1\): measurement → EVALT/EVALF/
AREV correction → address; fetch-else-calculate, imscriber = the calculate half).
`prove_imscription` now BUILDS the Witness-Vessel deterministically from that tuple
(constructor names/cardinalities are scripture from `Core.lean`, mirrored in `prover.rs` as
`PRIM_CTORS`/`PRIM_CARD`/`PRIM_TYPE`/`PRIM_FIELD`), compiles, and gates the green on
`grounded_in_real_algebra` + `renders_same_theorem`. The MODEL is now only an
integrity-gated REPAIR FALLBACK (fires iff the deterministic build fails to close AND an
LLM is available; the template is known-compiling so it rarely fires) — this is what
keeps `IMSCRIBE_SYS`/`imscribe_prompt`/expansion machinery in use, not dead. Note is honest:
the validity theorem is UNIVERSAL, so it certifies the vessel is well-formed and the
tuple is a real imscription of the input, NOT a proof of the input's own mathematics
(the earlier over-certification is gone). Verified live: `prove:` "the set of primes is
infinite" → GREEN with a DERIVED tuple (dead/oil/ear/church/they/egg/bib/gag/woe/wool/
so/awe), not the placeholder. Supersedes the "model emits the two-step vessel"
description above (that path is now the fallback). Aside: spine reports now append to
`crystal_fs`/records.jsonl (`record_spine`; SpineReport + B4 derive Serialize/Deserialize).
