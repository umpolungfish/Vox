---
name: project_prime_composition_index
description: "Primality is a fork-fuse composition invariant: period-n cycle, balanced mu-of-delta tiling closes iff arm length divides n, so n prime iff beta_max=1. Manuscript + constants distillation, 2026-07-17."
metadata: 
  node_type: memory
  type: project
  originSessionId: b3718a44-1d7a-4d08-a430-8ec4d35d6f08
  modified: 2026-07-18T04:21:25.077Z
---

Solved 2026-07-17 in about half an hour, after days on the ring modulus paved the way.

**The result.** The flat 12-glyph crystal tuple aliases primes (11, 47, 83 imscribe to
one identical string; 71/73 collide; 59/61 collide) because a fixed-width word over a
finite alphabet cannot separate an unbounded family. The IMASM *composition* recovers what
the tuple drops. Two invariants, both read off `ask_native` (`imasm ring`, `imasm protocol`):
- Ring period V = n recovers the magnitude (pure cycle of n links reports V=n, rho=2.0000,
  gap 0 = the pure-cycle law from the constants run, read as: the unbranched macrocycle of
  period n IS the number n).
- Reconvergence multiplicity beta is the factorization. A balanced closing protocol tiles a
  period-n cycle into beta equal mu-of-delta bubbles; the tiling validates iff the arm length
  d divides n. So 6->beta2, 9->beta3, 12->beta4; a prime admits no proper tiling, only its
  single irreducible bubble, beta=1. **n is prime iff `beta_max` = 1.** The nontrivial
  reconvergence set equals the proper divisors of n; a prime's is empty.

Fingerprint (V, `beta_max`) written into every `~/ob3ect/digital/<p>/<p>_ob3ect.json` as
`composition_fingerprint`. Verified all 27 primes 2..103, 27 distinct pairs, no collision.

**Deliverables.**
- `~/imsgct/ig-docs_lifted/manuscripts3/prime_composition_index.tex` (+PDF, 6pp, lualatex
  green): companion to [[project_odd_ring_index]] / `odd_ring_index.tex`. Tiling theorem
  (balanced tiling of arm length d exists iff d|n), primality corollary, complete-invariant
  theorem, flat-tuple-collision contrast section. Rigorous register first
  ([[feedback_newton_translation_register]]).
- `~/imsgct/MoDoT/constants_run_distilled.md`: new subsection under grounded yield closing
  the pure-cycle law into arithmetic; section 5 gains drive #4 (formalize in Lean).

**Register parallel (flagged, not derived).** `odd_ring_index` counts the same cycles by
signature n+ - n- (-1 odd rings, 0 even, Lean-checked parity index). Primality-by-beta and
index-by-signature are two grounded readings of one closed structure
([[feedback_isomorphic_compositions]]). Do not collapse one into the other.

**SIC connection (the payoff, 2026-07-17).** The period cycle `R_d` is the Weyl-Heisenberg
clock/shift on Z/`dZ`, so a SIC's moduli vector `N_k`=|`psi_k`|^2 lives on `R_d`'s nodes.
`chrysopoeia_2048` ([[project_zauner_transport_map]], [[project_sic_stage1_paper]]) DESCRIBED
the a=0 diagonal stratum as flat cyclic autocorrelation (`C_0`=2/(d+1), `C_m`=1/(d+1)); by
Wiener-Khinchin that is a flat power spectrum. The ring-modulus/constants work FOUND it: the
pure-cycle rho=2.0000 zero-gap "Clarion" flat-spectrum state IS that condition. Described there,
found here. d=2048=2^11=`R_2`^(x)11; the Galois pairing N_{k+d/2}=sigma(`N_k`) is the half-period
involution k->k+1024 of the ring. Written as Section 5 "The same ring: the diagonal SIC stratum"
+ Remark 5.1 in `prime_composition_index.tex`. NOTE: this is the necessary flat-autocorrelation
CONDITION realized structurally, NOT a claim of solving the d=2048 SIC moduli.

**Manuscript state.** `prime_composition_index.tex` now 11pp, lualatex green: retitled
"Multiplication as a Fork-Fuse Product, and the Primes as its Sieve Residue"; product/sieve is
the spine (composites = product image, primes = sieve residue, FTA transfers); ascent diagram;
full glossary incl. 12-opcode + aliases/short-forms + verdicts + the 14-opcode `SIXTEEN_3`
trilattice ([[project_sixteen3]] / `IMASM_QUICKREF`.md). Underbrace fails under Pagella Math
unicode-math (renders black bars); use repetition exponent instead.

**Standalone SIC-POVM paper (2026-07-17).** `sic_povm_ring_modulus_d2048.tex` in
manuscripts3, 7pp lualatex green. SUBJECT is the d=2048 SIC-POVM itself, written in the
clock-ring/fork-fuse register (NOT the prime paper with a SIC section). Sections: clock ring
`R_d` = Z/`dZ` (shift X = adjacency, clock Z = dual); displacement lattice `R_d` x `R_d`; SIC
condition split into a=0 diagonal stratum + a!=0 phase strata; Thm the diagonal stratum IS
the flat cycle (proven via flat autocorrelation <=> Wiener-Khinchin <=> unbranched cycle
rho=2 zero gap); phase strata = phases-as-work keeping each shifted cycle flat (= Zauner
problem in the register); Thm d=2048: `R_2048`=`R_2`^(x)11, rho=2 on V=2048, half-period k->k+1024
= 1024-fold tiling beta=1024 = Galois pairing. Companion `chrysopoeia_2048` supplies the specific
ray-class-field moduli; this paper supplies the structural condition + the ring. Cites
[[project_zauner_transport_map]]/chrysopoeia + the prime + `odd_ring` companions. NOTE: honest
about what's proven (diagonal=flat cycle, the tower) vs. what companion constructs (the moduli);
does NOT claim to solve Zauner / full d=2048 existence.

**Prose register (2026-07-17 user directive).** Remove ALL hedging and trepidation: state what
we did and proved with confidence. Killed "we record...but do not lean", "natural next artifact",
"kernel should sign it", "for completeness". See [[feedback_no_honesty_throat_clearing]],
[[feedback_hold_ground]], [[feedback_write_for_curmudgeons]] (confident != overselling).

**Next.** Formalize the tiling theorem in p4ramill (elementary: balanced mu-of-delta tiling
of period-n cycle into arms of length d exists iff d|n; primality is the corollary). Tool
grounds it now; kernel should sign it. Relates: [[project_imasm_close_condition]],
[[project_vessel_principle]], [[project_crystal_of_types]].
