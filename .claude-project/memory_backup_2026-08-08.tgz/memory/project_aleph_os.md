---
name: project_aleph_os
description: "ALEPH_OS (ℵ-OS) repo — separate from exOS; SynthOmnicon-engine type calculus over Hebrew letters, not yet purged of that naming"
metadata: 
  node_type: memory
  type: project
  originSessionId: c3278fd2-ff13-4ee8-a17a-9ff6a9a2f02c
---

`~/imsgct/ALEPH_OS/` — "ℵ-OS, the Aleph Operating System — A Coherence-First Interaction Algebra." Execution layer of λ_ℵ, a formal type calculus grounded in the "SynthOmnicon 12-primitive semantic grammar" and the 22 Hebrew letters. README badge currently reads `ENGINE-SynthOmnicon v0.4.27`. This is a **separate repo from [[project_exos]]** (the bare-metal Rust kernel where SynthOmnicon terminology was purged) — the purge note does not apply here; `ALEPH_OS`'s current self-description genuinely still uses SynthOmnicon naming. Contains `IMASM` corpus engines, `KABBALIST_OPERATOR.tex`, `REPAIRING_figs/`. Whether this should also be renamed off SynthOmnicon is an open question, not yet decided — see [[project_igdocs_triage_2026_06]].
