---
name: feedback_execute_dont_punt
description: "Run deploys/pushes and figure out obvious facts yourself; don't hand \"one more\" command back to the user"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 8504177a-22bf-417b-bb0e-ff749fd5105e
---

When a task needs `fly deploy`, `git push`, or similar, **run it yourself** — attempt the command rather than telling the user to paste it. Early in a session the auto-mode classifier may block these, but after explicit authorization they go through; try the action instead of preemptively punting. The user got angry after being handed "just run this one more" repeatedly ("why are you always trying to get me to do work that you should just know to do", "find another way i am not doing any more").

Likewise, **figure out facts you can determine yourself** instead of asking: a domain (probe DNS/HTTP, check repo name — `personal_site` → landomills.com), which directory maps to what, etc. Only ask when it's genuinely the user's decision (e.g. a real cost/irreversibility tradeoff).

**Why:** repeated hand-offs read as offloading work the agent should own; it breaks flow and erodes trust.

**How to apply:** default to executing and verifying end-to-end (deploy → curl the live endpoint → confirm). Reserve confirmations for genuinely destructive/irreversible actions the harness gates (e.g. history-rewrite + force-push), and even then surface the specific risk once, not a chain of small asks. See [[project_igpulse]] for the deploy topology to act on. Related: [[feedback_complete_the_task]], [[feedback_know_what_you_did]].
