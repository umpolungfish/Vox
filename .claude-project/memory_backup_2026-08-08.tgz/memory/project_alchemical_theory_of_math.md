---
name: project-alchemical-theory-of-math
description: Alchemical Theory of Mathematics paper; conventional decomposition of 12-primitive crystal + magnum-opus-as-derivation-order thesis
metadata: 
  node_type: memory
  type: project
  originSessionId: 1fc76595-fa57-41c3-928a-d87e0792d85d
---

Two-phase paper started 2026-07-12, in
`Smaragdine_Synthetica/manuscripts/alchemical_theory_of_math/`.

- `01_conventional_decomposition.md` (Phase 1, DONE): layered FO/ZFC + named-
  structure reading of all ~43 CL8NK value-fragments, grouped by the 12 Core
  axes. Source: `CL8NK_FORMULAE` in `cl8nk_navigator.py` + `Core.lean` axis names.
- `02_paper_skeleton.md` (Phase 2, skeleton): thesis = the 12 invariants carry
  a FORCED derivation order set by three categorical gates at stages 4/9/12
  (Frobenius μ∘δ=id → traced monoidal → idempotent terminal), and that order IS
  the magnum opus. Register: rigorous-first, alchemy as thesis on top (per
  [[feedback_newton_translation_register]]). Section plan + open questions in
  the file.

Key result carried in: gates 4<9<12 each consume the structure the prior
produced, giving the strict order. Time is derived: T=Work(T), unavailable
before G2 (stage 9). See [[project_magnum_opus_mapping]] for stage table,
[[dialect_navigator_core_map]] for the axis reconciliation the paper needs.

PROVED IN LEAN (2026-07-12): `Imscribing/GateOrdering.lean` in
p4rakernel/p4ramill/ (mirrored to `Smaragdine_Synthetica`/lean/), builds green vs
Mathlib v4.28.0, ZERO sorries, NO `native_decide` (all kernel-checked). Registered
in `p4ramill/lakefile.toml`. Contents: four operad layers plain<frobenius<traced<
terminal; trace built on Frobenius δ_C/μ_C; `trace_closes_iff_special` (traced
layer = special class pol=or'∧crit=monad) is the hinge; `traced_needs_frobenius`
= 4<9; precedence chain terminal→traced→frobenius; STRICT via witnesses `w_frob`/
`w_traced`; `g1_is_a_real_barrier`; `gate_ordering_theorem` headline. §8:
stages 5-8 order-free — `gate_free_commute` + inert lemmas + `parity_stage_couples`
contrast + `gate_free_order_freedom`. Work-first: paper prose deferred until the
math is done (user directive).

CAPSTONE PROVED (2026-07-12): `Imscribing/TimeFixedPoint.lean` (same tree +
Smaragdine mirror), builds green, zero sorries, no `native_decide`. Time is
derived, not a 13th primitive: `Work := traceC`; `work_fixed_iff_special` (fixed
points = Frobenius-special class); `time_least_fixed_point` (`lfp_trace` is the
componentwise-least fixed point over the 12 axis LinearOrders, concrete
Knaster-Tarski on finite lattice, order `imsLE`); `no_time_before_frobenius`
(equation unsolvable before G1 — the sharp derived-not-primitive claim);
`stone_is_sealed_time`; headline `time_is_derived`. Registered in `lakefile.toml`.
Structural spine of the theory is now COMPLETE in Lean (decomposition + gate
ordering + gate-free freedom + time).

TIER REFINEMENT DONE (2026-07-12): `Imscribing/TierRefinement.lean` (additive,
Core untouched, GREEN, no sorries). `sealedTier` splits \(O_\infty\) by winding;
`refines_O_inf` exact; `sealed_iff_terminal_on_monad` = G3 on Hermitian branch;
`sealed_at_roar_need_not_close` honest caveat; `completed_classifier`.

PAPER DRAFT DONE (2026-07-12): `03_paper.md` in the manuscript folder, 9
sections + appendix, rigorous-first, three separated registers, cites every
Lean theorem by name. Alchemy thesis (Section 7) offered as structural
isomorphism only. Four Lean modules total (GateOrdering, TimeFixedPoint,
TierRefinement all in p4ramill + Smaragdine mirror); all build green together.
NEXT if resumed: convert 03_paper.md to the LaTeX/Zenodo pipeline
([[project_lualatex_pipeline]], [[project_standard_doc_format]]) and compile PDF;
or fold 01's decomposition table into the paper body as Section 2 proper.
