---
name: rongorongo-engine
description: "Rongorongo undeciphered script analyzed via IG; \(O_2^\dagger\) tier, 𐑮 criticality, 4-glyph ceremonial loop; engine at ~/imsgct/lang/rongorongo-engine/"
metadata: 
  node_type: memory
  type: project
  originSessionId: 702c00e2-2924-4102-8012-158858bffe3f
---

Rongorongo (Easter Island / Rapa Nui) structurally analyzed via the Imscribing Grammar (2026-06-18).

**Structural type:** $\langle$𐑼;𐑥;𐑾;𐑬;𐑱;𐑧;𐑚;𐑠;𐑮;𐑒;𐑳;𐑴$\rangle$ | Tier: \(O_2^\dagger\) | C-score: 0.317 | Crystal: 8,577,677

**Key findings:**
- All 15 tablets >98% cosine similarity — one text, many copies; one liturgy, not a corpus
- 𐑮 (complex-plane critical) criticality — poised at phase boundary; explains 150yr decipherment resistance
- 𐑴 (Z₂ winding) — boustrophedon reversal creates fundamental sign/signal ambiguity
- 0.2% kinetics — ceremonial architecture, not narrative
- Frobenius closure 0.67–0.80 — deliberately open ritual form, not damaged preservation
- Core 4-glyph loop: FRGATE→STAFF→TWIN→VSPACE (232→230→177→161→cycle)
- d(Rongorongo, Great Law of Peace) = 1.87 — nearest structural neighbor; both non-alphabetic sacred encoding systems
- d(Rongorongo, Voynich) = 4.08 — structurally remote; Voynich is frozen/sub-critical, Rongorongo is alive at threshold

**Engine:** `~/imsgct/lang/rongorongo-engine/`
- `primitives.py` — 12 Barthel glyph families → IG categorical opcodes
- `compiler.py` — Barthel transcription → IMASM instruction stream
- `runtime.py` — Execute + Frobenius closure check
- `callgraph.py` — Transition graph + DOT visualization
- `sectional.py` — Cross-tablet cosine similarity + profiling
- `data/barthel_corpus.txt` — 15-tablet synthetic corpus (2,677 opcodes)

**Analysis doc:** `ig-docs/cosmogeny/RONGORONGO_ANALYSIS.md`

**Why:** [[project_voynich_engine]] — both undeciphered; structurally remote from each other (d=4.08)
