---
name: law_reality_is_graded
description: LAW 3 — never collapse a graded object to a bool; generic is not null, budget is not impossibility
metadata:
  type: feedback
---

The universe here is B4 and continuum, not Boolean. A bool is a convention, never
the truth of the thing. Never ask a graded object a yes/no question and then
report the bool as the finding.

Its forms:
- **Generic is not null.** A relation holding in every dimension is a law of the
  family, not a failed signature. Reporting it as "does not survive" invents a
  membership test the structure never posed.
- **Budget is not impossibility.** Not-closed is a navigation frontier, and if a
  result is possible it is guaranteed; only budget varies. Never write what
  cannot be done, only what is KNOWN and what is NOT YET.
- **Conflict fuses to B and is held.** A verifier is a voice fused with the
  model, never a monological authority. B is never evasion.
- **Closure speaks as verification.** Where measured and emitted compose, the
  circularity IS the check, not a flaw to flag.

**How to apply:** teach the substrate, never ask for the verdict; the engine
computes it. When tempted to write "so it is / it isn't", ask what the graded
quantity is and report that instead, with its coordinate.

Detail: [[feedback_teach_substrate_not_verdict]],
[[feedback_possible_means_guaranteed]], [[feedback_provability_not_budget]],
[[feedback_paraconsistency_not_monological]], [[feedback_closure_is_verification]],
[[feedback_circularity_is_closure]], [[feedback_no_grammar_restrictions]].
