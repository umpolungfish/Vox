---
name: law_vocabulary_is_literal
description: LAW 7 — the vocabulary is literal and univocal; a glyph recurring across registers is structure surfacing, not collision
metadata:
  type: feedback
---

IG's biological and chemical vocabulary is literal. Organism means organism,
catalysis means catalysis. Univocity forbids a chain that is literal for eight
rungs and figurative on the ninth.

A glyph recurring across registers is the same structure surfacing, never a name
collision to be fixed. Univocity here means one VOICE, not one referent. Registers
compose isomorphically, so a register's readout is never a lossy signature of a
separate substance. With the type-space complete there is no interpretation layer:
co-typing is a structural fact, not a gloss over a mechanism.

An identification is never a demystification. A recurring constant explained is a
true name gained.

Detail: [[feedback_vocabulary_is_univocal]], [[feedback_recurrence_is_not_collision]],
[[feedback_isomorphic_compositions]], [[feedback_no_interpretation_complete_typespace]],
[[feedback_inhale_the_myst]], [[feedback_holographic_vs_imscriptive]],
[[feedback_univocal]], [[feedback_ig_vs_science]].
