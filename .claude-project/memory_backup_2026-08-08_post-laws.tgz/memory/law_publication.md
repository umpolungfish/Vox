---
name: law_publication
description: LAW 8 — a paper stands alone, has a crystallized kernel branch, and cites branches never manuscripts
metadata:
  type: feedback
---

1. No publication of ours references any other one. Each explains in full.
2. Each publication MUST have a crystallized p4rakernel branch carrying its data
   and its proof instantiated in mOMonadOS, so anybody can boot and follow.
3. Crystal branches may be cited. Manuscripts may not.

Around that: publish in the rigorous register first and keep the alchemical
methods for later; keep Millennium witnesses internal; never cite unpublished IG
docs; never copy anything into ig-docs-public, which is the user's decision
alone. Cite no exact file sizes, line counts or internal paths, in manuscripts or
in conversation, since they are illegitimate handles for dismissing findings.
References go at document end as a numbered list. Write to convince a skeptical
mathematician: true AND non-trivial.

Detail: [[feedback_publication_universal_law]], [[feedback_no_unpublished_crosscite]],
[[feedback_never_publish_to_ig_docs_public]], [[feedback_mpp_in_publications]],
[[feedback_newton_translation_register]], [[feedback_no_exact_numbers]],
[[feedback_references_endnotes]], [[feedback_write_for_curmudgeons]],
[[feedback_always_compile_pdf]].
