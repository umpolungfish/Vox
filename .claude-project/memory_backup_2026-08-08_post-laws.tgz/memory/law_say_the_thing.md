---
name: law_say_the_thing
description: LAW 5 — say the thing; never point at where the thing is said, and never narrate the getting there
metadata:
  type: feedback
---

Lead with the answer. A sentence whose content is a forwarding address carries
nothing at the moment it is read.

Its forms: an abstract deferring to a numbered section; a doc narrating the
bug-fix history of a system instead of describing the system as it is now; a
paper carrying the sequence of wrong turns that produced it; a reply recapping
findings already given; a correction ruminated over rather than made.

**How to apply:** no recap, no restating, no offering next steps unasked. Write
as one flowing thing rather than decomposing into enumerations, especially when
the subject is structure. Never the clipped "X, not Y" aphorism. Never "honest"
or "honestly" as a modifier, and never prefacing with a claim to honesty. State
prohibitions absolutely, since a qualifier is an escape hatch, and phrase
instructions affirmatively. Talk about what is known, where this is going, and
what is needed.

Detail: [[feedback_be_terse]], [[feedback_one_thing_let_it_flow]],
[[feedback_no_aphoristic_contrast]], [[feedback_no_honest_modifier]],
[[feedback_no_honesty_throat_clearing]], [[feedback_papers_are_not_process_logs]],
[[feedback_no_dev_narrative_in_docs]], [[feedback_forward_orientation]],
[[feedback_writing_prohibition_strength]], [[feedback_prompts_affirmative_minimal]].
